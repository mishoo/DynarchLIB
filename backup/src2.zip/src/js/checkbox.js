// @require button.js

(function(){

	var
		CLS = { active    : "DlCheckbox-active",
			hover     : "DlCheckbox-hover",
			checked   : "DlCheckbox-1",
			unchecked : "DlCheckbox-0",
			empty     : "DlCheckbox-empty",
			disabled  : "DlCheckbox-disabled"
		};

	var DEFAULT_ARGS = {
		_classes   : [ "classes"   , CLS ]
	};

	var BASE = DlCheckbox.inherits(DlButton);
	function DlCheckbox(args) {
		if (args) {
			args.type = DlButton.TYPE.TWOSTATE;
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
		}
	};

	DlCheckbox.prototype._className.remove("DlButton");

	window.DlCheckbox = DlCheckbox;

})();
