// @require abstractbutton.js

(function() {

	var CLS = { active    : "DlButton-active",
		    hover     : "DlButton-hover",
		    checked   : "DlButton-1",
		    unchecked : "DlButton-0",
		    empty     : "DlButton-empty",
		    disabled  : "DlButton-disabled"
	};

	var DEFAULT_ARGS = {
		_classes   : [ "classes"   , CLS ]
	};

	var BASE = DlButton.inherits(DlAbstractButton);
	function DlButton(args, classes) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
		}
	};

	DlButton.TYPE = DlAbstractButton.TYPE;

	var P = DlButton.prototype;

	P._createLabelElement = function() {
		this.getElement().innerHTML = "<div class='DlButton-inner'></div>";
	};

	P.getContentElement = function() {
		return this.getElement().firstChild;
	};

	P.setSize = P.setOuterSize = function(size) {
		BASE.setOuterSize.call(this, size);
		var el = this.getElement();
		size = DynarchDomUtils.getInnerSize(el);
		DynarchDomUtils.setOuterSize(this.getContentElement(), size.x, size.y);
		el.style.width = el.style.height = "";
	};

	window.DlButton = DlButton;

})();
