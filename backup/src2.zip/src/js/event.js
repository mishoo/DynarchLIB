// @require eventlistener.js

(function() {

	eval(DynarchDomUtils.importCommonVars());

	var EVENT_MAP = {
		"onmouseover" : "onMouseEnter",
		"onmouseout"  : "onMouseLeave",
		"onmousedown" : "onMouseDown",
		"onmouseup"   : "onMouseUp",
		"onclick"     : "onClick"
	};

	function DlEvent(ev) {
		this.type = ev.type;
		if (!/^on/.test(this.type))
			this.type = "on" + this.type;
		this.dl_type = EVENT_MAP[this.type] || this.type;
		this.ctrlKey = ev.ctrlKey;
		this.altKey = ev.altKey;
		this.shiftKey = ev.shiftKey;
		this.button = ev.button;
		this.pos = { x : ev.clientX,
			     y : ev.clientY };
		if (is_ie) {
			this.target = ev.srcElement;
			switch (this.type) {
			    case "onmouseover" : this.relatedTarget = ev.fromElement; break;
			    case "onmouseout"  : this.relatedTarget = ev.toElement; break;
			}
		} else try {
			this.target = ev.target;
			if (this.target.nodeType == 3 /* Node.TEXT */)
				this.target = this.target.parentNode;
			if (this.type == "onmouseout" || this.type == "onmouseover") {
				this.relatedTarget = ev.relatedTarget;
				if (this.relatedTarget && this.relatedTarget.nodeType == 3 /* Node.TEXT */)
					this.relatedTarget = this.relatedTarget.parentNode;
			}
		} catch(ex) {}
	};

	DlEvent.prototype.computePos = function(widget) {
		var el = widget
			? widget.getElement()
			: document.body;
		var pos = this.elPos = el
			? DOM.getPos(el)
			: { x: 0, y: 0 };
		this.relPos = { x : this.pos.x - pos.x,
				y : this.pos.y - pos.y };
	};

	DlEvent.prototype.getObject = function() {
		var el = this.target;
		try {
			while (el && !DlWidget.getFromElement(el))
				el = el.parentNode;
			return el ? DlWidget.getFromElement(el) : null;
		} catch(ex) {};
		return null;
	};

	DlEvent.stopEvent = function(ev) {
		if (is_ie) {
			ev.cancelBubble = true;
			ev.returnValue = false;
		} else {
			ev.preventDefault();
			ev.stopPropagation();
		}
		return false;
	};

	var _captures = {};
	var _captures_by_event = {};

	DlEvent.captureEvents = function(w, evs) {
		var id = Dynarch.ID("capture");
		var capture = {
			widget : w,
			events : evs
		};
		evs.r_foreach(function(ev, i) {
			// FIXME: is this needed if we stay organized?
			// evs[i] = ev = ev.toLowerCase();
			var f = _captures_by_event[ev];
			if (f == null)
				f = _captures_by_event[ev] = {};
			f[id] = capture;
		});
		_captures[id] = capture;
		return id;
	};

	DlEvent.releaseCapture = function(id) {
		var c = _captures[id];
		c.events.r_foreach(function(ev) {
			var f = _captures_by_event[ev];
			if (f != null)
				delete f[id];
		});
		delete _captures[id];
		return null;
	};

	function _processCaptures(dev) {
		var f = _captures_by_event[dev.dl_type];
		var processed = {};
		for (var i in f) {
			var w = f[i].widget;
			if (!DlEvent.checkDisabled(w)) {
				processed[w.id] = dev.dl_type;
				w.applyHooks(dev.dl_type, [ dev ]);
			}
		}
		return processed;
	};

	DlEvent.checkDisabled = function(w) {
		while (w) {
			if (w.disabled())
				return true;
			w = w.parent;
		}
		return false;
	};

	function _genericEventHandler(ev) {
		ev || (ev = window.event);
		var el, obj,
			dev = ev instanceof DlEvent ? ev : new DlEvent(ev);
		DlEvent.latestEvent = dev;
		try {
			var processed = _processCaptures(dev);
			function doEvent(type) {
				if (processed[obj.id] != type)
					obj.applyHooks(type, [ dev ]);
			};
			//window.status = dev.dl_type;
			el = dev.target;
			while (el) {
				obj = DlWidget.getFromElement(el);
				if (obj && !DlEvent.checkDisabled(obj)) {
					switch (dev.type) {
					    case "onmousedown" :
						obj._ev_mouseDown = true;
						break;
					    case "onmouseup" :
						obj._ev_mouseDown = false;
						break;
					    case "onmouseover" :
						if (!DOM.related(el, ev)) {
							obj._ev_mouseInside = true;
						}
						break;
					    case "onmouseout" :
						if (!DOM.related(el, ev)) {
							obj._ev_mouseInside = false;
						}
						break;
					}
					doEvent(dev.dl_type);
				}
				el = el.parentNode;
			}
		} catch(ex) {
			if (!(ex instanceof DlExStopEventBubbling))
				throw ex;
		}
	};

	var _unloadListeners = [];
	function _unloadHandler() {
		_unloadListeners.r_foreach(function(f) { f(); });
		DOM.removeEvents(document, [ "click", "mouseover", "mouseout", "mousedown", "mouseup", "mousemove" ],
				 _genericEventHandler);
		// CLEAN UP.  BULLDOZE EVERYTHING!  Who said JS is garbage collected?
		// No it ain't, not as long as IE still exists. :-(
		DOM.removeEvent(window, "unload", _unloadHandler);
		for (var i in window) {
			if (i == "DlEvent")
				continue;
			if (/^(Dynarch|Dl)/.test(i)) {
				DestroyObject(window[i]);
				window[i] = null;
			}
		}
		if (is_ie)
			CollectGarbage();
		window.unload = null;
		window.DlEvent = null;
	};

	DlEvent.atUnload = function(f) { _unloadListeners.push(f); };

	DOM.addEvents
		(document, [ "click", "mouseover", "mouseout", "mousedown", "mouseup", "mousemove" ],
		 _genericEventHandler);

	DOM.addEvent(window, "unload", _unloadHandler);

	window.DlEvent = DlEvent;

})();
