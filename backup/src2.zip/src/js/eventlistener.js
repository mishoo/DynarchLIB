// @require jslib.js
// @require exception.js

function DlEventListener() {
	this._hooks = {};
};

(function() {

	// private stuff
	function getHooks(o, ev) {
		var a = o._hooks[ev.toLowerCase()];
		if (!a)
			throw new DlException("Event [" + ev + "] not registered.");
		return a;
	};

	// public
	var P = {
		registerEvents : function(evs) {
			evs.foreach(function(e) {
				e = e.toLowerCase();
				if (!this._hooks[e])
					this._hooks[e] = [];
			}, this);
		},
		addEventListener : function(ev, handler, phase) {
			if (ev instanceof Array) {
				var self = this;
				ev.foreach(function(ev) {
					self.addEventListener(ev, handler, phase);
				});
			} else {
				var a = getHooks(this, ev);
				phase
					? a.unshift(handler)
					: a.push(handler);
			}
		},
		removeEventListener : function(ev, handler) {
			if (ev instanceof Array) {
				var self = this;
				ev.foreach(function(ev) {
					self.removeEventListener(ev, handler);
				});
			} else {
				getHooks(this, ev).remove(handler);
			}
		},
		callHooks : function(ev) {
			var args = arguments.length > 1
				? Dynarch.makeArray(arguments, 1)
				: [];
			return this.applyHooks(ev, args);
		},
		applyHooks : function(ev, args) {
			var self = this;
			try {
				getHooks(self, ev).foreach(function(f) {
					f.apply(self, args);
				});
			} catch(ex) {
				if (!(ex instanceof DlExStopEventProcessing))
					throw ex;
			}
		}
	};
	Dynarch.merge(DlEventListener.prototype, P);

})();
