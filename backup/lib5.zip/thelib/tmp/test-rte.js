var d = new DlDialog({ title: "Test editor", resizable: true });
d.setInnerSize({ x: 600, y: 400 });
//d.getContentElement().style.padding = "3px";

d.addEventListener("onContextMenu", function() {
	alert("Clicked!");
	throw new DlExStopEventBubbling;
});

var vbox = new DlVbox({ parent: d });
vbox.getElement().style.width = "100%";

var hbox = new DlHbox({ parent: vbox });
var dp = new DlButtonCalendar({ parent: hbox, calendar: { weekNumbers: true } });

//vbox.addSeparator();
hbox.addSeparator();

var modal = new DlCheckbox({ parent: hbox, label: "Modal dialog" });
hbox.addSeparator();
modal.addEventListener("onChange", function() {
	d.setModal(this.checked());
});

var bold = new DlButton({ parent: hbox, iconClass: "IconCalendar", label: "Bold" , type: DlButton.TYPE.TWOSTATE });
bold.addEventListener("onClick", function() {
	rte.execCommand("bold");
});
var italic = new DlButton({ parent: hbox, label: "<i>I</i>", type: DlButton.TYPE.TWOSTATE });
italic.addEventListener("onClick", function() {
	rte.execCommand("italic");
});

//hbox.addSeparator();
hbox.createCellElement().style.width = "100%";

var cp = new DlButtonColorPicker({ parent: hbox });
cp.setColorPicker(new DlColorPickerHSV({}));
cp.addEventListener("onSelect", function(rgb, hsv, color, brightness) {
	rte.execCommand("forecolor", color);
});
cp.getButton().addEventListener("onClick", Dynarch.makeClosure(function() {
	if (this.rgb)
		rte.execCommand("forecolor", DlColor.RGB2color(this.rgb));
}, cp));

var cp = new DlButtonColorPicker({ parent: hbox });
cp.setColorPicker(new DlColorPickerHSV({}));
cp.addEventListener("onSelect", function(rgb, hsv, color, brightness) {
	rte.execCommand("backcolor", color);
});
cp.getButton().addEventListener("onClick", Dynarch.makeClosure(function() {
	if (this.rgb)
		rte.execCommand("backcolor", DlColor.RGB2color(this.rgb));
}, cp));

// vbox.addSeparator();
var rte = new DlRteFrame({ parent: vbox });
// rte.setInnerSize({ x: "100%", y: "100%" });

rte.addEventListener("onUpdate", function() {
	var doc = this.getIframeDoc();
	bold.checked(doc.queryCommandState("bold"), true);
	italic.checked(doc.queryCommandState("italic"), true);
});

var status = new DlContainer({ parent: vbox, className: "Dl-StatusBar" });
status.getElement().innerHTML = "Status bar";

document.body.appendChild(d.getElement());
d.display(true);
d.centerOnParent();

d.addEventListener("onResize", function() {
	var dlg_size = d.getInnerSize();
	var h = dlg_size.y - rte.getElement().parentNode.offsetTop;
	h -= status.getOuterSize().y;
	rte.setOuterSize({ x: dlg_size.x, y: h });
});

d.callHooks("onResize");

rte.initDesignMode(function() {
	rte.loadStyle("/thelib/editor.css");
	rte.setHTML("<h1>Some content here</h1><p>and a paragraph</p>");
});

rte.addEventListener("onUpdate", function(ev) {
	var html = [];
	var a = this.getAllAncestors();
	a.pop();
	a.r_foreach(function(el, i) {
		html.push("<span>" + el.tagName.toLowerCase() + "</span>");
	});
	status.setContent(html.join(" » "));
});

// rte.addEventListener("onMouseMove", function(ev) {
// 	window.status = (ev.pos.x + ", " + ev.pos.y + " on a " + ev.origTarget);
// });
