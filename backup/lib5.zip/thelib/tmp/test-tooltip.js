var box = new DlHbox({ borderSpacing: 10 });
var btn = new DlButton({ parent: box, label: "Check This Out" });
var tt = new DlPopup({});
tt.install({ widget: btn, content: "This is a strange cool button, should we press it?" });
document.body.appendChild(box.getElement());

btn.addEventListener("onClick", function() {
	alert(document.body.innerHTML);
});

    
box.setAlign("5em");
