var b = new DlButtonCalendar({ label: "Select date..." });


var div = document.createElement("div");
div.style.margin = "2em 10em";
div.appendChild(b.getElement());
document.body.appendChild(div);
