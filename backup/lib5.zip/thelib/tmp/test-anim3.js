var stepp = 10;
var timer = setInterval(function() {
	if (!stepp--)
		clearInterval(timer);

	if (!window.tttt)
		window.tttt = 100;
	else
		window.tttt += 5;
	var el = document.createElement("div");
	el.style.position = "absolute";
	el.innerHTML = "DynArch";
	el.style.backgroundColor = "#ff8";
	el.style.border = "1px solid #c00";
	el.style.left = "10px";
	el.style.top = (100 + Math.random() * 500) + "px";
	document.body.appendChild(el);

	var a = new Animation(100, 50);
	a.el = el;
// a.fwd = false;
// a.reset(50, 50);
	a.addEventListener("onStop", function() {
		this.el.style.backgroundColor = "#fc4";
	});
	a.addEventListener("onUpdate", function() {
		this.el.style.left = this.comp(500, 10) + "px";
		this.el.style.fontSize = this.comp(2, 40) + "px";
	});
	a.start();
}, 500);
