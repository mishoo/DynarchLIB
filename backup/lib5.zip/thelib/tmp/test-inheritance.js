function Foo() {
	this.val = "foo";
}

Foo.prototype.f = function() {
	alert(this.val);
};

Bar.inherits(Foo);
function Bar() {
	this.val = "bar";
}

var b = new Bar();
b.f();
