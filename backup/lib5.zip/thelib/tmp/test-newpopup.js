
var b = new DlButton({ label: "Foo Bar" });
document.body.appendChild(b.getElement());

var ttip = "<table style='border: 1px solid #000; background: #fff;'><tr><td><b>Ckt cu mak</b></td></tr></table>";

b.addEventListener("onMouseEnter", function() {
	var p = DlPopup.get(0);
	p.popup(750, ttip, this.getElement(), "mouse");
});

b.addEventListener("onMouseLeave", function() {
	var p = DlPopup.get(0);
	p.hide();
});

// var p1 = DlPopup.get(0);
// var p2 = DlTooltip.get(0);
// var p3 = DlPopup.get(0);

// alert(p3 === p1);
