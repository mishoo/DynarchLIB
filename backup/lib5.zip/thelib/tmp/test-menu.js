	var orig_menu = menu = new DlHMenu({ className: "DlPopupMenu" });

	var i1 = new DlMenuItem({ parent: menu, label: "Check", iconClass: "icon1" });
	var i2 = new DlMenuItem({ parent: menu, label: "This is a cool" });
	menu.addSeparator();
	var i3 = new DlMenuItem({ parent: menu, label: "Menu that will" });
	menu.addSeparator();
	var i4 = new DlMenuItem({ parent: menu, label: "Become even cooler" });

	var fmenu = menu = new DlVMenu({});
	fmenu.addEventListener("onSelect", function(item_name, item) {
		alert(item_name);
	});
	var j1 = new DlMenuItem({ parent: menu, label: "Popup 1", iconClass: "icon1", name: "Foo Item" });
	var j2 = new DlMenuItem({ parent: menu, label: "Popup 2", iconClass: "icon1", disabled: true });
	// j2.disabled(true);
	var j3 = new DlMenuItem({ parent: menu, label: "Popup 3", iconClass: "icon1" });
	var j4 = new DlMenuItem({ parent: menu, label: "Popup 4", iconClass: "icon1" });
	i1.setMenu(menu);

	menu = new DlVMenu({});
	var j11 = new DlMenuItem({ parent: menu, label: "Popup 1", iconClass: "icon1" });
	var j22 = new DlMenuItem({ parent: menu, label: "Popup 2", iconClass: "icon1" });
	var j33 = new DlMenuItem({ parent: menu, label: "Popup 3", iconClass: "icon1" });
	var j44 = new DlMenuItem({ parent: menu, label: "Popup 4", iconClass: "icon1" });
	i2.setMenu(menu);

	menu = new DlVMenu({});
	var k1 = new DlMenuItem({ parent: menu, label: "Ckt Menu Item 1", iconClass: "icon1" });
	var k2 = new DlMenuItem({ parent: menu, label: "Ckt Menu Item 2" });
	var k3 = new DlMenuItem({ parent: menu, label: "Ckt Menu Item 3" });
	var k4 = new DlMenuItem({ parent: menu, label: "Ckt Menu Item 4", iconClass: "icon1" });
	j3.setMenu(menu);

	menu = new DlVMenu({});
	new DlCheckbox({ parent: menu, group: "Q3", label: "Apples" });
	new DlCheckbox({ parent: menu, group: "Q3", label: "Bananas", checked: true });
	new DlCheckbox({ parent: menu, group: "Q3", label: "Oranges" });
	DlRadioGroup.getById("Q3").maxChecked(2);
	menu.addSeparator();
	new DlCheckbox({ parent: menu, label: "Pears & Perls" });
	//new DlMenuItem({ parent: menu, label: "Ckt Menu Item 4", iconClass: "icon1" });
	menu.addSeparator();
	new DlRadioButton({ parent: menu, label: "Linux", group: "OS", checked: true });
	new DlRadioButton({ parent: menu, label: "Mac OS X", group: "OS" });
	new DlRadioButton({ parent: menu, label: "Windows", group: "OS" });
	//var clone = new DlMenuItem({ parent: menu, label: "Clone myself" });
	k1.setMenu(menu);
	i3.setMenu(menu);
	k4.setMenu(menu);
	//clone.setMenu(menu);

	menu = new DlVMenu({});
	var l1 = new DlMenuItem({ parent: menu, label: "Send email...", iconClass: "icon1" });
	menu.addSeparator();
	var l2 = new DlMenuItem({ parent: menu, label: "Check out" });
	var l3 = new DlMenuItem({ parent: menu, label: "Review changes" });

	l3.setMenu(fmenu);

	i4.setMenu(menu);

var div = document.createElement("div");
div.style.margin = "1em";
div.appendChild(orig_menu.getElement());
document.body.appendChild(div);
