var DlSingleton = {

	_ctors   : {},
	_objects : {},

	get : function(type) {
		var o = this._objects[type];
		if (!o)
			o = this._objects[type] = new this._ctors[type];
		return o;
	},

	register : function(type, ctor) {
		this._ctors[type] = ctor;
	}

};
