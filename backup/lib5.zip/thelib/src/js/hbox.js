// @require box.js

(function() {

	var CE = DynarchDomUtils.createElement;
	var BASE = DlHbox.inherits(DlBox);
	function DlHbox(args) {
		if (args) {
			BASE.constructor.call(this, args);
		}
	};

	var P = DlHbox.prototype;

	P._createElement = function() {
		BASE._createElement.call(this);
		this._row = CE("tr", null, null, this._tbody);
	};

	P.createCellElement = function() {
		return CE("td", null, { className : "cell" }, this._row);
	};

	P._removeWidgetElement = function(w) {
		if (this._widgets.contains(w)) {
			var el = w.getElement();
			el.parentNode.parentNode.removeChild(el.parentNode);
		}
	};

	P.setAlign = function(left, right) {
		var el = this.getElement();
		switch (left) {
		    case "left":
			el.style.marginLeft = "0";
			el.style.marginRight = "auto";
			break;
		    case "center":
			el.style.marginLeft = "auto";
			el.style.marginRight = "auto";
			break;
		    case "right":
			el.style.marginLeft = "auto";
			el.style.marginRight = "0";
			break;
		    default :
			el.style.marginLeft = left != null ? left : "auto";
			el.style.marginRight = right != null ? right : "auto";
		}
	};

	window.DlHbox = DlHbox;

})();
