// @require jslib.js

DlHtmlUtils = {

	_blockTags : ( " body form textarea fieldset ul ol dl li div blockquote " +
		       "p h1 h2 h3 h4 h5 h6 quote pre table thead " +
		       "tbody tfoot tr td iframe address " ),

	isBlockElement : function(el) {
		return el && el.nodeType == 1 && (DlHtmlUtils._blockTags.indexOf(" " + el.tagName.toLowerCase() + " ") != -1);
	},

	_quickTags : " br hr input link meta img ",

	needsClosingTag : function(el) {
		return el && el.nodeType == 1 && DlHtmlUtils._quickTags.indexOf(" " + el.tagName.toLowerCase() + " ") == -1;
	},

	htmlEncode : function(str) {
		// we don't need regexp for that, but.. so be it for now.
		return str.replace(/&/ig, "&amp;")
			.replace(/</ig, "&lt;")
			.replace(/>/ig, "&gt;")
			.replace(/\x22/ig, "&quot;")
			.replace(/\u00A0/g, "&#xa0;");
	},

	getHTML : function(root, outputRoot) {
		var html = [];
		function rec(root, outputRoot) {
			switch (root.nodeType) {
			    case 11: // DOCUMENT_FRAGMENT
				outputRoot = false;
			    case 1: // ELEMENT
				if (outputRoot) {
					var closed = !(root.hasChildNodes() || DlHtmlUtils.needsClosingTag(root));
					var tag = root.tagName.toLowerCase();
					html.push("<", tag);
					var attrs = root.attributes;
					for (var i = 0; i < attrs.length; ++i) {
						var a = attrs.item(i);
						if (!a.specified)
							continue;
						var name = a.nodeName.toLowerCase();
						if (/^_moz|^_msh/.test(name))
							continue;
						var value;
						if (name != "style") {
							if (typeof root[a.nodeName] != "undefined"
							    && name != "href"
							    && name != "src"
							    && !/^on/.test(name))
								value = root[a.nodeName];
							else
								// FIXME: IE converts URL-s to absolute
								value = a.nodeValue;
						} else
							value = root.style.cssText;
						if (/(_moz|^$)/.test(value))
							continue;
						html.push(" " + name + '="' + value + '"');
					}
					html.push(closed ? " />" : ">");
				}
				for (i = root.firstChild; i; i = i.nextSibling)
					rec(i, true);
				if (outputRoot && !closed)
					html.push("</" + tag + ">");
				break;
			    case 3: // TEXT
				if (/^(script|style)$/i.test(root.parentNode.tagName)) {
					if (root.data.indexOf("/*<![CDATA[*/") != 0)
						html.push("/*<![CDATA[*/", root.data, "/*]]>*/");
					else
						html.push(root.data);
				} else
					html.push(DlHtmlUtils.htmlEncode(root.data));
				break;
			    case 8: // COMMENT
				html.push("<!--", root.data, "-->");
				break;
			}
		};
		rec(root, outputRoot);
		return html.join("");
	}

};
