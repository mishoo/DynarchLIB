// @require container.js

(function(){

	eval(DynarchDomUtils.importCommonVars());

	var BASE = DlGrid.inherits(DlContainer);
	function DlGrid(args) {
		if (args) {
			args.tagName = "table";
			BASE.constructor.call(this, args);
		}
	};

	var D = DlGrid;
	var P = D.prototype;

	P._createElement = function() {
		BASE._createElement.call(this);
		CE("tbody", null, null, this.getElement());
	};

	P.getContentElement = function() {
		return this.getElement().firstChild;
	};

	P.addRow = function() {
		return new DlGridRow({ parent: this });
	};

	P.addCell = function(row) {
		return new DlGridCell({ parent: row });
	};

	P.addSeparator = function(span) {
		if (span == null)
			span = this.getContentElement().rows[0].cells.length;
		CE("div", null, { innerHTML: "&nbsp;" },
		   CE("td", null, { colSpan: span },
		      CE("tr", null, { className: "DlGrid-RowSeparator" },
			 this.getContentElement())));
	};

	window.DlGrid = D;

})();

(function(){

	var BASE = DlGridRow.inherits(DlContainer);
	function DlGridRow(args) {
		if (args) {
			args.tagName = "tr";
			BASE.constructor.call(this, args);
		}
	};

	window.DlGridRow = DlGridRow;

})();

(function(){

	var BASE = DlGridCell.inherits(DlContainer);
	function DlGridCell(args) {
		if (args) {
			args.tagName = "td";
			BASE.constructor.call(this, args);
		}
	};

	var D = DlGridCell;
	var P = D.prototype;

	P._createElement = function() {
		BASE._createElement.call(this);
	};

	window.DlGridCell = D;

})();
