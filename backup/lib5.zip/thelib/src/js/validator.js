function DlValidator(callback) {
	if (callback) {
		this._callback = callback;
		this._args = arguments.length > 1
			? Dynarch.makeArray(arguments, 1)
			: null;
	}
};

DlValidatorException.MISMATCH = 1;
DlValidatorException.TOO_SMALL = 2;
DlValidatorException.TOO_BIG = 3;

(function(){

	var D = DlValidator;
	var P = D.prototype;

	P.setArgs = function(args) {
		this._args = args;
	};

	P.ok = function(data) {
		if (typeof this._lastData != "undefined" && this._lastData === data)
			return true;
		try {
			var args = [ data ].concat(this._args || Dynarch.makeArray(arguments, 1));
			var val = this._callback.apply(this, args);
			this._lastData = data;
			this._lastValue = val;
			return true;
		} catch(ex) {
			if (ex instanceof DlValidatorException) {
				this._error = ex;
				return false;
			} else
				throw ex;
		}
	};

	P.getLastVal = function() { return this._lastValue; };
	P.getLastData = function() { return this._lastData; };
	P.getError = function() { return this._error; };

	DlValidator.Number = function(data, minVal, maxVal, integer, decimals) {
		data = data.replace(/\s/g, "");
		var n = new Number(data);
		if (isNaN(n))
			throw new DlValidatorException("Value must be numeric",
						       DlValidatorException.MISMATCH);
		if (integer && n != Math.round(n))
			throw new DlValidatorException("Value must be an integer",
						       DlValidatorException.MISMATCH);
		if (minVal != null && n < minVal)
			throw new DlValidatorException("Value must be bigger than " + minVal,
						       DlValidatorException.TOO_SMALL);
		if (maxVal != null && n > maxVal)
			throw new DlValidatorException("Value must be smaller than " + maxVal,
						       DlValidatorException.TOO_BIG);
		if (decimals)
			n = n.decimal(decimals);
		return n;
	};

})();
