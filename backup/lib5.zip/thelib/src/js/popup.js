// @require container.js

// COMMENTED OUT FOR NOW
(function(){

	var DEFAULT_EVENTS = [ "onBeforePopup", "onPopup", "onHide" ];
	var BASE = DlPopup.inherits(DlContainer);
	var DEFAULT_ARGS = {
		_level  : [ "level"  , 0 ],
		_sticky : [ "sticky" , false ]
	};
	var POPUPS = {};
	var ALL_POPUPS = {};

	eval(DynarchDomUtils.importCommonVars());

	function DlPopup(args) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
			this.visible = false;
		}
	};

	// FIXME: this function is known to suck
	DlPopup.get = function(level, nocreate) {
		if (level == null)
			level = 0;
		var type = this.prototype._objectType;
		var pt = POPUPS[type];
		if (!POPUPS[type])
			pt = POPUPS[type] = {};
		var ret = pt[level];
		if (!ret) {
			if (!nocreate)
				ret = pt[level] = new this({ level: level });
			else
				ret = null;
		}
		return ret;
	};

	DlPopup.clearAllPopups = function(except) {
		for (var i in ALL_POPUPS)
			if (!except || !except[i])
				ALL_POPUPS[i].hide();
	};

	var P = DlPopup.prototype;

	P.__patchSubclassPrototype = function() {
		BASE.__patchSubclassPrototype.call(this);
		this.constructor.get = DlPopup.get;
	};

	P.initDOM = function() {
		this.registerEvents(DEFAULT_EVENTS);
		BASE.initDOM.call(this);
	};

	P._createElement = function() {
		var parent = this._parent;
		this._parent = null;
		BASE._createElement.call(this);
		this.parent = parent;
		this.display(false);
		document.body.appendChild(this.getElement());
		this.zIndex(1000);
	};

	function onPopup() {
		if (!this._parentPopup)
			ALL_POPUPS[this.id] = this;
	};
	function onHide() {
		if (ALL_POPUPS[this.id])
			delete ALL_POPUPS[this.id];
		if (this._childPopup)
			this._childPopup.hide();
	};
// 	function onMouseEnter() {};
// 	function onMouseLeave() {};

	var have_doc_listener = false;
	function global_onMouseDown(ev) {
		var obj = ev.getObject();
		var except = {};
		while (obj && !(obj instanceof DlPopup)) {
			if (obj.currentPopup)
				except[obj.currentPopup.id] = true;
			obj = obj.parent;
		}
		if (obj) {
			var top = obj.getToplevelPopup();
			if (!top)
				top = obj;
			except[top.id] = true;
		}
		DlPopup.clearAllPopups(except);
	};

	P._setListeners = function() {
		BASE._setListeners.call(this);
		this.addEventListener("onPopup", onPopup);
		this.addEventListener("onHide", onHide);
// 		this.addEventListener("onMouseEnter", onMouseEnter);
// 		this.addEventListener("onMouseLeave", onMouseLeave);
 		if (!have_doc_listener) {
 			have_doc_listener = true;
			DlEvent.captureGlobal("onMouseDown", global_onMouseDown);
		}
	};

	function _do_popup(content, anchor, align, pos, args) {
		this.applyHooks("onBeforePopup", args);
		this._timer = null;
		if (content != null)
			this.setContent(content);
		this.callHooks("onPopup");
		this.showAt(anchor, align, pos);
	};

	function _do_hide(args) {
		this._timer = null;
		if (this.visible) {
			this.callHooks("onHide");
			this.display(false);
			this.visible = false;
		}
	};

	P.popup = function(timeout, content, anchor, align, pos) {
		this.cancel();
		var args = Dynarch.makeArray(arguments, 5);
		if (!timeout)
			_do_popup.call(this, content, anchor, align, pos, args);
		else
			this._timer = setTimeout(Dynarch.makeClosure(_do_popup, this, content, anchor, align, pos, args),
						 timeout);
	};

	P.hide = function(timeout) {
		this.cancel();
		var args = Dynarch.makeArray(arguments, 1);
		if (!timeout)
			_do_hide.call(this, args);
		else
			this._timer = setTimeout(Dynarch.makeClosure(_do_hide, this, args),
						 timeout);
	};

	P.cancel = function() {
		if (this._timer)
			clearTimeout(this._timer);
	};

	P.showAt = function(anchor, align, mousePos) {
		var origpos, p, sa;
		if (align == "mouse") {
			if (mousePos == null)
				mousePos = Dynarch.makeCopy(DlEvent.latestEvent.pos);
			origpos = mousePos;
			// FIXME: broken
			if (this._mouseDiff) {
				origpos.x += this._mouseDiff.x;
				origpos.y += this._mouseDiff.y;
			}
			align = {
				prefer : "__",
				fallX1 : "_R",
				fallX2 : "_L",
				fallY1 : "B_",
				fallY2 : "T_"
			};
		} else {
			origpos = DynarchDomUtils.getPos(anchor);
		}
		sa = DynarchDomUtils.getOuterSize(anchor);

		p = Dynarch.makeCopy(origpos);
		this.visibility(false);
		this.setPosition({ x: 0, y: 0 });
		this.display(true);

		var tmp,
			ws = DynarchDomUtils.getWindowSize(),
			r  = { x: 0, y: 0, w: ws.x, h: ws.y };

		this._doAlign(align.prefer, p, sa);
		tmp = this.checkXPos(p, r);
		if (tmp != 0) {
			p.x = origpos.x;
			this._doAlign(tmp < 0 ? align.fallX1 : align.fallX2, p, sa);
		}

		tmp = this.checkYPos(p, r);
		if (tmp != 0) {
			p.y = origpos.y;
			this._doAlign(tmp < 0 ? align.fallY1 : align.fallY2, p, sa);
		}

		this.setPosition(p);
		if (this._parentPopup) {
			var ZI = this._parentPopup.zIndex() + 1;
			this.zIndex(ZI);
		}

		this.visibility(true);
		this.visible = true;
	};

	P._doAlign = function(align, p, sa) {
		var
			sp     = this.getSize(),
			valign = align.substr(0, 1),
			halign = "";

		if (align.length > 1)
			halign = align.substr(1, 1);

		switch (valign) {
		    case "T": p.y -= sp.y; break;
		    case "B": p.y += sa.y; break;
		    case "C":
		    case "c": p.y += (sa.y - sp.y) / 2; break;
		    case "t": p.y += sa.y - sp.y; break;
		    case "b": break; // already there
		}
		switch (halign) {
		    case "L": p.x -= sp.x; break;
		    case "R": p.x += sa.x; break;
		    case "C":
		    case "c": p.x += (sa.x - sp.x) / 2; break;
		    case "l": p.x += sa.x - sp.x; break;
		    case "r": break; // already there
		}
	};

	P.checkXPos = function(p, rect) {
		if (p.x < rect.x)
			return p.x - rect.x;
		var s = this.getSize();
		var d = p.x + s.x - rect.x - rect.w;
		return d > 0 ? d : 0;
	};

	P.checkYPos = function(p, rect) {
		if (p.y < rect.y)
			return p.y - rect.y;
		var s = this.getSize();
		var d = p.y + s.y - rect.y - rect.h;
		return d > 0 ? d : 0;
	};

	P.attachToPopup = function(popup) {
		this._parentPopup = popup;
		popup._childPopup = this;
	};

	P.detachPopup = function() {
		if (this._parentPopup)
			this._parentPopup._childPopup = null;
		this._parentPopup = null;
	};

	P.getToplevelPopup = function() {
		var p = this;
		while (p._parentPopup)
			p = p._parentPopup;
		return p;
	};

	window.DlPopup = DlPopup;

})();
