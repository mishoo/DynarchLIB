// @require jslib.js

var DlKeyboard = {

	BACKSPACE    :  8,
	TAB          :  9,
	ENTER        : 13,
	ESCAPE       : 27,
	DELETE       : 46,
	PAGE_UP      : 33,
	PAGE_DOWN    : 34,
	END          : 35,
	HOME         : 36,
	ARROW_LEFT   : 37,
	ARROW_UP     : 38,
	ARROW_RIGHT  : 39,
	ARROW_DOWN   : 40,

	parseKey : function(key) {
		var o = {};
		if (/^([a-z]+)\s+\x27(.)\x27$/i.test(key)) {
			o[RegExp.$1.toUpperCase()] = true;
			o.key = RegExp.$2;
		} else if (/^([a-z]+)-([a-z]+)\s+\x27(.)\x27$/i.test(key)) {
			o[RegExp.$1.toUpperCase()] = true;
			o[RegExp.$2.toUpperCase()] = true;
			o.key = RegExp.$3;
		} else if (/^([a-z]+)-([a-z]+)-([a-z]+)\s+\x27(.)\x27$/i.test(key)) {
			o[RegExp.$1.toUpperCase()] = true;
			o[RegExp.$2.toUpperCase()] = true;
			o[RegExp.$3.toUpperCase()] = true;
			o.key = RegExp.$4;
		}
		return o;
	}

};
