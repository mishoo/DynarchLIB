// @require eventlistener.js

DlAnimation.inherits(DlEventListener);
function DlAnimation(length, fps) {
	DlEventListener.call(this);
	this.registerEvents([ "onStart", "onStop", "onPause", "onUpdate" ]);
	this.accel = false;
	this.timer = 0;
	this.reset(length, fps);
};

(function() {

	var
		cos   = Math.cos,
		sin   = Math.sin,
		round = Math.round;

	function finished(o) {
		return o.i < 0 || o.i > o.length;
	};

	function update(o) {
		if (!finished(o)) {
			o.pos = o.accel ? (1 - cos(o.rad_pos)) : sin(o.rad_pos);
			o.rad_pos += o.rad_step;
			--o.i;
			o.callHooks("onUpdate");
		} else {
			o.pos = 1;
			o.callHooks("onUpdate");
			o.stop();
		}
	};

	var P = {
		comp: function(start, stop) {
			return start + (stop - start) * this.pos;
		},
		compInt: function(start, stop) {
			return round(start + (stop - start) * this.pos);
		},
		reset: function(length, fps) {
			this.i = this.length = length - 1;
			this.pause(true);
			this.speed = round(1000 / fps);
			this.pos = this.rad_pos = 0;
			this.rad_step = Math.PI / (2 * this.length);
			return this;
		},
		start: function() {
			var self = this;
			function U() { update(self); };
			this.pause(true);
			U();
			this.timer = setInterval(U, this.speed);
			this.callHooks("onStart");
			return this;
		},
		stop: function() {
			this.pause(true);
			this.callHooks("onStop");
			this.reset();
			return this;
		},
		pause: function(nohooks) {
			if (!nohooks)
				this.callHooks("onPause");
			if (this.timer)
				clearInterval(this.timer);
			this.timer = 0;
			return this;
		}
	};
	Dynarch.merge(DlAnimation.prototype, P);

})();
