// @require checkbox.js

(function(){

	var
		CLS = { active    : "DlRadioButton-active",
			hover     : "DlRadioButton-hover",
			checked   : "DlRadioButton-1",
			unchecked : "DlRadioButton-0",
			empty     : "DlRadioButton-empty",
			disabled  : "DlRadioButton-disabled"
		};

	var DEFAULT_ARGS = {
		_groupId   : [ "group"     , 0 ],
		_classes   : [ "classes"   , CLS ]
	};

	var BASE = DlRadioButton.inherits(DlCheckbox);
	function DlRadioButton(args) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
		}
	};

	var P = DlRadioButton.prototype;

	P._className.remove("DlCheckbox");

	// make sure this widget will always be checked upon click, rather than
	// toggled (as in DlCheckbox)
	P._onClick = function(ev) { this.checked(true); };

	window.DlRadioButton = DlRadioButton;

})();
