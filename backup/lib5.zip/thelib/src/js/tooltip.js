// @require popup.js

DlTooltip.inherits(DlPopup);
function DlTooltip(args) {
	if (args) {
		args.zIndex = 2000;
		DlPopup.call(this, args);
		this._mouseDiff = { x: 6, y: 10 };
	}
};
