// @require popup.js
// @require hbox.js
// @require vbox.js

// WARNING: this is all hairy stuff.  Don't mess with it.

function DlMenuBase(args) {
	if (this._isMenuBase)
		return;
	this._isMenuBase = true;
	this._items = [];

	var self = this;
	function onNamedItemSelect() {
		DlPopup.clearAllPopups();
		var me = this;
		setTimeout(function() {
			self.applyHooks("onSelect", [ me.name, me ]);
		}, 1);
	};

	// whatever container we are in, we patch the appendWidget function
	// (which will presumably used to append items) in order to keep an
	// array of menu items.
	var orig_appendWidget = this.appendWidget;
	this.appendWidget = function(w) {
		if (w instanceof DlMenuItem) {
			this._items.push(w);
			if (w.name)
				w.addEventListener("onSelect", onNamedItemSelect);
		}
		orig_appendWidget.apply(this, Dynarch.makeArray(arguments));
	};

	if (this instanceof DlHMenu) {
		this._popupAlign = {
			prefer: "Br",
			fallX1: "__",
			fallX2: "_l",
			fallY1: "__",
			fallY2: "T_"
		};
	} else {
		this._popupAlign = {
			prefer: "bR",
			fallX1: "__",
			fallX2: "_L",
			fallY1: "__",
			fallY2: "t_"
		};
	}

	this.getPopup = function() {
		return DlPopupMenu.get(this.getLevel());
	};

	this.getLevel = function() {
		var lvl = 0;
		var m = this;
		while (m.parentMenu) {
			lvl++;
			m = m.parentMenu;
		}
		return lvl;
	};

// 	var foo = 0;
// 	this.debug = function() {
// 		var txt = [ foo++ ];
// 		var m = this;
// 		while (m) {
// 			txt.unshift(m.id);
// 			m = m.parentMenu;
// 		}
// 		window.status = txt.join(" => ");
// 	};
};

(function() {

	var BASE = DlPopupMenu.inherits(DlPopup);
	function DlPopupMenu(args) {
		if (args) {
			BASE.constructor.call(this, args);
			this._mouseDiff = { x: 2, y: 1 }; // for context menus
		}
	};

	var P = DlPopupMenu.prototype;

	function onBeforePopup(args) {
		this.callHooks("onHide");
		this.args = args;
		var menu = args.content || args.item.getMenu();
		var pm = menu.parentMenu = args.parentMenu || args.item.parentMenu;
		if (pm) {
			pm._popupVisible = true;
			pm = menu.parentMenu.parentMenu;
			if (pm)
				this.attachToPopup(pm.getPopup());
			else
				this.detachPopup();
		}
		args.item.currentPopup = this;
		args.item._popupVisible = true;
		this.setContent(menu);
	};

	function onHide() {
		if (this.args) {
			var pm = this.args.item.parentMenu;
			if (pm)
				pm._popupVisible = false;
			this.args.item.currentPopup = null;
			this.args.item._popupVisible = false;
			this.args = null;
		}
	};

	function onMouseEnter() {
		this.cancel();
		if (this.args && this.args.item) {
			try {
				this.args.item.activateSubmenu(true);
				onMouseEnter.call(this.args.item.parentMenu.parentMenu.getPopup());
			} catch(ex) {};
		}
	};

	function onMouseLeave(ev) {
		if (this.args && this.args.item) {
 			try {
				this.args.item.activateSubmenu(false);
 				// onMouseLeave.call(this.args.item.parentMenu.parentMenu.getPopup());
 			} catch(ex) {};
		}
	};

	P._setListeners = function() {
		BASE._setListeners.call(this);
		this.addEventListener("onMouseEnter", onMouseEnter);
		this.addEventListener("onMouseLeave", onMouseLeave);
 		this.addEventListener("onHide", onMouseLeave);
		this.addEventListener("onBeforePopup", onBeforePopup);
		this.addEventListener("onHide", onHide);
	};

	P.correctPos = function() {
	};

	window.DlPopupMenu = DlPopupMenu;

})();

/* DlHMenu */

DlHMenu.inherits(DlHbox);
function DlHMenu(args) {
	if (args) {
		DlHbox.call(this, args);
		DlMenuBase.call(this, args);
	}
};

DlHMenu.prototype.initDOM = function() {
	this.registerEvents([ "onSelect" ]);
	DlHbox.prototype.initDOM.call(this);
};

/* DlVMenu */

DlVMenu.inherits(DlVbox);
function DlVMenu(args) {
	if (args) {
		DlVbox.call(this, args);
		DlMenuBase.call(this, args);
	}
};

DlVMenu.prototype.initDOM = function() {
	this.registerEvents([ "onSelect" ]);
	DlVbox.prototype.initDOM.call(this);
};

(function() {

	var DEFAULT_ARGS = {
		label      : [ "label",     "DlMenuItem" ],
		_iconClass : [ "iconClass", null ],
		parentMenu : [ "menu",      null ],
		name       : [ "name",      null ]
	};

	var BASE = DlMenuItem.inherits(DlContainer);
	function DlMenuItem(args) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
			if (!this.parentMenu)
				this.parentMenu = this.parent;
		}
	};

	var P = DlMenuItem.prototype;

	P._inBaseMenu = function() {
		return !this.parentMenu.parentMenu;
	};

	P.initDOM = function() {
		this.registerEvents([ "onSelect" ]);
		BASE.initDOM.call(this);
	};

	P._createElement = function() {
		BASE._createElement.call(this);
		var el = this.getElement();
		el.innerHTML = [ '<div class="div1"><div class="div2"><div class="div3">',
				 '</div></div></div>' ].join();
		this.setIconClass(this._iconClass);
		this._iconClass = null;
		this.setUnselectable();
		if (this.label)
			this.setContent(this.label);
	};

	P.getContentElement = function() {
		return this.getElement().firstChild.firstChild.firstChild;
	};

	P.setIconClass = DlButton.prototype.setIconClass;	// ALIAS

	P.getPopup = function() {
		return this.parentMenu.getPopup();
	};

	function onMouseEnter(ev) {
		this.addClass("DlMenuItem-hover");
		this.delClass("DlMenuItem-active");
		var base = this._inBaseMenu();
 		if (!base || this.parentMenu._popupVisible)
			this._popupMenu(base ? 0 : 250);
	};

	function onMouseLeave() {
		this.delClass("DlMenuItem-hover");
		this.delClass("DlMenuItem-active");
		var base = this._inBaseMenu();
		if (!base)
			this.getPopup().hide(100);
	};

	function onMouseUp() {
		this.delClass("DlMenuItem-active");
		this.callHooks("onSelect");
	};

	function onMouseDown() {
		this.addClass("DlMenuItem-active");
		this._popupMenu(0);
	};

	P._popupMenu = function(timeout) {
		if (this._menu && !this._popupVisible) {
			var pm = this.parentMenu;
			var p = this.getPopup();
			p.popup(timeout, null, this.getElement(), pm._popupAlign, null, { item: this });
		} else if (!this._menu) {
			this.getPopup().hide(100);
		}
	};

	P._setListeners = function() {
		BASE._setListeners.call(this);
		this.addEventListener("onMouseEnter", onMouseEnter);
		this.addEventListener("onMouseLeave", onMouseLeave);
		this.addEventListener("onMouseDown", onMouseDown);
		this.addEventListener("onMouseUp", onMouseUp);
	};

	P.getMenu = function() {
		var menu = this._menu;
// 		if (typeof menu == "function")
// 			menu = menu();
		return menu;
	};

	P.setMenu = function(menu) {
		this._menu = menu;
		this.condClass(menu, "DlMenuItem-withPopup");
	};

	P.activateSubmenu = function(act) {
		this.condClass(act, "DlMenuItem-active");
		//this.condClass(act, "DlMenuItem-hover");
	};

	window.DlMenuItem = DlMenuItem;

})();
