// @require widget.js
// @require htmlutils.js
// @require keyboard.js

(function(){

	eval(DynarchDomUtils.importCommonVars());

	var DEFAULT_EVENTS = [ "onUpdate" ];

	var FORWARD_EVENTS = [ "mouseover", "mouseout", "mousemove", "mousedown", "mouseup", "click",
			       "keydown", "keyup", "keypress", "focus", "blur" ];

	var INIT_HTML =
		'<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" ' +
		'<html>' +
		'<head><title>DynarchLIB Rich Text Editor</title></head>' +
		'<body></body></html>';

	var BASE = DlRteFrame.inherits(DlWidget);
	function DlRteFrame(args) {
		if (args) {
			BASE.constructor.call(this, args);
		}
	};

	var D = DlRteFrame;
	var P = D.prototype;

	D.COMMANDS = {
		"backcolor"             : { id: is_ie ? "backcolor" : "hilitecolor" },
		"forecolor"             : { id: "forecolor" },
		"bold"                  : { id: "bold"                   , key: "CTRL 'B'" },
		"italic"                : { id: "italic"                 , key: "CTRL 'I'" },
		"underline"             : { id: "underline"              , key: "CTRL 'U'" },
		"strike"                : { id: "strikethrough"          , key: "CTRL '-'" },
		"subscript"             : { id: "subscript" },
		"superscript"           : { id: "superscript" },
		"removeformat"          : { id: "removeformat"           , key: "ALT-CTRL '0'" },
		"justifyleft"           : { id: "justifyleft"            , key: "ALT-CTRL 'l'" },
		"justifyright"          : { id: "justifyright"           , key: "ALT-CTRL 'r'" },
		"justifycenter"         : { id: "justifycenter"          , key: "ALT-CTRL 'e'" },
		"justifyfull"           : { id: "justifyfull"            , key: "ALT-CTRL 'j'" },
		"orderedlist"           : { id: "insertorderedlist"      , key: "ALT-CTRL 'o'" },
		"unorderedlist"         : { id: "insertunorderedlist"    , key: "ALT-CTRL-SHIFT 'o'" },
		"unorderedlist1"        : { id: "insertunorderedlist"    , key: "ALT-CTRL 'u'" },
		"indent"                : { id: "indent"                 , key: "CTRL '.'" },
		"outdent"               : { id: "outdent"                , key: "CTRL ','" },
		"undo"                  : { id: "undo" },
		"redo"                  : { id: "redo" },
		"<hr>"                  : { id: "inserthorizontalrule"   , key: "CTRL ' '" },
		"<h1>"                  : { id: "formatblock"            , key: "CTRL '1'", arg: "h1" },
		"<h2>"                  : { id: "formatblock"            , key: "CTRL '2'", arg: "h2" },
		"<h3>"                  : { id: "formatblock"            , key: "CTRL '3'", arg: "h3" },
		"<h4>"                  : { id: "formatblock"            , key: "CTRL '4'", arg: "h4" },
		"<h5>"                  : { id: "formatblock"            , key: "CTRL '5'", arg: "h5" },
		"<h6>"                  : { id: "formatblock"            , key: "CTRL '6'", arg: "h6" },
		"<p>"                   : { id: "formatblock"            , key: "CTRL 'n'", arg: "p" },
		"<pre>"                 : { id: "formatblock"            , key: "CTRL-ALT 'n'", arg: "pre" },

		// tmp
		"showHtml"              : { id: "showHtml"               , key: "CTRL-ALT-SHIFT 'h'" }
	};

	P.execCommand = function(cmd, param) {
		var ret;
		if (D.COMMANDS[cmd]) {
			cmd = D.COMMANDS[cmd];
			if (typeof param == "undefined")
				param = cmd.arg || "";
			cmd = cmd.id;
		}
		if (is_ie && cmd == "formatblock")
			param = "<" + param + ">";
		switch (cmd) {
		    case "showHtml":
			try {
				alert(DlHtmlUtils.getHTML(this.getIframeBody(), false));
			} catch(ex) {
				alert("ERROR: " + ex);
			}
			break;

		    default:
			ret = this.getIframeDoc().execCommand(cmd, false, param);
		}
		this.focus();
		return ret;
	};

	P._setListeners = function() {
		this.registerEvents(DEFAULT_EVENTS);
		BASE._setListeners.call(this);
		this.addEventListener(is_ie ? "onKeyDown" : "onKeyPress", onKeypress);
	};

	P._createElement = function() {
		BASE._createElement.call(this);
		var iframe = CE("iframe", null,
			{ frameBorder: 0, marginHeight: 0, marginWidth: 0,
			  src : is_ie ? "javascript:'';" : "about:blank" },
				this.getElement());
		this._hasFrameEvents = false;
		var keymap = this._keymap = [];
		for (var i in D.COMMANDS) {
			var cmd = D.COMMANDS[i];
			if (cmd.key)
				keymap.push([ DlKeyboard.parseKey(cmd.key), i ]);
		}
	};

	P.setOuterSize = function(s) {
		var pb1 = DOM.getPaddingAndBorder(this.getElement());
		var pb2 = DOM.getPaddingAndBorder(this.getContentElement());
		this.setInnerSize({ x: s.x - pb1.x - pb2.x, y: s.y - pb1.y - pb2.y });
	};

	P.getIframeElement = function() {
		return this.getElement().firstChild;
	};

	P.getContentElement = P.getIframeElement; // ALIAS

	P.getIframeWin = function() {
		return this.getIframeElement().contentWindow;
	};

	P.getIframeDoc = function() {
		return this.getIframeWin().document;
	};

	P.getIframeBody = function() {
		return this.getIframeDoc().body;
	};

	P.initDesignMode = function(callback) {
		var doc = this.getIframeDoc();
		doc.open();
		doc.write(INIT_HTML);
		doc.close();
		doc.designMode = "on";
		if (!this._hasFrameEvents)
			setTimeout(Dynarch.makeClosure(registerEvents, this, callback), 5);
	};

	P.setHTML = function(html) {
		if (html instanceof Array)
			html = html.join();
		this.getIframeBody().innerHTML = html.trim();
	};

	P.focus = function() {
		this.getIframeWin().focus();
	};

	P.loadStyle = function(css) {
		var doc = this.getIframeDoc();
		var id = css.replace(/\x2f/g, "_");
		if (!doc.getElementById(id)) {
			var head = doc.getElementsByTagName("head")[0];
			var link = doc.createElement("link");
			link.type = "text/css";
			link.rel = "stylesheet";
			link.href = css;
			link.id = id;
			head.appendChild(link);
			// The Magic Gecko Hack
			link.disabled = true;
			link.disabled = false;
		}
	};

	P.createRange = function() {
		return is_ie
			? this.getIframeBody().createTextRange()
			: this.getIframeDoc().createRange();
	};

	P.getRange = function(sel) {
		if (sel == null)
			sel = this.getSelection();
		return is_ie
			? sel.createRange()
			: sel.getRangeAt(0);
	};

	P.getSelection = function() {
		return is_ie
			? this.getIframeDoc().selection
			: this.getIframeWin().getSelection();
	};

	P.select = function(range) {
		if (is_ie)
			range.select();
		else {
			var sel = this.getSelection();
			sel.removeAllRanges();
			sel.addRange(range);
		}
	};

	// FIXME: this has been copied from HTMLArea almost literally; it might
	// not be as good as we want.
	P.getParentElement = function() {
		var sel = this.getSelection();
		var range = this.getRange(sel);
		if (is_ie) {
			switch (sel.type) {
			    case "Text":
			    case "None":
				return range.parentElement();
			    case "Control":
				return range.item(0);
			    default:
				// return this._doc.body;
				return null;
			}
		} else try {
			var p = range.commonAncestorContainer;
			if (!range.collapsed && range.startContainer == range.endContainer &&
			    range.startOffset - range.endOffset <= 1 && range.startContainer.hasChildNodes())
				p = range.startContainer.childNodes[range.startOffset];
			while (p.nodeType == 3)
				p = p.parentNode;
			return p;
		} catch(ex) {
			return null;
		}
	};

	P.getAllAncestors = function() {
		var p = this.getParentElement();
		if (p && p.nodeType == 1)
			p = this.getParentElement();
		var body = this.getIframeBody();
		var a = [];
		while (p && p !== body && p.nodeType == 1) {
			a.push(p);
			p = p.parentNode;
		}
		a.push(body);
		return a;
	};

	P.getAncestorsHash = function() {
		var p = this.getAllAncestors(), el, i, tn, pnodes = {};
		p.foreach(function(el) {
			tn = el.tagName.toLowerCase();
			if (!pnodes[tn])
				pnodes[tn] = el;
		});
		return pnodes;
	};

	function onKeypress(ev) {
		this._keymap.r_foreach(function(kc) {
			var k = kc[0], cmd = kc[1],
				on = ( ((!k.CTRL  && !ev.ctrlKey)   ||  (k.CTRL    && ev.ctrlKey)) &&
				       ((!k.ALT   && !ev.altKey)    ||  (k.ALT     && ev.altKey)) &&
				       ((!k.SHIFT && !ev.shiftKey)  ||  (k.SHIFT   && ev.shiftKey)) &&
				       ev.keyStr.toUpperCase() == k.key.toUpperCase() );
			if (on) {
				this.execCommand(cmd);
				throw new DlExStopFrameEvent;
			}
		}, this);
	};

	function callUpdateHooks(dev, ev) {
		this.callHooks("onUpdate");
		this._timerUpdate = null;
	};

	function eventProxy(ev) {
		ev || (ev = this.getIframeWin().event);
		var dev = new DlEvent(ev);
		dev.origTarget = dev.target;
		var p1 = dev.origPos = dev.pos;
		var p2 = DOM.getPos(this.getIframeElement());
		dev.pos = { x: p1.x + p2.x, y: p1.y + p2.y };
		// dev.origRelatedTarget = dev.relatedTarget;
		dev.target = this.getElement();
		try {
			DlEvent._genericEventHandler(dev);
		} catch(ex) {
			if (ex instanceof DlExStopFrameEvent)
				DOM.stopEvent(ev);
		}
		if (/onMouseDown|onMouseUp|onKey/.test(dev.dl_type)) {
			if (this._timerUpdate)
				clearTimeout(this._timerUpdate);
			this._timerUpdate = setTimeout(Dynarch.makeClosure(callUpdateHooks, this, dev, ev), 25);
		}
	};

	function registerEvents(callback) {
		var doc = this.getIframeDoc();
		this._hasFrameEvents = true;
		DOM.addEvents(doc, FORWARD_EVENTS,
			      Dynarch.makeClosure(eventProxy, this));
		if (callback)
			callback();
	};

	window.DlRteFrame = D;

})();
