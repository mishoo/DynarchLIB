// @require widget.js
// @require radiogroup.js

(function() {

	var TYPE = {
		STANDARD : 1,
		TWOSTATE : 2
	};

	var DEFAULT_ARGS = {
		_label     : [ "label"     , "" ],
		_classes   : [ "classes"   , {} ],
		_checked   : [ "checked"   , false ],
		_groupId   : [ "group"     , null ],
		_btnType   : [ "type"      , TYPE.STANDARD ],
		_noCapture : [ "noCapture" , false ]
	};

	var DEFAULT_LISTENERS = [ "onMouseEnter",
				  "onMouseLeave",
				  "onMouseDown",
				  "onMouseUp",
				  "onUpdateLabel",
				  "onClick",
				  "onCheck",
				  "onChange",
				  "onDisabled"
		];

	eval(DynarchDomUtils.importCommonVars());

	var BASE = DlAbstractButton.inherits(DlWidget);
	function DlAbstractButton(args, classes) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
			if (this._groupId != null) {
				if (typeof this._groupId == "object") {
					this._group = this._groupId;
					this._groupId = this._group.id;
				} else {
					this._group = DlRadioGroup.get(this._groupId);
					this._group.addWidget(this);
				}
			}
		}
	};

	DlAbstractButton.TYPE = TYPE;

	var P = DlAbstractButton.prototype;

	var CAPTURE_EVENTS = [ "onMouseEnter", "onMouseLeave", "onMouseUp" ];

	P._onMouseEnter = function(ev) {
		var obj = ev.getObject();
		if (this._capture && obj !== this) {
			obj._ev_mouseInside = true;
			throw new DlExStopEventBubbling();
		}
		var el = this.getElement();
		AC(el, this._classes.hover);
		if (this._capture)
			AC(el, this._classes.active);
	};

	P._onMouseLeave = function(ev) {
		if (ev) {
			var obj = ev.getObject();
			if (this._capture && obj !== this) {
				obj._ev_mouseInside = false;
				throw new DlExStopEventBubbling();
			}
		}
		var el = this.getElement();
		DC(el, this._classes.active);
		if (!this._capture)
			DC(el, this._classes.hover);
	};

	P._onMouseDown = function(ev) {
		if (ev.button === 0) {
			var el = this.getElement();
			AC(el, this._classes.hover);
			AC(el, this._classes.active);
			if (!this._noCapture)
				this._capture = DlEvent.captureEvents(this, CAPTURE_EVENTS);
		}
	};

	P._onMouseUp = function(ev) {
		var el = this.getElement();
		DC(el, this._classes.active);
		CC(el, ev.getObject() === this, this._classes.hover);
		if (this._capture) {
			DlEvent.releaseCapture(this._capture);
			this._capture = null;
		}
	};

	P._onUpdateLabel = function() {
		var el = this.getElement();
		if (!/\S/.test(this._label))
			AC(el, this._classes.empty);
		else
			DC(el, this._classes.empty);
	};

	P._onClick = function() {
		if (this._btnType == TYPE.TWOSTATE)
			this.toggle();
	};

	P.disabled = function(v, force) {
		if (v != null && v) {
			DC(this.getElement(), this._classes.hover);
			DC(this.getElement(), this._classes.active);
		}
		return BASE.disabled.call(this, v, force);
	};

	P._onChange = function() {
		if (this._group != null)
			this._group.applyHooks("onChange", [ this ]);
	};

	P._onCheck = Dynarch.noop;

	P._onDisabled = function(v) {
		CC(this.getElement(), v, this._classes.disabled);
		if (v && this._capture) {
			DlEvent.releaseCapture(this._capture);
			this._capture = null;
		}
	};

	P.initDOM = function() {
		this.registerEvents([ "onCheck", "onUncheck", "onChange", "onUpdateLabel" ]);
		BASE.initDOM.call(this);
		this.setUnselectable();
	};

	P._createElement = function() {
		BASE._createElement.call(this);
		this._createLabelElement();
		this.label(this._label, true);
		this._updateState();
		this.addClass("DlWidget-3D");
	};

	P._setListeners = function() {
		BASE._setListeners.call(this);
		DEFAULT_LISTENERS.r_foreach(function(ev) {
			this.addEventListener(ev, this["_"+ev]);
		}, this);
	};

	P._createLabelElement = Dynarch.noop;

	P.label = function(label, force) {
		if (label != null && (force || label !== this._label)) {
			this._label = label;
			this.setContent(this._label);
			this.applyHooks("onUpdateLabel", [ this._label ]);
		}
		return this._label;
	};

	/* two-state button stuff */

	P.group = function() {
		return this._group;
	};

	P._checkTwoState = function(nothrow) {
		var cond = this._btnType != TYPE.TWOSTATE;
		if (cond && !nothrow)
			throw new DlExInvalidOperation("This operation is only available for a TWOSTATE button");
		return !cond;
	};

	P._updateState = function() {
		if (this._checkTwoState(true)) {
			var c = this._classes;
			CC(this.getElement(), this._checked, c.checked, c.unchecked);
		}
	};

	P.checked = function(checked, nohooks) {
		this._checkTwoState();
		if (checked != null) {
			var diff = !nohooks && (this._checked !== checked);
			this._checked = checked;
			this._updateState();
			if (diff) {
				this.callHooks("onChange");
				this.callHooks(this._checked ? "onCheck" : "onUncheck");
			}
		}
		return this._checked;
	};

	P.toggle = function(nohooks) {
		this._checkTwoState();
		this.checked(!this._checked, nohooks);
	};

	window.DlAbstractButton = DlAbstractButton;
	window.DlLabel = DlAbstractButton;

})();
