// @require widget.js

(function(){

	/**
	 * EVENT DOCS:
	 *
	 *    onChange -- called when the calendar display has been changed,
	 *    such as when the month/year is changing.  No args.
	 *
	 *    onSelect(cleared, otherMonth, secondClick) -- called when a date
	 *    is selected, but also upon onChange.  Upon onChange the selection
	 *    is cleared, so the "cleared" arg will be true.  "otherMonth" is
	 *    true a date from an adjacent month was clicked.  "secondClick" is
	 *    true when an already selected date was clicked.
	 *
	 */

	var DEFAULT_EVENTS = [ "onSelect", "onChange" ];

	var DEFAULT_ARGS = {
		firstDay       : [ "firstDay"      , Date.getFirstDayOfWeek() ],
		fixedFirstDay  : [ "fixedFirstDay" , true ],
		_weekNumbers   : [ "weekNumbers"   , 0 ],
		date           : [ "date"          , null ],
		selected       : [ "selected"      , true ],
		_navigation    : [ "navigation"    , 2 ],
		_navDisabled   : [ "navDisabled"   , false ],
		_omDisabled    : [ "omDisabled"    , false ]
	};

	var BASE = DlCalendar.inherits(DlWidget);
	function DlCalendar(args) {
		if (args) {
			args.tagName = "table";
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			this._dayNamesOn = -1;
			this._selectedDate = (this.date && this.selected)
				? this.date.getDate() : 0;
			BASE.constructor.call(this, args);
		}
	};

	var P = DlCalendar.prototype;

	// cache some static elements
	{
		var STATIC_CELL = document.createElement("td");
		var STATIC_ROW = document.createElement("tr");
		(7).times(function(){
			STATIC_ROW.appendChild(STATIC_CELL.cloneNode(true));
		});
		var STATIC_HEAD = document.createElement("thead");
		STATIC_HEAD.appendChild(STATIC_ROW.cloneNode(true));
		var STATIC_BODY = document.createElement("tbody");
		(6).times(function(){
			STATIC_BODY.appendChild(STATIC_ROW.cloneNode(true));
		});
	}

	eval(DynarchDomUtils.importCommonVars());

	P._createElement = function() {
		BASE._createElement.call(this);
		var trs, i, tr, td,
			table = this.getElement(),
			tbody = STATIC_BODY.cloneNode(true);
		table.cellSpacing = table.cellPadding = table.border = 0;
		table.appendChild(STATIC_HEAD.cloneNode(true));
		table.appendChild(tbody);
		if (this._weekNumbers) {
			trs = table.getElementsByTagName("tr");
			for (i = trs.length; --i >= 0;) {
				tr = trs[i];
				td = STATIC_CELL.cloneNode(true);
				td.className = "DlCalendar-WeekNumber";
				tr.insertBefore(td, tr.firstChild);
			}
		}
		tr = CE("tr");
		td = CE("td", null, null, tr);
		tr.className = "DlCalendar-Navigation";
		if (this._navigation == 0) {
			td.colSpan = this.getNCols();
			this._makeNavPart(td, 0);
		} else {
			var td1 = CE("td", null, null, tr);
			var td2 = CE("td", null, null, tr);
			if (this._navigation == 1) {
				td1.colSpan = this.getNCols() - 2;
				this._makeNavPart(td1, 0,
						  td, -1,
						  td2, 1);
			} else if (this._navigation == 2) {
				var td3 = CE("td", null, null, tr);
				var td4 = CE("td", null, null, tr);
				td2.colSpan = this.getNCols() - 4;
				this._makeNavPart(td2, 0,
						  td, -2,
						  td1, -1,
						  td3, 1,
						  td4, 2);
			}
		}
		i = table.rows[0];
		i.parentNode.insertBefore(tr, i);
		this.setUnselectable();
	};

	P._makeNavPart = function() {
		var td, type, i;
		for (var i = 0; i < arguments.length; ++i) {
			td = arguments[i++];
			type = arguments[i];
			td._navType = type;
			switch (type) {
			    case -2:
				td.innerHTML = "«";
				td.className = "PrevYear";
				break;
			    case -1:
				td.innerHTML = "‹";
				td.className = "PrevMonth";
				break;
			    case 0:
				td.className = "Month";
				this._monthTD = td;
				break;
			    case 1:
				td.className = "NextMonth";
				td.innerHTML = "›";
				break;
			    case 2:
				td.className = "NextYear";
				td.innerHTML = "»";
				break;
			}
		}
	};

	P.getNCols = function() {
		return this._weekNumbers ? 8 : 7;
	};

	P.getTableElement = function() {
		return this.getElement();
	};

	P._displayDayNames = function() {
		var td,
			dnrow = this.getTableElement().getElementsByTagName("tr")[1],
			i = this._weekNumbers ? 1 : 0,
			j = this.firstDay;
		dnrow.className = "DlCalendar-DayNames";
		while (td = dnrow.cells[i++]) {
			td._firstDay = j % 7;
			td.innerHTML = Date.getDayName(j++, true);
			CC(td, Date.isWeekend(td._firstDay), "WeekEnd");
		}
		this._dayNamesOn = this.firstDay;
		if (this._weekNumbers) {
			td = dnrow.cells[0];
			td.innerHTML = "w";
			td._week = -1;
			td.className = "WeekNumber";
		}
	};

	P._displayCalendar = function() {
		var today = new Date(),
			TY = today.getFullYear(),
			TM = today.getMonth(),
			TD = today.getDate();

		this._selectedTD = null;

		if (this._dayNamesOn != this.firstDay)
			this._displayDayNames();
		var date = new Date(this.date);
		date.setHours(12);
		var month = date.getMonth();
		var mday = date.getDate();
		var year = date.getFullYear();
		var no_days = date.getMonthDays();

		this._monthTD.innerHTML = [ "<b>",
					    Date.getMonthName(month, this._navigation == 2),
					    "</b> ", year ].join();

		// calendar voodoo for computing the first day that would actually be
		// displayed in the calendar, even if it's from the previous month.
		// WARNING: this is magic. ;-)
		date.setDate(1);
		var day1 = (date.getDay() - this.firstDay) % 7;
		if (day1 < 0)
			day1 += 7;
		date.setDate(-day1);
		date.setDate(date.getDate() + 1);

		var row = this.getTableElement().getElementsByTagName("tr")[2];

		for (var i = 0; i < 6; ++i, row = row.nextSibling) {
			row.className = "Dates";
			var cell = row.firstChild;
			if (this._weekNumbers) {
				cell.className = "WeekNumber";
				cell.innerHTML = cell._week = date.getWeekNumber();
				cell = cell.nextSibling;
			}
			var iday;
			for (var j = 0; j < 7; ++j, cell = cell.nextSibling, date.setDate(iday + 1)) {
				var wday = date.getDay();
				cell.className = "";
				cell._iday = iday = date.getDate();
				cell._month = date.getMonth();
				cell._year = date.getFullYear();
				cell._otherMonth = month != cell._month;
				if (cell._otherMonth) {
					cell.className = "OtherMonth";
				} else {
					if (month == TM && iday == TD && TY == cell._year)
						cell.className = "Today";
					if (this._selectedDate == iday)
						this._selectCell(cell);
				}
				if (wday == 0 || wday == 6)
					AC(cell, "WeekEnd");
				cell.innerHTML = iday;
			}
		}
	};

	function getTD(ev) {
		var el = ev.target;
		try {
			while (el && el.tagName.toLowerCase() != "td")
				el = el.parentNode;
		} catch(ex) {
			el = null;
		}
		return el;
	};

	function onMouseOver(ev) {
		this._clearTimer();
		var cell = getTD(ev);
		if (cell) {
			if (this._currentHover) {
				DC(this._currentHover, "hover");
				DC(this._currentHover, "rolling");
				this._currentHover = null;
			}
			if (cell._navType != null && this._navDisabled)
				return;
			if (cell._otherMonth && this._omDisabled)
				return;
			if ((cell._firstDay != null && this.fixedFirstDay)
			    || cell._week != null)
				return;
			AC(cell, "hover");
			this._currentHover = cell;
		}
	};

	function onMouseLeave(ev) {
		this._clearTimer();
		if (this._currentHover) {
			DC(this._currentHover, "hover");
			this._currentHover = null;
		}
	};

	P._navCellClicked = function(cell, timeout) {
		AC(cell, "rolling");
		this._selectedDate = 0;
		switch (cell._navType) {
		    case 0:
			var today = new Date();
			if (this.date.dateEqualsTo(today, true))
				return;
			this.date = today;
			break;
		    case -2:
			this.date.setFullYear(this.date.getFullYear() - 1);
			break;
		    case -1:
			this.date.setMonth(this.date.getMonth() - 1);
			break;
		    case 1:
			this.date.setMonth(this.date.getMonth() + 1);
			break;
		    case 2:
			this.date.setFullYear(this.date.getFullYear() + 1);
			break;
		}
		this.init();
		this.callHooks("onChange", cell._navType);
		this.callHooks("onSelect", true, cell._navType);
		if (timeout) {
			++this._timerStep;
			this._timer = setTimeout(
				Dynarch.makeClosure(
					this._navCellClicked,
					this,
					cell,
					this._timerStep > 4 ? 75 : 150),
				timeout);
		}
	};

	P._clearTimer = function() {
		if (this._timer)
			clearTimeout(this._timer);
		this._timer = null;
		this._timerStep = 0;
	};

	function onClick(ev) {
		onMouseOver.call(this, ev);
		var cell = getTD(ev);
		if (!cell)
			return;
		if (cell._otherMonth && this._omDisabled)
			return;
		if (cell._navType != null && ev.dl_type == "onMouseDown") {
			this._navDisabled ||
				this._navCellClicked(cell, cell._navType != 0 ? 350 : 0);
		} else if (cell._year != null && ev.dl_type == "onMouseUp") {
			this.date.setMonth(cell._month);
			this.date.setFullYear(cell._year);
			this.date.setDate(cell._iday);
			var old_date = this._selectedDate;
			this._selectedDate = cell._iday;
			if (cell._otherMonth) {
				this.init();
				this.callHooks("onSelect", false, true, false);
			} else if (old_date != this._selectedDate) {
				this._selectCell(cell);
				this.callHooks("onSelect", false, false, false);
			} else
				this.callHooks("onSelect", false, false, true);
		} else if (cell._firstDay != null && !this.fixedFirstDay) {
			this.firstDay = cell._firstDay;
			this._displayCalendar();
		}
	};

	P._selectCell = function(cell) {
		this._selectedDate = cell._iday;
		if (this._selectedTD) {
			DC(this._selectedTD, "Selected");
			DC(this._selectedTD.parentNode, "Selected");
		}
		this._selectedTD = cell;
		AC(cell, "Selected");
		AC(cell.parentNode, "Selected");
		DC(cell, "hover");
	};

	function onKeyDown(ev) {
		alert(ev.charCode);
	};

	P._setListeners = function() {
		this.addEventListener("onMouseOver", onMouseOver);
		this.addEventListener("onMouseLeave", onMouseLeave);
		this.addEventListener("onMouseUp", onClick);
		this.addEventListener("onMouseDown", onClick);
		this.addEventListener("onKeyDown", onKeyDown);
	};

	P.initDOM = function() {
		BASE.initDOM.call(this);
		this.registerEvents(DEFAULT_EVENTS);
	};

	P.init = function() {
		if (!this.date)
			this.date = new Date();
		this._displayCalendar();
	};

	window.DlCalendar = DlCalendar;

})();
