// @require widget.js

(function(){

	var DEFAULT_ARGS = {
		_domType : [ "type", "text" ],
		_value   : [ "value", null ]
	};

	eval(DynarchDomUtils.importCommonVars());

	var BASE = DlEntry.inherits(DlWidget);
	function DlEntry(args) {
		if (args) {
			args.tagName = "table";
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			this._isTextArea = args.type == "textarea";
			BASE.constructor.call(this, args);
		}
	};

	var D = DlEntry;
	var P = D.prototype;

	var STATIC_ELEMENT = document.createDocumentFragment();
	(function(){
		CE("td", null, null,
		   CE("tr", null, null,
		      CE("tbody", null, null, STATIC_ELEMENT)));
	})();

	P.focus = function() {
		this.getInputElement().focus();
	};

	P.blur = function() {
		this.getInputElement().blur();
	};

	function element_focus() {
		this.addClass("DlEntry-Focus");
		this.callHooks("onFocus");
	};

	function element_blur() {
		this.delClass("DlEntry-Focus");
		this.callHooks("onBlur");
	};

	P._createElement = function() {
		BASE._createElement.call(this);
		var el = this.getElement();
		el.appendChild(STATIC_ELEMENT.cloneNode(true));
		el.cellSpacing = el.cellPadding = el.border = 0;
		el = el.rows[0].cells[0];
		var field = this._isTextArea
			? document.createElement("textarea")
			: field = document.createElement("input");
		el.appendChild(field);
		if (this._domType == "password")
			field.type = "password";
		if (this._value != null)
			this.setValue(this._value);
		delete this._value;
	};

	P.getInputElement = function() {
		return this.getElement().rows[0].cells[0].firstChild;
	};

	P.getContentElement = P.getInputElement; // ALIAS

	P.setValue = function(value) {
		this.getInputElement().value = value;
	};

	P.getValue = function() {
		return this.getInputElement().value;
	};

	P.initDOM = function() {
		BASE.initDOM.call(this);
		var input = this.getInputElement();
		DOM.addEvent(input, "focus", Dynarch.makeClosure(element_focus, this));
		DOM.addEvent(input, "blur", Dynarch.makeClosure(element_blur, this));
// 		input.onmousedown = function() {
// 			window.status = "onmousedown";
// 		};
// 		input.onmouseup = function() {
// 			window.status = "onmouseup";
// 		};
// 		input.onclick = function() {
// 			window.status = "onclick";
// 		};
	};

	P.disabled = function(v, force) {
		var isDisabled = BASE.disabled.call(this, v, force);
		if (v != null)
			this.getInputElement().disabled = !!v;
		return isDisabled;
	};

	window.DlEntry = D;

})();
