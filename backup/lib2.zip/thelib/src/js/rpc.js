// @require eventlistener.js

(function() {

	var DEFAULT_ARGS = {
		url      : [ "url"      , null ],
		args     : [ "args"     , null ],
		callback : [ "callback" , null ],
		method   : [ "method"   , "GET" ],
		data     : [ "data"     , null ],
		timeout  : [ "timeout"  , null ]
	};

	function DlRPC(args) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			this.method = this.method.toUpperCase();
			this._timeoutID = 0;
		}
	};

	var P = DlRPC.prototype;

	var _globalEvents = null;

	P.globalEvents = function() {
		if (_globalEvents == null) {
			_globalEvents = new DlEventListener();
			_globalEvents.registerEvents([ "onStart", "onStop", "onTimeout" ]);
		}
		return _globalEvents;
	};

	function onState(req) {
		if (req.readyState == 4) {
			// cleanup for MSIE leaks
			req.onreadystatechange = null;
			this._request = null;
			if (this._timeoutID) {
				clearTimeout(this._timeoutID);
				this._timeoutID = null;
			}
			this.globalEvents().applyHooks("onStop", [ this ]);
			if (this.callback) {
				var args = {
					success    : req.status == 200,
					status     : req.status,
					statusText : req.statusText,
					timeout    : false,
					xml        : req.responseXML,
					text       : req.responseText
				};
				this.callback(args);
			}
		}
	};

	function onTimeout(req) {
		this._request = null;
		req.abort();
		this.globalEvents().applyHooks("onTimeout", [ this ]);
		if (this.callback)
			this.callback({ success: false, timeout: true });
	};

	P.call = function() {
		var req, urlargs = false, i;
		if (window.ActiveXObject)
			req = new ActiveXObject("Microsoft.XMLHTTP");
		else if (window.XMLHttpRequest)
			req = new XMLHttpRequest();
		else
			throw "Browser does not support XMLHttpRequest";
		this._request = req;
		req.onreadystatechange = Dynarch.makeClosure(onState, this, req);
		var args = this.args;
		if (args) {
			urlargs = [];
			for (i in args)
				urlargs.push(escape(i), "=", escape(args[i]));
			if (urlargs.length == 0)
				urlargs = false;
			else
				urlargs = urlargs.join("&");
		}
		var url = this.url;

		switch (this.method) {
		    case "POST":
			if (urlargs && this.data)
				url += "?" + urlargs; // send arguments by GET. ;-)
			req.open("POST", url, true);
			if (!this.data) {
				req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
				this._start(urlargs);
			} else {
				this._start(this.data);
			}
			break;

		    case "GET":
			if (urlargs)
				url += "?" + urlargs;
			req.open("GET", url, true);
			this._start(null);
			break;
		}
	};

	P._start = function(data) {
		if (this.timeout)
			this._timeoutID = setTimeout(Dynarch.makeClosure(onTimeout, this, this._request));
		else
			this._timeoutID = 0;
		this.globalEvents().applyHooks("onStart", [ this ]);
		this._request.send(data);
	};

	window.DlRPC = DlRPC;

})();
