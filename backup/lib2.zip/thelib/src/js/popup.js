// @require container.js

(function(){

	var DEFAULT_EVENTS = [ "onPopup", "onHide", "onBeforePopup" ];

	var DEFAULT_ARGS = {
		_sticky : [ "sticky", true ],
		_zindex : [ "zIndex", 1000 ]
	};

	var BASE = DlPopup.inherits(DlContainer);
	function DlPopup(args) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
			this.visible = false;
			this._popupArgs = null;
		}
	};

	var P = DlPopup.prototype;

// 	var POPUPS = {};

// 	DlPopup.get = function(level) {
// 		if (level == null)
// 			level = 0;
// 		var type = this.prototype._objectType;
// 		var pt = POPUPS[type];
// 		if (!POPUPS[type])
// 			pt = POPUPS[type] = {};
// 		var ret = pt[level];
// 		if (!ret)
// 			ret = pt[level] = new DlPopup({ level: level });
// 		return ret;
// 	};

// 	P.__patchSubclassPrototype = function() {
// 		BASE.__patchSubclassPrototype.call(this);
// 		this.constructor.get = DlPopup.get;
// 	};

	var ALL_POPUPS = {};

	function onPopup() {
// 		var top = this.getToplevelPopup();
// 		if (!top)
// 			top = this;
// 		var except = {};
// 		except[top.id] = true;
// 		DlPopup.clearAllPopups(except);
		if (!this._parentPopup)
			ALL_POPUPS[this.id] = this;
	};
	function onHide(args, ev) {
		if (ALL_POPUPS[this.id])
			delete ALL_POPUPS[this.id];
		if (this._childPopup)
			this._childPopup.hide(args, ev);
		this._childPopup = null;
	};

	function onMouseEnter(ev) {
		this._clear_off_timeout();
		this._clear_on_timeout();
		if (this._parentPopup)
			this._parentPopup.callHooks("onMouseEnter", ev);
	};

	function onMouseLeave(ev) {
		if (!this._sticky) {
			var p = this;
			while (p._parentPopup)
				p = p._parentPopup;
			p._handle_off(this.popupArgs(), ev);
		}
	};

	var have_doc_listener = false;
	function global_onMouseDown(ev) {
		var obj = ev.getObject();
		var except = {};
		while (obj && !(obj instanceof DlPopup)) {
			if (obj.currentPopup)
				except[obj.currentPopup.id] = true;
			obj = obj.parent;
		}
		if (obj) {
			var top = obj.getToplevelPopup();
			if (!top)
				top = obj;
			except[top.id] = true;
		}
		DlPopup.clearAllPopups(except);
	};

	DlPopup.clearAllPopups = function(except) {
		for (var i in ALL_POPUPS)
			if (!except || !except[i])
				ALL_POPUPS[i].hide();
	};

	DlPopup.checkActivePopups = function(obj) {
		while (obj) {
			if (obj instanceof DlPopup)
				return;
			if (obj._isMenuBase)
				return;
			obj = obj.parent;
		}
		DlPopup.clearAllPopups();
	};

	P.sticky = function(sticky) {
		if (sticky != null)
			this._sticky = sticky;
		return this._sticky;
	};

	P.setContent = function(w) {
		this.callHooks("onHide");
		BASE.setContent.call(this, w);
	};

	P._setListeners = function() {
		BASE._setListeners.call(this);
		this.addEventListener("onPopup", onPopup);
		this.addEventListener("onHide", onHide);
		this.addEventListener("onMouseEnter", onMouseEnter);
		this.addEventListener("onMouseLeave", onMouseLeave);
 		if (!have_doc_listener) {
 			have_doc_listener = true;
			DlEvent.captureGlobal("onMouseDown", global_onMouseDown);
			// DlEvent.captureGlobal("onMouseUp", global_onMouseDown);
 		}
	};

	P._createElement = function() {
		BASE._createElement.call(this);
		this.display(false);
		this.zIndex(this._zindex);
	};

	P.initDOM = function() {
		this.registerEvents(DEFAULT_EVENTS);
		// hack around our standard API so that DlPopup elements remain
		// direct children of the <body> element.
// 		var p = this._parent;
// 		this._parent = null;
		BASE.initDOM.call(this);
// 		this.parent = p;
		document.body.appendChild(this.getElement());
	};

	P.DEFAULT_INSTALL_EVENTS = { on  : "onMouseEnter",
				     off : "onMouseLeave" };

	P.DEFAULT_INSTALL_ALIGN = { prefer : "Br", // we prefer Bottom-right
				    fallX1 : "__", // X can't fail at the left side
				    fallX2 : "_l", // but do left alignment if it fails at the right side
				    fallY1 : "__", // Y can't fail at the top side
				    fallY2 : "T_"  // but do Top alignment if it fails at the bottom
	};

	P.DEFAULT_TIMEOUTS = null;

	/**
	 * Pass: widget, events, anchor, type, timeouts, content, align
	 */
	P.install = function(args) {
		args = Dynarch.makeCopy(args);
		var widget = args.widget;
		function PD(key, val) { if (typeof args[key] == "undefined") args[key] = val; };
		PD("events"   , this.DEFAULT_INSTALL_EVENTS);
		PD("timeouts" , this.DEFAULT_TIMEOUTS);
		PD("align"    , this.DEFAULT_INSTALL_ALIGN);
		PD("anchor"   , widget.getElement());
		//PD("type"     , "tooltip");
		PD("content"  , null);
		var events = args.events;
		if (events.on)
			widget.addEventListener
				(events.on,
				 Dynarch.makeClosure(this._handle_on, this, args));
		if (events.off)
			widget.addEventListener
				(events.off,
				 Dynarch.makeClosure(this._handle_off, this, args));
		if (events.on_i)
			widget.addEventListener
				(events.on_i,
				 Dynarch.makeClosure(this._do_handle_on, this, args));
		if (events.off_i)
			widget.addEventListener
				(events.off_i,
				 Dynarch.makeClosure(this._do_handle_off, this, args));
		if (events.reset_tm_on)
			widget.addEventListener
				(events.reset_tm_on,
				 Dynarch.makeClosure(this._reset_on_timeout, this, args));
		return args;
	};

	P._do_handle_on = function(args, ev) {
		try {
			this.callHooks("onBeforePopup", args, ev);
			if (this.visible && args == this._popupArgs)
				return;
			this._clear_on_timeout(args, ev);
			this._clear_off_timeout(args, ev);
			tmp = args.content;
			if (tmp != null) {
				if (typeof tmp == "function")
					tmp = tmp(args, ev);
				this.setContent(tmp);
			}
			this._popupArgs = args;
			this.showAt(args.anchor, args.align,
				    Dynarch.makeCopy(DlEvent.latestEvent.pos), args, ev);
			args.widget.currentPopup = this;
		} catch (ex) {
			if (!(ex instanceof DlExStopEventDefault))
				throw ex;
		}
	};

	P._do_handle_off = function(args, ev) {
		if (!args)
			args = this.popupArgs();
		args.widget.currentPopup = null;
		this.hide(args, ev);
	};

	P._handle_on = function(args, ev) {
		this._clear_on_timeout(args, ev);
		this._clear_off_timeout(args, ev);
		if (!args.timeouts || !args.timeouts.on) {
			this._do_handle_on(args, ev);
		} else {
			this._timer_on = setTimeout
				(Dynarch.makeClosure(this._do_handle_on, this, args, ev),
				 args.timeouts.on);
		}
	};

	P._handle_off = function(args, ev) {
		if (!args)
			args = this.popupArgs();
		this._clear_on_timeout(args, ev);
		this._clear_off_timeout(args, ev);
		if (!args || !args.timeouts || !args.timeouts.off) {
			this.hide(args, ev);
		} else {
			this._timer_off = setTimeout
				(Dynarch.makeClosure(this._do_handle_off, this, args, ev),
				 args.timeouts.off);
		}
	};

	P._clear_on_timeout = function() {
		if (this._timer_on) {
			clearTimeout(this._timer_on);
			this._timer_on = null;
		}
	};

	P._clear_off_timeout = function() {
		if (this._timer_off) {
			clearTimeout(this._timer_off);
			this._timer_off = null;
		}
	};

	P._reset_on_timeout = function(args, ev) {
		if (!args)
			args = this.popupArgs();
		if (this._timer_on) {
			this._clear_on_timeout();
			this._handle_on(args, ev);
		}
	};

	P.popupArgs = function() {
		return this._popupArgs;
	};

	P.hide = function(args, ev) {
		if (!args)
			args = this.popupArgs();
		this.display(false);
		this._timer_off = null;
		this.visible = false;
		this.applyHooks("onHide", [ args, ev ]);
		this._popupArgs = null;
	};

	P.correctPos = Dynarch.noop;

	P.showAt = function(anchor, align, mousePos, args, ev) {
		var origpos, p, sa;
		if (align == "mouse") {
			origpos = mousePos;
			// FIXME: broken
			origpos.y += 10;
			origpos.x += 6;
			align = {
				prefer : "__",
				fallX1 : "_R",
				fallX2 : "_L",
				fallY1 : "B_",
				fallY2 : "T_"
			};
		} else {
			origpos = DynarchDomUtils.getPos(anchor);
		}
		sa = DynarchDomUtils.getOuterSize(anchor);

		p = Dynarch.makeCopy(origpos);
		this.visibility(false);
		this.setPosition({ x: 0, y: 0 });
		this.display(true);

		var tmp,
			ws = DynarchDomUtils.getWindowSize(),
			r  = { x: 0, y: 0, w: ws.x, h: ws.y };

		this._doAlign(align.prefer, p, sa);
		tmp = this.checkXPos(p, r);
		if (tmp != 0) {
			p.x = origpos.x;
			this._doAlign(tmp < 0 ? align.fallX1 : align.fallX2, p, sa);
		}

		tmp = this.checkYPos(p, r);
		if (tmp != 0) {
			p.y = origpos.y;
			this._doAlign(tmp < 0 ? align.fallY1 : align.fallY2, p, sa);
		}

		this.setPosition(p);
		if (this._parentPopup) {
			var ZI = this._parentPopup.zIndex() + 1;
			this.zIndex(ZI);
		}

		// FIXME [FADE IN]: do this properly, if at all:
		this.getElement().style.opacity = 0;
		var steps = 4;
		var timer = setInterval(Dynarch.makeClosure(function() {
			this.getElement().style.opacity = (4 - steps) / 4;
			if (steps-- == 0)
				clearInterval(timer);
		}, this), 50);

		this.visibility(true);
		this.visible = true;
		this._timer_on = null;
		this.applyHooks("onPopup", [ args, ev ]);
	};

	P._doAlign = function(align, p, sa) {
		var
			sp     = this.getSize(),
			valign = align.substr(0, 1),
			halign = "";

		this.correctPos(p);

		if (align.length > 1)
			halign = align.substr(1, 1);

		++p.x;
		++p.y;

		switch (valign) {
		    case "T": p.y -= sp.y; break;
		    case "B": p.y += sa.y; break;
		    case "C":
		    case "c": p.y += (sa.y - sp.y) / 2; break;
		    case "t": p.y += sa.y - sp.y; break;
		    case "b": break; // already there
		}
		switch (halign) {
		    case "L": p.x -= sp.x; break;
		    case "R": p.x += sa.x; break;
		    case "C":
		    case "c": p.x += (sa.x - sp.x) / 2; break;
		    case "l": p.x += sa.x - sp.x; break;
		    case "r": break; // already there
		}
	};

	P.checkXPos = function(p, rect) {
		if (p.x < rect.x)
			return p.x - rect.x;
		var s = this.getSize();
		var d = p.x + s.x - rect.x - rect.w;
		return d > 0 ? d : 0;
	};

	P.checkYPos = function(p, rect) {
		if (p.y < rect.y)
			return p.y - rect.y;
		var s = this.getSize();
		var d = p.y + s.y - rect.y - rect.h;
		return d > 0 ? d : 0;
	};

	P.attachToPopup = function(popup) {
		this._parentPopup = popup;
		popup._childPopup = this;
	};

	P.getToplevelPopup = function() {
		var p = this;
		while (p._parentPopup)
			p = p._parentPopup;
		return p;
	};

	window.DlPopup = DlPopup;

})();
