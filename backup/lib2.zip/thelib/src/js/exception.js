// @require jslib.js

function DlException(message) {
	this.error = this.constructor.name;
	if (!message)
		message = "*** no error message given ***";
	this.message = this.constructor.name + ": " + message;
};

DlException.prototype.toString = function() { return this.message; };

DlException.defineException = function(className, base) {
	if (base == null)
		base = "DlException";
	// the power of eval: write less code.
	return eval([ "window.", className, "=function ", className, "(message){",
		      base, ".call(this, message);};",
		      className, ".inherits(", base, ");" ].join(""));
};

DlException.defineException("DlExInvalidOperation");
DlException.defineException("DlExAbstractBaseClass");
DlException.defineException("DlExStopEventDefault");
DlException.defineException("DlExStopEventProcessing");
DlException.defineException("DlExStopEventBubbling");

DlException.blockDefaultEvent = function() { throw new DlExStopEventDefault; };
DlException.stopEventBubbling = function() { throw new DlExStopEventBubbling; };
