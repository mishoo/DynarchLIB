// @require container.js

(function() {

	var DEFAULT_ARGS = {
		_borderSpacing  : [ "borderSpacing"  , 0 ],
		_align          : [ "align"          , null ]
	};

	eval(DynarchDomUtils.importCommonVars());

	var BASE = DlBox.inherits(DlContainer);
	function DlBox(args) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			args.tagName = "table";
			BASE.constructor.call(this, args);
		}
	};

	var P = DlBox.prototype;

	P._createElement = function() {
		// this.BASE_call("_createElement");
		BASE._createElement.call(this);
		//var div = this.getElement();
		//var table = CE("table", null, { className : div.className }, div);
		//div.className = "";
		var table = this.getElement();
		table.cellSpacing = this._borderSpacing;
		table.cellPadding = 0;
		if (this._align)
			table.align = this._align;
		this._tbody = CE("tbody", null, null, table);
	};

	//P.getTableElement = function() { return this.getElement().firstChild; };
	P.getTableElement = P.getElement;

	P._appendWidgetElement = function(widget) {
		this._createCellElement().appendChild(widget.getElement());
	};

	// <PURE VIRTUAL> -- we mean it.  DO Define this in subclasses.
	// P._createCellElement = function() {};
	// </PURE VIRTUAL>

	P.addSeparator = function() {
		var td = this._createCellElement();
		td.separator = true;
		var cn = this._objectType + "-separator";
		td.className = cn;
		td.innerHTML = "<div class='" + cn + "'>&nbsp;</div>";
		DOM.setUnselectable(td);
	};

	window.DlBox = DlBox;

})();
