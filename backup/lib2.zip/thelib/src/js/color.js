var DlColor = {

	// thanks http://www.cs.rit.edu/~ncs/color/t_convert.html and google
	// for the following 2 algorithms

	// note that the values must be floating point numbers between 0 and 1
	RGB2HSV : function(rgb) {
		var r = rgb[0], g = rgb[1], b = rgb[2];
		var min, max, delta, h, s, v;
		min = Math.min(r, g, b);
		max = Math.max(r, g, b);
		v = max;
		delta = max - min;
		if (max != 0) {
			s = delta / max;
			if (r == max)
				h = (g - b) / delta;
			else if (g == max)
				h = 2 + (b - r) / delta;
			else
				h = 4 + (r - g) / delta;
			h *= 60;
			if (h < 0)
				h += 360;
		} else {
			s = 0;
			h = -1;
		}
		return [h, s, v];
	},

	HSV2RGB : function(hsv) {
		var h = hsv[0], s = hsv[1], v = hsv[2];
		var i, r, g, b, f, p, q, t;
		if (s == 0)
			r = g = b = v;
		else {
			h /= 60;
			i = Math.floor(h);
			f = h - i;
			p = v * (1 - s);
			q = v * (1 - s * f);
			t = v * (1 - s * (1 - f));
			switch (i) {
			    case 0  : r = v; g = t; b = p; break;
			    case 1  : r = q; g = v; b = p; break;
			    case 2  : r = p; g = v; b = t; break;
			    case 3  : r = p; g = q; b = v; break;
			    case 4  : r = t; g = p; b = v; break;
			    default : r = v; g = p; b = q; break;
			}
		}
		return [r, g, b];
	},

	RGB2bytes : function(a) {
		var b = new Array(3);
		b[0] = Math.round(a[0] * 255);
		b[1] = Math.round(a[1] * 255);
		b[2] = Math.round(a[2] * 255);
		return b;
	},

	RGB2color : function(a) {
		return [ "rgb(",
			 a[0] * 100, "%,",
			 a[1] * 100, "%,",
			 a[2] * 100, "%)" ].join();
	},

	RGB2hex : function(a) {
		a = DlColor.RGB2bytes(a);
		return a[0].hex(2) + a[1].hex(2) + a[2].hex(2);
	},

	color2RGB : function(color) {
		var r = 0, g = 0, b = 0;
		if (/^#/.test(color)) {
			if (color.length == 4)
				color = color.replace(/([a-f0-9])/ig, "$1$1");
			r = parseInt(color.substr(1, 2), 16) / 255;
			g = parseInt(color.substr(3, 2), 16) / 255;
			b = parseInt(color.substr(5, 2), 16) / 255;
		} else
			throw new DlException("Can't parse color: " + color);
		return [r, g, b];
	},

	brighter : function(hsv) {
		
	},

	// And that's from here: http://juicystudio.com/article/luminositycontrastratioalgorithm.php.
	// It returns a float value between 0 and 1 that determines how bright the given color is
	// If the returned value is > 0.6, I would use black to contrast.  White otherwise.
	RGBrightness : function(a) {
		return (a[0] * 299 + a[1] * 587 + a[2] * 114) / 1000;
	}

};
