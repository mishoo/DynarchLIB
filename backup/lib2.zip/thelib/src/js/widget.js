// @require eventlistener.js
// @require event.js

(function() {

	var DEFAULT_ARGS = {
		_parent         : [ "parent"     , null ],
		_appendArgs     : [ "appendArgs" , window.undefined ],
		_tagName        : [ "tagName"    , "div" ],
		_addClassName   : [ "className"  , "" ],
		_disabled       : [ "disabled"   , false ],
		_tooltip        : [ "tooltip"    , null ],
		userData        : [ "data"       , null ]
	};

	var DEFAULT_EVENTS = [ "onMouseEnter",
			       "onMouseLeave",
			       "onMouseMove",
			       "onMouseDown",
			       "onMouseUp",
			       "onMouseOver",
			       "onMouseOut",
			       "onClick",
			       "onDisabled",
			       "onDestroy",
			       "onDisplay",
			       "onFocus",
			       "onBlur"
		];

	var WIDGETS = {};

	eval(DynarchDomUtils.importCommonVars());

	var BASE = DlWidget.inherits(DlEventListener);
	function DlWidget(args) {
		if (args) {
			BASE.constructor.call(this);
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);

			if (!(this._parent == null || this._parent instanceof DlContainer))
				throw new DlException("Parent must be an instance of DlContainer");

			this.id = Dynarch.ID(this._objectType || 'DlWidget');
			WIDGETS[this.id] = this;

			this.initDOM();
		}
	};

	DlWidget.getById = function(id) { return WIDGETS[id]; };
	DlWidget.getDefaultArgs = function() { return DEFAULT_ARGS; };
	DlWidget.getFromElement = function(el) { return el._dynarch_object; };

	var TOOLTIP = null;
	DlWidget.getTooltip = function() {
		if (!TOOLTIP)
			TOOLTIP = new DlTooltip({});
		return TOOLTIP;
	};

	var P = DlWidget.prototype;

	P._className = [ "DlWidget" ];

	P.__patchSubclassPrototype = function() {
		this._className = Dynarch.makeArray(this._className);
		this._className.push(this._objectType);
	};

	P._setListeners = Dynarch.noop;	// ALIAS

	P._createElement = function() {
		var cn = this._className.join(" ");
		if (this._addClassName)
			cn += " " + this._addClassName;
		var el = DynarchDomUtils.createElement(
			this._tagName, null, { className : cn,
					       id        : this.id
			});
		el._dynarch_object = this;
		this._element = el;
		if (this._tooltip)
			DlWidget.getTooltip().install({ widget: this, content: this._tooltip });
	};

	P.getElement = function() {
		return this._element;
	};

	P.getContentElement = P.getElement;

	P.setContent = function(content) {
		var el = this.getContentElement();
		if (typeof content == "string") {
			el.innerHTML = content;
		} else if (content instanceof DlWidget) {
			el.innerHTML = "";
			this.appendWidget(content, this._appendArgs);
		} else if (content instanceof Array) {
			el.innerHTML = content.join("");
		}
	};

	P.initDOM = function() {
		this.registerEvents(DEFAULT_EVENTS);
		this._setListeners();
		this._createElement();
		if (this._parent) {
			this._parent.appendWidget(this, this._appendArgs);
			this._parent = null; // this was a temporary property
		}
		if (this._disabled)
			this.disabled(true, true);
		return this;
	};

	P.setUnselectable = function() {
		DOM.setUnselectable(this.getElement());
	};

	P.disabled = function(v, force) {
		if (v != null && (force || v != this._disabled)) {
			this._disabled = v;
			this.condClass(v, "DlWidget-disabled");
			var last = this._className.peek();
			this.condClass(v, last + "-disabled");
			this.applyHooks("onDisabled", [ v ]);
		}
		return this._disabled;
	};

	P.destroy = function() {
		if (!this.destroyed) {
			this.destroying = true;
			// alert("Destroying " + this.id);
			this.callHooks("onDestroy");
			// <XXX: this is probably not good for composed widgets>
			// var els = Dynarch.makeArray(el.getElementsByTagName("*"));
			// els.r_foreach(function(el) { el._dynarch_object = null; });
			// </XXX>
			if (this.parent)
				this.parent.removeWidget(this);
			var el = this.getElement();
			el._dynarch_object = null;
			this._element = null;
			if (el.parentNode)
				el.parentNode.removeChild(el);
			if (WIDGETS[this.id])
				delete WIDGETS[this.id];
			this.destroyed = true;
			this.destroying = false;
		}
	};

	P.getParent = function(type, skipThis) {
		if (type == null)
			return this.parent;
		var parent = this;
		if (skipThis)
			parent = this.parent;
		while (parent && (!parent instanceof type))
			parent = parent.parent;
		return parent;
	};

	P.setPos = function(x, y) {
		var el = this.getElement();
		if (x != null)
			el.style.left = x + "px";
		if (y != null)
			el.style.top = y + "px";
	};

	P.setSize = P.setOuterSize = function(size) {
		DOM.setOuterSize(this.getElement(), size.x, size.y);
	};

	P.setInnerSize = function(size) {
		DOM.setInnerSize(this.getContentElement(), size.x, size.y);
	};

	P.getSize = P.getOuterSize = function() {
		return DOM.getOuterSize(this.getElement());
	};

	P.getInnerSize = function() {
		return DOM.getInnerSize(this.getContentElement());
	};

	P.display = function(v) {
		var s = this.getElement().style;
		if (v != null) {
			s.display = v ? "" : "none";
			this.callHooks("onDisplay", v, s.display);
			return v;
		}
		return s.display != "none";
	};

	P.visibility = function(v) {
		var s = this.getElement().style;
		if (v != null) {
			s.visibility = v ? "" : "hidden";
			return v;
		}
		return s.visible != "hidden";
	};

	P.setPosition = function(pos) {
		var s = this.getElement().style;
		s.left = pos.x + "px";
		s.top = pos.y + "px";
	};

	P.addClass = function(ac, dc) {
		AC(this.getElement(), ac, dc);
	};

	P.delClass = function(dc, ac) {
		DC(this.getElement(), dc, ac);
	};

	P.condClass = function(cond, clsTrue, clsFalse) {
		CC(this.getElement(), cond, clsTrue, clsFalse);
	};

	P.zIndex = function(zIndex) {
		var el = this.getElement();
		if (zIndex != null) {
			el.style.zIndex = zIndex;
			return zIndex;
		}
		if (el.style.zIndex)
			return parseInt(el.style.zIndex);
		return 0;
	};

	window.DlWidget = DlWidget;

	DlEvent.atUnload(function(){
		for (var i in WIDGETS) {
			var w = WIDGETS[i];
			//w.destroy();
			if (w._element) {
				w._element._dynarch_object = null;
				w._element = null;
			}
			delete WIDGETS[i];
		}
		WIDGETS = null;
	});

})();
