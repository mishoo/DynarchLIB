// @require container.js

// COMMENTED OUT FOR NOW
(function(){

	var DEFAULT_EVENTS = [ "onPopup", "onHide" ];
	var BASE = DlPopup.inherits(DlContainer);
	var DEFAULT_ARGS = {
		_level : [ "level", 0 ]
	};
	var POPUPS = {};
	var CAPTURE_EVENTS = [ "onMouseDown" ];
	var TOPLEVEL_POPUP = null;

	eval(DynarchDomUtils.importCommonVars());

	function DlPopup(args) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
			this.visible = false;
		}
	};

	DlPopup.get = function(level) {
		if (level == null)
			level = 0;
		var type = this.prototype._objectType;
		var pt = POPUPS[type];
		if (!POPUPS[type])
			pt = POPUPS[type] = {};
		var ret = pt[level];
		if (!ret)
			ret = pt[level] = new DlPopup({ level: level });
		return ret;
	};

	var P = DlPopup.prototype;

	P.__patchSubclassPrototype = function() {
		this.constructor.get = DlPopup.get;
	};

	P.initDOM = function() {
		this.registerEvents(DEFAULT_EVENTS);
		BASE.initDOM.call(this);
	};

	P._createElement = function() {
		var parent = this._parent;
		this._parent = null;
		BASE._createElement.call(this);
		this.parent = parent;
		this.display(false);
		document.body.appendChild(this.getElement());
		this.zIndex(1000);
	};

	function onPopup() {
		if (this._level == 0) {
			if (TOPLEVEL_POPUP)
				TOPLEVEL_POPUP.hide();
			TOPLEVEL_POPUP = this;
		}
	};
	function onHide() {
		if (this._level == 0)
			TOPLEVEL_POPUP = null;
	};
	function onMouseEnter() {};
	function onMouseLeave() {};

	function doc_onMouseDown(ev) {
		ev || (ev = window.event);
		ev = new DlEvent(ev);
		var obj = ev.getObject();
		while (obj && !(obj instanceof DlPopup))
			obj = obj.parent;
		if (!obj)
			DlPopup.clearAllPopups();
		else {
			var top = obj.getToplevelPopup();
			if (!top)
				top = obj;
			var except = {};
			except[top.id] = true;
			DlPopup.clearAllPopups(except);
		}
	};

	var have_doc_listener = false;
	P._setListeners = function() {
		BASE._setListeners.call(this);
		this.addEventListener("onPopup", onPopup);
		this.addEventListener("onHide", onHide);
		this.addEventListener("onMouseEnter", onMouseEnter);
		this.addEventListener("onMouseLeave", onMouseLeave);
		if (!have_doc_listener) {
			have_doc_listener = true;
			DOM.addEvent("onmousedown", doc_onMouseDown);
		}
	};

	P.getToplevelPopup = function() {
		return TOPLEVEL_POPUP;
	};

	window.DlPopup = DlPopup;

})();
