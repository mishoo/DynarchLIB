function DlTimeout(callback, timeout) {
	var self = this;
	this._callback = callback;
	this._runCount = 0;
	this.redo(timeout);
};

(function(){

	var P = DlTimeout.prototype;

	P.redo = function(timeout) {
		if (timeout != null)
			this._timeout = timeout;
		this._isRunning = false;
		this._hasFinished = false;
		this._wasCanceled = false;
		this._timeoutID = setTimeout(function() { self.runNow(); }, this._timeout);
	};

	P.runNow = function() {
		this.cancel();
		this._wasCanceled = false;
		this._isRunning = true;
		this._callback();
		this._isRunning = false;
		this._hasFinished = true;
		++this._runCount;
	};

	P.cancel = function() {
		if (this._timeoutID) {
			clearTimeout(this._timeoutID);
			this._timeoutID = null;
			this._wasCanceled = true;
		}
	};

	P.isRunning = function() { return this._isRunning; };
	P.hasFinished = function() { return this._hasFinished; };
	P.runCount = function() { return this._runCount; };
	P.wasCanceled = function() { return this._wasCanceled; };

})();
