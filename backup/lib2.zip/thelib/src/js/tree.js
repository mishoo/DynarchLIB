// @require container.js

(function() {

	var BASE = DlTree.inherits(DlContainer);
	function DlTree(args) {
		if (args) {
			// args.className = "DlTree-withLines";
			BASE.constructor.call(this, args);
			this._items = [];
		}
	};

	var P = DlTree.prototype;

	P._appendWidgetElement = function(w, pos) {
		var parent = this.getContentElement();
		if (pos == null) {
			if (w instanceof DlTreeItem) {
				var last = this._items.peek();
				last
					? last.setFirstLast(null, false)
					: w.setFirstLast(true, null);
				this._items.push(w);
				w.setFirstLast(null, true);
			}
			parent.appendChild(w.getElement());
		} else {
			if (pos == this._items.length)
				return this._appendWidgetElement(w, null);
			var prev = this._items[pos];
			if (prev && pos == 0) {
				prev.setFirstLast(false, null);
				w.setFirstLast(true, null);
			}
			this._items.splice(pos, 0, w);
			parent.insertBefore(w.getElement(),
					    parent.childNodes[pos]);
		}
	};

	window.DlTree = DlTree;

})();

(function() {

	eval(DynarchDomUtils.importCommonVars());

	var DEFAULT_EVENTS = [ "onExpand", "onCollapse" ];

	var STATIC_ELEMENT = document.createDocumentFragment();

	(function() {
		var STATIC_TABLE = CE
			("table", null,
				{ cellSpacing: 0, cellPadding: 0,
				  className: "DlTreeItem-Table" },
			 STATIC_ELEMENT);
		// we don't want to share these variables.
		var STATIC_TR = CE("tr", null, null,
				   CE("tbody", null, null, STATIC_TABLE));
		CE("td", null, { className: "DlTreeItem-Expander" }, STATIC_TR);
		CE("td", null, null, STATIC_TR);
		CE("td", null, { className: "DlTreeItem-Label" }, STATIC_TR);
		CE("div", null, { className: "DlTreeItem-Subtree" }, STATIC_ELEMENT);
	})();

	var DEFAULT_ARGS = {
		_label     : [ "label", null ],
		_iconClass : [ "iconClass" , null ]
	};

	var BASE = DlTreeItem.inherits(DlContainer);
	function DlTreeItem(args) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
			this.setIconClass(this._iconClass);
			this._iconClass = null;
		}
	};

	var P = DlTreeItem.prototype;

	function getTD(ev) {
		var el = ev.target;
		try {
			while (el && el.tagName.toLowerCase() != "td")
				el = el.parentNode;
		} catch(ex) {
			el = null;
		}
		return el;
	};

	function onClick(ev) {
		var td = getTD(ev);
		if (td && /DlTreeItem-(Expander|Icon)/.test(td.className)) {
			this.toggle();
			throw new DlExStopEventBubbling;
		}
	};

	P.setFirstLast = function(isFirst, isLast) {
		if (isFirst != null) {
			this.condClass(isFirst, "DlTreeItem-First");
			CC(this.getTableElement(), isFirst, "DlTreeItem-First");
		}
		if (isLast != null) {
			this.condClass(isLast, "DlTreeItem-Last");
			CC(this.getTableElement(), isLast, "DlTreeItem-Last");
		}
	};

	P.initDOM = function() {
		this.registerEvents(DEFAULT_EVENTS);
		BASE.initDOM.call(this);
		this.addEventListener("onMouseDown", onClick);
	};

	P._createElement = function() {
		BASE._createElement.call(this);
		this.getElement().appendChild(STATIC_ELEMENT.cloneNode(true));
		if (this._label)
			this.setContent(this._label);
		this.setUnselectable();
	};

	P.getTableElement = function() {
		return this.getElement().firstChild;
	};

	P.getExpanderElement = function() {
		return this.getTableElement().rows[0].cells[0];
	};

	P.getIconElement = function() {
		return this.getTableElement().rows[0].cells[1];
	};

	P.getContentElement = function() {
		return this.getTableElement().rows[0].cells[2];
	};

	P.getSubtreeDiv = function() {
		return this.getTableElement().nextSibling;
	};

	P.setTree = function(tree) {
		if (this._tree && (typeof this.tree != "function"))
			this.removeWidget(this._tree);
		this._tree = tree;
		if (tree != null) {
			if (typeof tree != "function") {
				this.appendWidget(tree, true);
				this.expanded = true;
			} else
				this.expanded = false;
		} else
			this.expanded = null;
		this.condClass(tree, "DlTreeItem-HasTree");
		this.updateExpanderState();
	};

	P.toggle = function() {
		this.expand(!this.expanded);
	};

	P.expand = function(expand, nohooks) {
		if (expand == null)
			expand = true;
		if (expand !== this.expanded) {
			this.expanded = expand;
			this.getSubtreeDiv().style.display = expand ? "block" : "none";
			this.updateExpanderState();
			if (!nohooks)
				this.callHooks(expand ? "onExpand" : "onCollapse");
		}
	};

	P.setIconClass = function(iconClass) {
		var e2 = this.getIconElement();
		CC(e2, iconClass != null, this._className.peek() + "-Icon");
		if (this.iconClass)
			DC(e2, this.iconClass);
		if (iconClass)
			AC(e2, iconClass);
		this.iconClass = iconClass;
	};

	P.updateExpanderState = function() {
		var div = this.getExpanderElement().firstChild;
		if (this._tree) {
			if (!div) {
				div = CE("div", null, { innerHTML: "&nbsp;" },
					 this.getExpanderElement());
			}
			CC(div, this.expanded,
			   "DlTreeItem-Arrow-Expanded", "DlTreeItem-Arrow-Collapsed");
			CC(this.getTableElement(), this.expanded,
			   "DlTreeItem-Table-Expanded", "DlTreeItem-Table-Collapsed");
		} else if (div) {
			DC(div, "DlTreeItem-Arrow-Expanded");
			DC(div, "DlTreeItem-Arrow-Collapsed");
			div.parentNode.removeChild(div);
			div = this.getTableElement();
			DC(this.getTableElement(), "DlTreeItem-Table-Expanded");
			DC(this.getTableElement(), "DlTreeItem-Table-Collapsed");
		}
	};

	P.getTree = function() {
		if (typeof this._tree == "function") {
			this._tree = this._tree();
			if (this._tree)
				this.appendWidget(this._tree, true);
		}
		return this._tree;
	};

	P._appendWidgetElement = function(w, subtree) {
		var el = w.getElement(), t;
		t = subtree ? this.getSubtreeDiv() : this.getContentElement();
 		if (subtree) {
 			AC(el, "DlTree-withLines");
			this.addClass("DlTreeItem-hasSubtree");
		}
		t.appendChild(el);
	};

	P._removeWidgetElement = function(w) {
		BASE._removeWidgetElement.call(this, w);
		if (!this.getSubtreeDiv().firstChild)
			this._tree = null;
		this.updateExpanderState();
	};

	window.DlTreeItem = DlTreeItem;

})();
