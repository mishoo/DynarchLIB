var hbox = new DlHbox({ borderSpacing: 10 });

var vbox1 = new DlVbox({ parent: hbox, borderSpacing: 5 });
var vbox2 = new DlVbox({ parent: hbox, borderSpacing: 5 });
var vbox3 = new DlVbox({ parent: hbox, borderSpacing: 5 });

var r1 = new DlRadioButton({ label: "Move to vbox1", group: "group0", parent: vbox1, data: 1, checked: true });
var r2 = new DlRadioButton({ label: "Move to vbox2", group: "group0", parent: vbox2, data: 2 });
var r3 = new DlRadioButton({ label: "Move to vbox3", group: "group0", parent: vbox3, data: 3 });

var b1 = new DlButton({ label: "What's my parent?", parent: vbox1 });

b1.addEventListener("onClick", function() {
	alert(this.parent.id);
});

function listener(r) {
	if (r.checked()) {
		var group = DlRadioGroup.get("group0");
		var dest = [vbox1, vbox2, vbox3][r.userData - 1];
		dest.appendWidget(b1);
	}
};

DlRadioGroup.get("group0").addEventListener("onChange", listener);

Dynarch.makeArray(hbox.getElement().getElementsByTagName("td")).r_foreach(
	function(td) {
		td.style.verticalAlign = "top";
	});

document.body.appendChild(hbox.getElement());
