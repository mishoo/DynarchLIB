var w = new DlWidget({});

w.addEventListener("onMouseEnter", function(ev) {
    this.getElement().style.background = "#ff8";
});

w.addEventListener("onMouseLeave", function(ev) {
    this.getElement().style.background = "#ff0";
    window.status = "";
});

w.addEventListener("onMouseDown", function(ev) {
    this.getElement().style.background = "#f88";
});

w.addEventListener("onMouseUp", function(ev) {
    this.getElement().style.background = "#ff0";
});

w.addEventListener("onMouseMove", function(ev) {
    window.status = ev.clientX + " / " + ev.clientY;
});

var div = w.getElement();
div.innerHTML = "Foo";
div.style.position = "absolute";
div.style.width = "100px";
div.style.height = "100px";
div.style.right = "10px";
div.style.top = "10px";
div.style.border = "1px solid #000;";
div.style.background = "#ff0";
div.style.padding = "10px";
document.body.appendChild(div);

