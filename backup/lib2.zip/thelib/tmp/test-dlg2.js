var $D = new DlDialog({ title: "Test dialog" });

var T = new Date().getTime();
var top_box = new DlVbox({ className: "DlWidget-3D" });
var tmp;
var tooltip = new DlTooltip({});
{
	var tabs = new DlTabs({ parent: top_box, tabPos: DlTabs.TAB_POS.TOP });

	var box1 = new DlVbox({});
	new DlCheckbox({ parent: box1, checked: true, label: "Tabbed browsing" });
	tmp = new DlCheckbox({ parent: box1, checked: false, label: "Popup filter" });
	tooltip.install({ widget: tmp, content: [ "Using Firefox, you will",
						  "<em>never</em> be <em>pissed off</em>",
						  "by those popups again." ].join("<br />")
					  });
	tmp = new DlCheckbox({ parent: box1, checked: true, label: "Interactive search" });
	tooltip.install({ widget: tmp, content: [ "Firefox has an Interactive Search",
						  "feature that will make you forget",
						  "about non-interactive ones." ].join("<br />")
					  });
	box1.addSeparator();
	new DlCheckbox({ parent: box1, checked: true, label: "Standards compliance" });
	new DlCheckbox({ parent: box1, checked: true, label: "Browse safely" });
	box1.getElement().style.margin = "20px";

        var tab2 = new DlContainer({});
	var box2 = new DlVbox({ parent: tab2, borderSpacing: 0 });

	box2.getElement().style.paddingTop = "1em";
	box2.getElement().align="center";

	var hb2 = new DlHbox({ parent: box2 });
	hb2.setAlign("left");

	new DlRadioButton({ parent: hb2, checked: true, data: DlTabs.TAB_POS.TOP, group: "tabPosGrp", label: "Top" });
//	new DlRadioButton({ parent: hb2, data: DlTabs.TAB_POS.RIGHT, group: "tabPosGrp", label: "Right" });

	DlRadioGroup.get("tabPosGrp").addEventListener("onChange", function(b) {
		if (b.checked())
			tabs.setTabPos(b.userData);
	});

	box2.addSeparator();

	var hb3 = new DlHbox({ parent: box2 });
	hb3.setAlign("center");

	new DlRadioButton({ parent: hb3, data: "left", group: "tabAlign", label: "Left" });
	hb3.addSeparator();
	new DlRadioButton({ parent: hb3, data: "center", group: "tabAlign", label: "Center" });
	hb3.addSeparator();
	new DlRadioButton({ parent: hb3, data: "right", group: "tabAlign", label: "Right" });

	DlRadioGroup.get("tabAlign").addEventListener("onChange", function(b) {
		if (b.checked())
			var el = tabs.setTabAlign(b.userData);
	});

	box2.addSeparator();

	var hb4 = new DlHbox({ parent: box2 });
	hb4.setAlign("right");

	new DlRadioButton({ parent: hb4, data: DlTabs.TAB_POS.BOTTOM, group: "tabPosGrp", label: "Bottom" });
//	new DlRadioButton({ parent: hb4, data: DlTabs.TAB_POS.LEFT, group: "tabPosGrp", label: "Left" });

	var box3 = new DlVbox({ borderSpacing: 20 });
	var b13 = new DlButton({ parent: box3, label: "Goo Fuck" });
	box3.addSeparator();
	var b23 = new DlButton({ parent: box3, label: "Goo Your Self" });
	box3.addSeparator();
	var b33 = new DlButton({ parent: box3, label: "IE sucks hard" });

	var vbox4 = new DlVbox({ borderSpacing: 5 });
	new DlButtonCalendar({ parent: vbox4, calendar: { weekNumbers: true } });
	new DlButtonCalendar({ parent: vbox4, calendar: { weekNumbers: true } });
	new DlButtonCalendar({ parent: vbox4, calendar: { weekNumbers: true } });
	var box4 = new DlHbox({ parent: vbox4, className: "DlPopupMenu" });
	var menu = new DlHMenu({ parent: box4 });
	var i1 = new DlMenuItem({ parent: menu, label: "Check", iconClass: "icon1" });
	var i2 = new DlMenuItem({ parent: menu, label: "This is a cool" });
	menu.addSeparator();
	var i3 = new DlMenuItem({ parent: menu, label: "Menu that will" });
	menu.addSeparator();
	var i4 = new DlMenuItem({ parent: menu, label: "Become even cooler" });

	var fmenu = menu = new DlVMenu({});
	fmenu.addEventListener("onSelect", function(item_name, item) {
		alert(item_name);
	});
	var j1 = new DlMenuItem({ parent: menu, label: "Popup 1", iconClass: "icon1", name: "Foo Item" });
	var j2 = new DlMenuItem({ parent: menu, label: "Popup 2", iconClass: "icon1", disabled: true });
	// j2.disabled(true);
	var j3 = new DlMenuItem({ parent: menu, label: "Popup 3", iconClass: "icon1" });
	var j4 = new DlMenuItem({ parent: menu, label: "Popup 4", iconClass: "icon1" });
	i1.setMenu(menu);

	menu = new DlVMenu({});
	var j11 = new DlMenuItem({ parent: menu, label: "Popup 1", iconClass: "icon1" });
	var j22 = new DlMenuItem({ parent: menu, label: "Popup 2", iconClass: "icon1" });
	var j33 = new DlMenuItem({ parent: menu, label: "Popup 3", iconClass: "icon1" });
	var j44 = new DlMenuItem({ parent: menu, label: "Popup 4", iconClass: "icon1" });
	i2.setMenu(menu);

	menu = new DlVMenu({});
	var k1 = new DlMenuItem({ parent: menu, label: "Ckt Menu Item 1", iconClass: "icon1" });
	var k2 = new DlMenuItem({ parent: menu, label: "Ckt Menu Item 2" });
	var k3 = new DlMenuItem({ parent: menu, label: "Ckt Menu Item 3" });
	var k4 = new DlMenuItem({ parent: menu, label: "Ckt Menu Item 4", iconClass: "icon1" });
	j3.setMenu(menu);

	menu = new DlVMenu({});
	new DlCheckbox({ parent: menu, group: "Q3", label: "Apples" });
	new DlCheckbox({ parent: menu, group: "Q3", label: "Bananas", checked: true });
	new DlCheckbox({ parent: menu, group: "Q3", label: "Oranges" });
	DlRadioGroup.getById("Q3").maxChecked(2);
	menu.addSeparator();
	new DlCheckbox({ parent: menu, label: "Pears & Perls" });
	//new DlMenuItem({ parent: menu, label: "Ckt Menu Item 4", iconClass: "icon1" });
	menu.addSeparator();
	new DlRadioButton({ parent: menu, label: "Linux", group: "OS", checked: true });
	new DlRadioButton({ parent: menu, label: "Mac OS X", group: "OS" });
	new DlRadioButton({ parent: menu, label: "Windows", group: "OS" });
	//var clone = new DlMenuItem({ parent: menu, label: "Clone myself" });
	k1.setMenu(menu);
	i3.setMenu(menu);
	k4.setMenu(menu);
	//clone.setMenu(menu);

	menu = new DlVMenu({});
	var l1 = new DlMenuItem({ parent: menu, label: "Send email...", iconClass: "icon1" });
	menu.addSeparator();
	var l2 = new DlMenuItem({ parent: menu, label: "Check out" });
	var l3 = new DlMenuItem({ parent: menu, label: "Review changes" });

	l3.setMenu(fmenu);

	i4.setMenu(menu);

	box4 = new DlHbox({ parent: vbox4 });
	var bm = new DlButtonMenu({ parent: box4, label: "New" });
	bm.getPopup().addEventListener("onPopup", function() {
		var buttonmenu = this.parentMenu;
		var args = {
			url : "foomenu.js",
			callback : function(r) {
				eval(r.text);
			}
		};
		var rpc = new DlRPC(args).call();
	});

	menu = new DlVMenu({});
	new DlMenuItem({ parent: menu, label: "Email message", iconClass: "icon1" });
	new DlMenuItem({ parent: menu, label: "Test document" });
	menu.addSeparator();
	new DlMenuItem({ parent: menu, label: "Appointment" });
	bm.setMenu(menu);
	bm.getButton().setIconClass("icon1");

	box4.addSeparator();
	bm = new DlButtonMenu({ parent: box4, label: "Test with a bigger menu" });
	bm.setMenu(fmenu);

// 	box4.addSeparator();
//  	var cal = new DlCalendar({ parent: box4, navigation: 2, weekNumbers: true });
//  	cal.init();

//  	cal.addEventListener("onSelect", function(cleared, otherMonth, dblClick) {
//  		window.status = ("onSelect: " + this.date + "\ncleared: " + cleared + ", other month: " + otherMonth
//  				 + ", dbl click: " + dblClick);
//  	});

	box4.addSeparator();

	var hbox5 = new DlHbox({ borderSpacing: 5 });

	var tree = new DlTree({ parent: hbox5 });
	var i1 = new DlTreeItem({ parent: tree, label: "Tree item 1" });
	var i2 = new DlTreeItem({ parent: tree, label: "Tree item 2" });
	var i3 = new DlTreeItem({ parent: tree, label: "Item 3" });

 	// var foo = new DlButton({ label: "A foo button" });
// 	var foo = new DlVbox({});
// 	new DlButtonCalendar({ parent: foo });
// 	new DlButton({ parent: foo, label: "A foo button" });
// 	i3.setContent(foo);

	var t2 = new DlTree({});
	new DlTreeItem({ parent: t2, label: "Item 3.1", iconClass: "IconCalendar" });
	new DlTreeItem({ parent: t2, label: "Item 3.2" });
	new DlTreeItem({ parent: t2, label: "Item 3.3" });
	new DlTreeItem({ parent: t2, label: "Item 3.4", iconClass: "icon1" });
	i3.setTree(t2);
	i3.setIconClass("icon1");

	var i4 = new DlTreeItem({ parent: tree, label: "Tree item 4" });
	var t2 = new DlTree({});
	new DlTreeItem({ parent: t2, label: "Item 3.1" });
	new DlTreeItem({ parent: t2, label: "Item 3.2" });
	new DlTreeItem({ parent: t2, label: "Item 3.3" });
	foo = new DlTreeItem({ parent: t2, label: "Item 3.4", iconClass: "icon1" });
	i4.setTree(t2);

	new DlTreeItem({ parent: t2, label: "Item 3.5" });
	new DlTreeItem({ parent: t2, label: "Item 3.6" });

	var i4 = new DlTreeItem({ parent: tree, label: "Tree item 4", iconClass: "IconCalendar" });
	var t2 = new DlTree({});
	new DlTreeItem({ parent: t2, label: "Item 3.1", iconClass: "IconCalendar" });
	new DlTreeItem({ parent: t2, label: "Item 3.2", iconClass: "IconCalendar" });
	i4 = new DlTreeItem({ parent: t2, label: "Item 3.3", iconClass: "IconCalendar" });
	new DlTreeItem({ parent: t2, label: "Item 3.4", iconClass: "IconCalendar" });
	foo.setTree(t2);

	t2 = new DlTree({});
	new DlTreeItem({ parent: t2, label: "Item 3.1" });
	new DlTreeItem({ parent: t2, label: "Item 3.2" });
	new DlTreeItem({ parent: t2, label: "Item 3.3" });
	i4.setTree(t2);

	foo = new DlButton({ parent: hbox5, label: "Test reparent" });
	foo.addEventListener("onClick", function() {
		i1.setTree(t2);
	});

	tabs.addTab(box1, "Mozilla Firefox");
	tabs.addTab(tab2, "Tab position");
	tabs.addTab(box3, "Apple Safari");
	tabs.addTab(vbox4, "Popup menu");
	tabs.addTab(hbox5, "Tree");
	tabs.showPane(0);

	vbox4._tab.setIconClass("icon1");
}
{
	top_box.addSeparator();
	var btn_box = new DlHbox({ parent: top_box, borderSpacing: 0 });
	btn_box.setAlign(null, "1em");
        var tt1 = new DlButton({ checked: true, parent: btn_box, label: "Enable tabs", type: DlButton.TYPE.TWOSTATE });
	tt1.addEventListener("onChange", function() {
		tabs.getTabContent().disabled(!this.checked());
	});
	tooltip.install({ widget: tt1, content: function(args, ev) {
		if (args.widget.checked())
			return "Click to disable the tab contents";
		else
			return "Click to enable the tab contents";
	}});
	btn_box.addSeparator();
	var prev = new DlButton({ parent: btn_box, label: "<div style='width: 6em'>« Previous</div>" });
	prev.addEventListener("onClick", function() {
		tabs.prevPane();
	});
	var next = new DlButton({ parent: btn_box, label: "<div style='width: 6em'>Next »</div>" });
	next.addEventListener("onClick", function() {
		tabs.nextPane();
	});
}

tabs.getNotebook().addEventListener("onChange", function() {
	prev.disabled(this.isFirstPane());
	next.disabled(this.isLastPane());
});

tabs.showPane(4);
tabs.getTabBar().setAlign("1em");

top_box.getTableElement().style.padding = "5px";
//top_box.getElement().style.margin = "1em";

$D.appendWidget(top_box);

document.body.appendChild($D.getElement());
$D.display(true);
tabs.setSize({ x:700, y:250 });
$D.centerOnParent();

//tabs.setSize({ x:500, y:200 });
//tabs.getTabContent().setIdealSize();
//var s = tabs.getSize();
//alert(s.x + " x " + s.y);

//alert((new Date().getTime() - T) / 1000);

