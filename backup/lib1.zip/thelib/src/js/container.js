// @require widget.js

(function() {

	var BASE = DlContainer.inherits(DlWidget);
	function DlContainer(args) {
		if (args) {
			this._widgets = [];
			BASE.constructor.call(this, args);
		}
	};

	var P = DlContainer.prototype;

	P.appendWidget = function(w) {
		// alert("Appending " + w._objectType + " to " + this._objectType);
		if (w.parent)
			w.parent.removeWidget(w);
		this._widgets.push(w);
		w.parent = this;
		this._appendWidgetElement.apply(this, Dynarch.makeArray(arguments));
	};

	P._appendWidgetElement = function(w) {
		var p = this.getContentElement();
		var el = w.getElement();
		if (el.parentNode !== p)
			p.appendChild(el);
	};

	P.removeWidget = function(w) {
		if (w.parent === this) {
			this._widgets.remove(w);
			this._removeWidgetElement(w);
			w.parent = null;
		}
	};

	P._removeWidgetElement = function(w) {
		if (this._widgets.contains(w)) {
			var el = w.getElement();
			if (el.parentNode)
				el.parentNode.removeChild(el);
		}
	};

	P.destroy = function() {
		var a = this._widgets, i = 0;
		try {
			while (i < a.length) {
				// alert("Destroying: " + a[i].id);
				var tmp = a.length;
				a[i].destroy();
				if (tmp == a.length)
					++i;
			}
		} catch(ex) {
			//alert(ex.toSource());
// 			alert(ex + "\n" + i + " : " + a[i] + "\n" + this._objectType + "\n" + a[i]._objectType + " : " + a[i].id +
// 			      "\n" + a[i].parent.id + "\n" + a[i].parent.removeWidget + "\n\n" +
// 			      (a[i].parent === this));
		}
		BASE.destroy.call(this);
	};

	P.disabled = function(v, force) {
		var isDisabled = BASE.disabled.call(this, v, force);
		if (v != null)
			this._widgets.r_foreach(function(w) {
				w.disabled(v, force);
			});
		return isDisabled;
	};

	window.DlContainer = DlContainer;

})();
