// @require buttonmenu.js

(function() {

	var DEFAULT_ARGS = {
		rgb   : [ "rgb", null ],
		hsv   : [ "hsv", null ],
		color : [ "color", null ]
	};

	var BASE = DlButtonColorPicker.inherits(DlButtonMenu);
	function DlButtonColorPicker(args) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
			this._colorSelectClosure = Dynarch.makeClosure(onSelect, null, this);
			this._colorHoverClosure = Dynarch.makeClosure(onHover, null, this);
			this._colorLeaveClosure = Dynarch.makeClosure(onLeave, null, this);
			this._updateValues();
		}
	};

	var D = DlButtonColorPicker;
	var P = D.prototype;

	function onSelect(btn, rgb, hsv, color, brightness) {
		btn.getColorElement().style.backgroundColor = color;
		btn.hsv = Dynarch.makeArray(hsv);
		btn._updateValues();
		DlPopup.clearAllPopups();
		btn.applyHooks("onSelect", [ rgb, hsv, color, brightness ]);
	};

	function onHover(btn, rgb, hsv, color, brightness) {
		btn.getColorElement().style.backgroundColor = color;
	};

	function onLeave(btn) {
		var div = btn.getColorElement();
		div.style.backgroundColor = btn.rgb ? DlColor.RGB2color(btn.rgb) : "";
	};

	P._updateValues = function() {
		if (this.hsv) {
			this.rgb = DlColor.HSV2RGB(this.hsv);
			this.color = DlColor.RGB2color(this.rgb);
		} else if (this.rgb) {
			this.hsv = DlColor.RGB2HSV(this.rgb);
			this.color = DlColor.RGB2color(this.rgb);
		} else if (this.color) {
			this.rgb = DlColor.color2RGB(this.color);
			this.hsv = DlColor.RGB2HSV(this.rgb);
		}
	};

	P.setColorPicker = function(cp) {
		this.setMenu(cp);
		cp.addEventListener("onSelect", this._colorSelectClosure);
		cp.addEventListener("onHover", this._colorHoverClosure);
		cp.addEventListener("onHoverOut", this._colorLeaveClosure);
		if (this.hsv) {
			cp.setHSV(this.hsv);
			onSelect.call(cp, this, this.rgb, this.hsv,
				      DlColor.RGB2color(this.rgb),
				      DlColor.RGBrightness(this.rgb));
		}
	};

	P._createElement = function() {
		BASE._createElement.call(this);
		var el = this.getButton().setContent("<div class='ColorPart'></div><div></div>");
		this.setLabel(this.label);
	};

	P.setLabel = function(label) {
		var div = this.getLabelElement();
		div.innerHTML = label || "&nbsp;";
		DynarchDomUtils.condClass(div, label, "Label", "EmptyLabel");
	};

	P.getColorElement = function() {
		return this.getButton().getContentElement().firstChild;
	};

	P.getLabelElement = function() {
		return this.getButton().getContentElement().childNodes[1];
	};

// 	P.initDOM = function() {
// 		BASE.initDOM.call(this);
// 	};

	window.DlButtonColorPicker = D;

})();
