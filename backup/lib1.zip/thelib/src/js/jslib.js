(function(){
	var UA = navigator.userAgent, w = window;
	w.is_gecko = /gecko/i.test(UA);
	w.is_opera = /opera/i.test(UA);
	w.is_ie = /msie/i.test(UA) && !is_opera && !(/mac_powerpc/i.test(UA));
	w.is_ie5 = is_ie && /msie 5\.[^5]/i.test(UA);
	w.is_ie6 = is_ie && /msie 6/i.test(UA);
	w.is_ie7 = is_ie && /msie 7/i.test(UA);
	w.ie_box_model = is_ie && document.compatMode && document.compatMode == "BackCompat";
	w.is_mac_ie = /msie.*mac/i.test(UA);
	w.is_khtml = /Konqueror|Safari|KHTML/i.test(navigator.userAgent);
	w.is_safari = /Safari/i.test(navigator.userAgent);
})();

(function() {
	var F = Function.prototype;
	var A = Array.prototype;
	var D = Date.prototype;

	// Object inheritance

	if (!F.inherits)
		F.inherits = function(base) {
			var p = (this.prototype = new base);
			p.constructor = this;
			p._objectType = Dynarch.getFunctionName(this);
			if (typeof p.__patchSubclassPrototype == "function")
				p.__patchSubclassPrototype();
 			// p.BASE = function() { return base.prototype; };
			return base.prototype;
		};

	// Array extensions

	if (!A.foreach)
		A.foreach = function(f, obj) {
			if (obj == null)
				obj = this;
			var i = 0, l = this.length;
			while (l-- > 0)
				f.call(obj, this[i], i++);
			return this;
		};

	if (!A.r_foreach)
		A.r_foreach = function(f, obj) {
			if (obj == null)
				obj = this;
			for (var i = this.length; --i >= 0;)
				f.call(obj, this[i], i);
			return this;
		};

	if (!A.map)
		A.map = function(f, obj) {
			if (obj == null)
				obj = this;
			var i = 0, l = this.length, a = new Array(l);
			while (l-- > 0)
				a[i] = f.call(obj, this[i], i++);
			return a;
		};

	if (!A.r_map)
		A.r_map = function(f, obj) {
			if (obj == null)
				obj = this;
			var i = this.length, a = new Array(i);
			while (--i >= 0)
				a[i] = f.call(obj, this[i], i);
			return a;
		};

	if (!A.grep)
		A.grep = function(re) {
			var i = 0, l = this.length, a = [], el;
			while (l-- > 0) {
				el = this[i++];
				re.test(el) && a.push(el);
			}
			return a;
		};

	if (!A.contains)
		A.contains = function(el) {
			for (var i = this.length; --i >= 0;)
				if (this[i] === el)
					return true;
			return false;
		};

	if (!A.find)
		A.find = function(el) {
			for (var i = this.length; --i >= 0;)
				if (this[i] === el)
					return i;
			return -1;
		};

	if (!A.remove)
		A.remove = function(el) {
			for (var i = this.length; --i >= 0;)
				if (this[i] === el)
					this.splice(i, 1);
			return this;
		};

	if (!A.qsort)
		A.qsort = function(cmp, reverse) {
			if (this.length < 2)
				return;
			var _cmp, a = this, tmp, modified = false;
			if (reverse) {
				if (typeof cmp == "function") _cmp = function(el1, el2) { return cmp(el2, el1); };
				else _cmp = function(el2, el1) { return (el1 < el2) ? -1 : ((el1 > el2) ? 1 : 0); };
			} else {
				if (typeof cmp == "function") _cmp = cmp;
				else _cmp = function(el1, el2) { return (el1 < el2) ? -1 : ((el1 > el2) ? 1 : 0); };
			}
			function _qs(st, en) {
				var j = st, k = en, sw = false;
				if (j < k) {
					do {
						if (_cmp(a[j], a[k]) > 0) {
							tmp = a[j];
							a[j] = a[k];
							a[k] = tmp;
							sw = !sw;
							modified = true;
						}
						sw ? --k : ++j;
					} while (j < k);
					_qs(st, j - 1);
					_qs(j + 1, en);
				}
			};
			_qs(0, this.length - 1);
			return modified;
		};

	if (!A.peek)
		A.peek = function() {
			if (this.length > 0)
				return this[this.length - 1];
		};

	if (!A.__old_join) {
		A.__old_join = A.join;
		A.join = function(s) {
			if (s == null)
				s = "";
			return this.__old_join(s);
		};
	}

	if (!Number.prototype.times)
		Number.prototype.times = function(f, obj) {
			var i = this, j = 0;
			while (--i >= 0)
				f.call(obj, j++, i);
		};

	if (!Number.prototype.hex) {
		var HEX_DIGITS = [ "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" ];
		Number.prototype.hex = function(width) {
			var n = this, ret = [];
			do
				ret.unshift(HEX_DIGITS[n & 0xF]);
			while ((n >>= 4) > 0);
			if (width != null) {
				n = width - ret.length;
				while (n-- > 0)
					ret.unshift("0");
			}
			return ret.join();
		};
	}

	/* Can't understand why JS 1.5 standard defines the following 2
	 * functions to take only 2 arguments.  Brain dead.
	 */
	Math.max = function() {
		var n = arguments.length, max = arguments[--n];
		while (--n >= 0)
			if (arguments[n] > max)
				max = arguments[n];
		return max;
	};

	Math.min = function() {
		var n = arguments.length, min = arguments[--n];
		while (--n >= 0)
			if (arguments[n] < min)
				min = arguments[n];
		return min;
	};

	Date._MD = [ 31,28,31,30,31,30,31,31,30,31,30,31 ];
	Date.SECOND = 1000;
	Date.MINUTE = 60 * Date.SECOND;
	Date.HOUR   = 60 * Date.MINUTE;
	Date.DAY    = 24 * Date.HOUR;
	Date.WEEK   =  7 * Date.DAY;

	Date._MN = [ "January",
		     "February",
		     "March",
		     "April",
		     "May",
		     "June",
		     "July",
		     "August",
		     "September",
		     "October",
		     "November",
		     "December" ];

	Date._SMN = [ "Jan",
		      "Feb",
		      "Mar",
		      "Apr",
		      "May",
		      "Jun",
		      "Jul",
		      "Aug",
		      "Sep",
		      "Oct",
		      "Nov",
		      "Dec" ];

	Date._DN = [ "Sunday",
		     "Monday",
		     "Tuesday",
		     "Wednesday",
		     "Thursday",
		     "Friday",
		     "Saturday",
		     "Sunday" ];

	Date._SDN = [ "Su",
		      "Mo",
		      "Tu",
		      "We",
		      "Th",
		      "Fr",
		      "Sa",
		      "Su" ];

	Date._FDOW = 1;

	if (!Date.isWeekend)
		Date.isWeekend = function(day) {
			return day == 0 || day == 6;
		};

	if (!D.getMonthDays)
		D.getMonthDays = function(m) {
			var y = this.getFullYear();
			if (m != null)
				m = this.getMonth();
			return
				(((0 == (y%4)) && ( (0 != (y%100)) || (0 == (y%400)))) && m == 1)
				? 29 : Date._MD[m];
		};

	if (!D.getDayOfYear)
		D.getDayOfYear = function() {
			var now = new Date(this.getFullYear(), this.getMonth(), this.getDate(), 0, 0, 0);
			var then = new Date(this.getFullYear(), 0, 0, 0, 0, 0);
			var time = now - then;
			return Math.floor(time / Date.DAY);
		};

	if (!D.getWeekNumber)
		D.getWeekNumber = function() {
			var d = new Date(this.getFullYear(), this.getMonth(), this.getDate(), 0, 0, 0);
			var DoW = d.getDay();
			d.setDate(d.getDate() - (DoW + 6) % 7 + 3); // Nearest Thu
			var ms = d.valueOf(); // GMT
			d.setMonth(0);
			d.setDate(4); // Thu in Week 1
			return Math.round((ms - d.valueOf()) / (7 * 864e5)) + 1;
		};

	if (!D.dateEqualsTo)
		D.dateEqualsTo = function(date, monthOnly) {
			return this.getFullYear() == date.getFullYear()
				&& this.getMonth() == date.getMonth()
				&& (monthOnly || this.getDate() == date.getDate());
		};

	if (!D.print)
		D.print = function (str) {
			var m = this.getMonth();
			var d = this.getDate();
			var y = this.getFullYear();
			var wn = this.getWeekNumber();
			var w = this.getDay();
			var s = {};
			var hr = this.getHours();
			var pm = (hr >= 12);
			var ir = (pm) ? (hr - 12) : hr;
			var dy = this.getDayOfYear();
			if (ir == 0)
				ir = 12;
			var min = this.getMinutes();
			var sec = this.getSeconds();
			s["%a"] = Date.getDayName(w, true); // abbreviated weekday name [FIXME: I18N]
			s["%A"] = Date.getDayName(w); // full weekday name
			s["%b"] = Date.getMonthName(m, true); // abbreviated month name [FIXME: I18N]
			s["%B"] = Date.getMonthName(m); // full month name
			// FIXME: %c : preferred date and time representation for the current locale
			s["%C"] = 1 + Math.floor(y / 100); // the century number
			s["%d"] = (d < 10) ? ("0" + d) : d; // the day of the month (range 01 to 31)
			s["%e"] = d; // the day of the month (range 1 to 31)
			// FIXME: %D : american date style: %m/%d/%y
			// FIXME: %E, %F, %G, %g, %h (man strftime)
			s["%H"] = (hr < 10) ? ("0" + hr) : hr; // hour, range 00 to 23 (24h format)
			s["%I"] = (ir < 10) ? ("0" + ir) : ir; // hour, range 01 to 12 (12h format)
			s["%j"] = (dy < 100) ? ((dy < 10) ? ("00" + dy) : ("0" + dy)) : dy; // day of the year (range 001 to 366)
			s["%k"] = hr;		// hour, range 0 to 23 (24h format)
			s["%l"] = ir;		// hour, range 1 to 12 (12h format)
			s["%m"] = (m < 9) ? ("0" + (1+m)) : (1+m); // month, range 01 to 12
			s["%M"] = (min < 10) ? ("0" + min) : min; // minute, range 00 to 59
			s["%n"] = "\n";		// a newline character
			s["%p"] = pm ? "PM" : "AM";
			s["%P"] = pm ? "pm" : "am";
			// FIXME: %r : the time in am/pm notation %I:%M:%S %p
			// FIXME: %R : the time in 24-hour notation %H:%M
			s["%s"] = Math.floor(this.getTime() / 1000);
			s["%S"] = (sec < 10) ? ("0" + sec) : sec; // seconds, range 00 to 59
			s["%t"] = "\t";		// a tab character
			// FIXME: %T : the time in 24-hour notation (%H:%M:%S)
			s["%U"] = s["%W"] = s["%V"] = (wn < 10) ? ("0" + wn) : wn;
			s["%u"] = w + 1;	// the day of the week (range 1 to 7, 1 = MON)
			s["%w"] = w;		// the day of the week (range 0 to 6, 0 = SUN)
			// FIXME: %x : preferred date representation for the current locale without the time
			// FIXME: %X : preferred time representation for the current locale without the date
			s["%y"] = ('' + y).substr(2, 2); // year without the century (range 00 to 99)
			s["%Y"] = y;		// year with the century
			s["%%"] = "%";		// a literal '%' character

			var re = /%./g;
			return str.replace(re, function (par) { return s[par] || par; });

			var a = str.match(re);
			for (var i = 0; i < a.length; i++) {
				var tmp = s[a[i]];
				if (tmp) {
					re = new RegExp(a[i], 'g');
					str = str.replace(re, tmp);
				}
			}

			return str;
		};

	if (!Date.getMonthName)
		Date.getMonthName = function(mon, sh) {
			var a = sh ? Date._SMN : Date._MN;
			return a[mon % 12];
		};

	if (!Date.getFirstDayOfWeek)
		Date.getFirstDayOfWeek = function() {
			return Date._FDOW;
		};

	if (!Date.getDayName)
		Date.getDayName = function(day, sh) {
			var a = sh ? Date._SDN : Date._DN;
			return a[day % 7];
		};

	window.Dynarch = {
		// functions to cope with objects in JavaScript
		// merge an object
		merge : function(dest, src) {
			for (var i in src)
				dest[i] = src[i];
		},

		// copy an object
		copy : function(dest, src) {
			for (var i in dest)
				delete dest[i];
			Dynarch.merge(dest, src);
		},

		// return a copy of a given object
		makeCopy : function(src) {
			var dest = {};
			for (var i in src)
				dest[i] = src[i];
			return dest;
		},

		// merge src into dest but only those properties that are
		// undefined in dest
		mergeUndefined : function(dest, src) {
			for (var i in src)
				if (typeof dest[i] == "undefined")
					dest[i] = src[i];
		},

		// create an array from an object which is not an array but
		// behaves like one (has length and can be indexed with [])
		makeArray : function(obj, start) {
			if (start == null)
				start = 0;
			var a, i, j;
			try {
				a = A.slice.call(obj, start);
			} catch (ex) {
				a = new Array(obj.length - start);
				for (i = start, j = 0; i < obj.length; ++i, ++j)
					a[j] = obj[i];
			}
			return a;
		},

		// Call this in the context of some object.  Sets the default
		// properties of "this" according to their description in
		// defaults.  Can throw an exception if invalid data was
		// passed.
		setDefaults : function(defaults, args, overwrite) {
			var i, val, def, inst;
			for (i in defaults) {
				if (overwrite || typeof this[i] == "undefined") {
					def = defaults[i];
					val = args[def[0]];
					if (typeof val == "undefined")
						val = def[1];
					this[i] = val;
				}
			}
		},

		_ids : {},
		ID : function(namespace) {
			if (namespace == null)
				namespace = "generic";
			if (typeof this._ids[namespace] == "undefined")
				this._ids[namespace] = 0;
			return "dynarch-" + namespace + "-" + (++this._ids[namespace]);
		},

		getFunctionName : function(f) {
			if (f.name)
				return f.name;
			else if (/function\s+(\$?[a-z0-9_]+)\(/i.test(f.toString()))
				return RegExp.$1;
			return "UNKNOWN_FUNCTION";
		},

		noop : function(){}
	};

	window.DynarchDomUtils = {
		related : function(element, ev) {
			var related, type;
			if (is_ie) {
				type = ev.type;
				if (type == "mouseover")
					related = ev.fromElement;
				else if (type == "mouseout")
					related = ev.toElement;
			} else
				related = ev.relatedTarget;
			try { // Gecko brain dead exception
				for (; related; related = related.parentNode)
					if (related === element)
						return true;
			} catch(ex) {};
			return false;
		},

		addEvent : function(el, evname, func) {
			if (el.addEventListener)
				el.addEventListener(evname, func, true);
			else if (el.attachEvent)
				el.attachEvent("on" + evname, func);
			else
				el["on" + evname] = func;
		},
		addEvents : function(el, evs, func) {
			for (var i = evs.length; --i >= 0;)
				DynarchDomUtils.addEvent(el, evs[i], func);
		},
		removeEvent : function(el, evname, func) {
			if (el.removeEventListener)
				el.removeEventListener(evname, func, true);
			else if (el.detachEvent)
				el.detachEvent("on" + evname, func);
			else
				el["on" + evname] = "";
		},
		removeEvents : function(el, evs, func) {
			for (var i = evs.length; --i >= 0;)
				DynarchDomUtils.removeEvent(el, evs[i], func);
		},
		stopEvent : function(ev) {
			if (is_ie) {
				ev.cancelBubble = true;
				ev.returnValue = false;
			} else {
				ev.preventDefault();
				ev.stopPropagation();
			}
			return false;
		},

		callHandler : function(obj, method) {
			if (!obj[method])
				return;
			if (typeof obj[method] == "function")
				obj[method].call(obj);
			else if (typeof obj[method] == "string")
				eval(obj[method]);
		},
		setStyleProperty : function(el, prop, val) {
			switch (prop) {
			    case "float":
				prop = "styleFloat";
				break;
			    default:
				prop = prop.replace(/-([a-z])/gi, function(s, p1) {
					return '-' + p1.toUpperCase();
				});
			}
			el.style[prop] = val;
		},

		getClosestParentByTagName : function(el, tag) {
			tag = tag.toLowerCase();
			while (el && el.tagName && el.tagName.toLowerCase() != tag)
				el = el.parentNode;
			return el;
		},

		isInside : function(el, parent) {
			try {
				while (el) {
					if (el === parent)
						return true;
					el = el.parentNode;
				}
			} catch(ex) {}
			return false;
		},

		getWindowSize : function() {
			if (is_gecko) {
				if (document.documentElement.clientWidth)
					return { x: document.documentElement.clientWidth, y: document.documentElement.clientHeight };
				else
					return { x: window.innerWidth, y: window.innerHeight };
			}
			if (is_opera)
				return { x: window.innerWidth, y: window.innerHeight };
			if (is_ie) {
				if (!document.compatMode || document.compatMode == "BackCompat")
					return { x: document.body.clientWidth, y: document.body.clientHeight };
				else
					return { x: document.documentElement.clientWidth, y: document.documentElement.clientHeight };
			}
			// let's hope we never get to use this hack.
			var div = document.createElement("div"), s = div.style;
			s.position = "absolute";
			s.bottom = s.right = "0px";
			document.body.appendChild(div);
			s = { x: div.offsetLeft, y: div.offsetTop };
			document.body.removeChild(div);
			return s;
		},

// 		getPos : function(el) {
// 			DynarchDomUtils.addClass(el, "DYNARCH-GET-ABSOLUTE-POSITION");
// 			var pos = this._getPos(el);
// 			// var pos = { x: el.offsetLeft, y: el.offsetTop };
// 			DynarchDomUtils.delClass(el, "DYNARCH-GET-ABSOLUTE-POSITION");
// 			return pos;
// 		},

		getPos : function (el) {
// 			if (/^body$/i.test(el.tagName))
// 				return { x: 0, y: 0 };
			var r;
			r = { x: el.offsetLeft, y: el.offsetTop };
			el = el.offsetParent;
			while (el != null) {
				if (el.scrollLeft)
					r.x -= el.scrollLeft;
				if (el.scrollTop)
					r.y -= el.scrollTop;
				r.x += el.offsetLeft;
				r.y += el.offsetTop;
				el = el.offsetParent;
			}
			return r;
		},

		createElement : function(tag, st, at, par, pos) {
			var el, i;
			if (document.createElementNS)
				el = document.createElementNS("http://www.w3.org/1999/xhtml", tag);
			else
				el = document.createElement(tag);
			if (st) for (i in st)
				if (is_ie)
					DynarchDomUtils.setStyleProperty(el, i, st[i]);
				else
					el.style.setProperty(i, st[i], "");
			if (at) for (i in at)
				// el.setAttribute(i, at[i]);
				el[i] = at[i];
			if (par) {
				if (typeof pos == "integer")
					pos = par.childNodes[pos];
				if (!pos)
					pos = null;
				par.insertBefore(el, pos);
			}
			return el;
		},

		setUnselectable : function(el) {
			if (!is_ie) {
				el.style.MozUserSelect = "none";
				el.style.userSelect = "none";
			} else {
				var els = Dynarch.makeArray(el.getElementsByTagName("*"));
				els.push(el);
				els.foreach(function(el) { el.unselectable = "on"; });
			}
		},

		addClass : function(el, ac, dc) {
			if (el) {
				if (dc)
					DynarchDomUtils.delClass(el, dc);
				DynarchDomUtils.delClass(el, ac);
				el.className += " " + ac;
			}
		},
		delClass : function(el, dc, ac) {
			if (el) {
				if (typeof dc == "string") {
					var a = el.className.split(" ");
					a.remove(dc);
					if (ac)
						a.push(ac);
					el.className = a.join(" ");
				} else
					el.className = el.className.replace(dc, "");
			}
		},
		condClass : function(el, cond, clsTrue, clsFalse) {
			cond
				? DynarchDomUtils.addClass(el, clsTrue, clsFalse)
				: DynarchDomUtils.delClass(el, clsTrue, clsFalse);
		},

		getPaddingAndBorder : function(el) {
			DynarchDomUtils.addClass(el, "DYNARCH-GET-PADDING-AND-BORDER");
			dx = el.offsetWidth - 1;
			dy = el.offsetHeight - 1;
			DynarchDomUtils.delClass(el, "DYNARCH-GET-PADDING-AND-BORDER");
			return { x: dx, y: dy };
		},

		setOuterSize : function(el, x, y) {
			var pb = DynarchDomUtils.getPaddingAndBorder(el);
			DynarchDomUtils.setInnerSize(el, x - pb.x, y - pb.y);
		},

		setInnerSize : function(el, x, y) {
			if (typeof x == "number") x += "px";
			if (typeof y == "number") y += "px";
			if (x != null)
				el.style.width = x;
			if (y != null)
				el.style.height = y;
		},

		getOuterSize : function(el) {
			return { x: el.offsetWidth, y: el.offsetHeight };
		},

		getInnerSize : function(el) {
			var s = DynarchDomUtils.getOuterSize(el);
			var pb = DynarchDomUtils.getPaddingAndBorder(el);
			s.x -= pb.x;
			s.y -= pb.y;
			// amazing, eh?
			return s;
		},

		importCommonVars : function() {
			return [ "var DOM=DynarchDomUtils",
				 "AC=DOM.addClass",
				 "DC=DOM.delClass",
				 "CC=DOM.condClass",
				 "CE=DOM.createElement" ].join(",");
		}

	};

	if (is_safari || is_ie5) {
		if (!String.prototype.__old_replace) {
			String.prototype.__old_replace = String.prototype.replace;
			String.prototype.replace = function(re, val) {
				if (typeof val != "function")
					return this.__old_replace(re, val);
				else {
					// TODO: investigate if it's possible to use the array.join approach
					var str = this.slice(0), v, l, a;
					while (a = re.exec(str)) {
						v = val.apply(null, a);
						l = a[0].length;
						re.lastIndex -= l - v.length;
						str = str.substr(0, a.index) + v + str.substr(a.index + l);
						if (!re.global)
							break;
					}
					return str;
				}
			};
		}
	}

})();

// This is the most important function I ever wrote.
// I'll let you guess why it's defined outside of another function :-)
Dynarch.makeClosure = function(f, obj) {
	var args = Dynarch.makeArray(arguments, 2);
	return function() {
		return f.apply(obj || this, args.concat(Dynarch.makeArray(arguments)));
	};
};

// And in fact, the above is so widely used that we could create a special
// shortcut to it.  Lemme think about it.
// var $ = Dynarch.makeClosure;

function DestroyObject(o, dbg) {
	for (var i in o) {
		if (dbg) {
			alert("Trying to remove " + i + " from " + dbg + "\n" + (typeof o));
		}
		if (/object/i.test(typeof o[i])) try {
			DestroyObject(o[i], dbg);
		} catch(ex) {};
		try { o[i] = null; } catch(ex) {}
		try { delete o[i]; } catch(ex) {}
	}
};
