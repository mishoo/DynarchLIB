// @require abstractbutton.js

(function() {

	var CLS = { active    : "DlButton-active",
		    hover     : "DlButton-hover",
		    checked   : "DlButton-1",
		    unchecked : "DlButton-0",
		    empty     : "DlButton-empty",
		    disabled  : "DlButton-disabled"
	};

	eval(DynarchDomUtils.importCommonVars());

	var DEFAULT_ARGS = {
		_classes   : [ "classes"   , CLS ],
		_iconClass : [ "iconClass" , null ]
	};

	var BASE = DlButton.inherits(DlAbstractButton);
	function DlButton(args, classes) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
			this.setIconClass(this._iconClass);
			this._iconClass = null;
		}
	};

	DlButton.TYPE = DlAbstractButton.TYPE;

	var P = DlButton.prototype;

	P._createLabelElement = function() {
		this.getElement().innerHTML = "<div class='DlButton-inner'><div></div></div>";
	};

	P.getContentElement = function() {
		return this.getElement().firstChild.firstChild;
	};

	P.setSize = P.setOuterSize = function(size) {
		BASE.setOuterSize.call(this, size);
		var el = this.getElement();
		size = DOM.getInnerSize(el);
		DOM.setOuterSize(this.getContentElement(), size.x, size.y);
		el.style.width = el.style.height = "";
	};

	P.setIconClass = function(iconClass) {
		var e2 = this.getContentElement();
		CC(e2, iconClass != null, this._className.peek() + "-withIcon");
		if (this.iconClass)
			DC(e2, this.iconClass);
		if (iconClass)
			AC(e2, iconClass);
		this.iconClass = iconClass;
	};

	window.DlButton = DlButton;

})();
