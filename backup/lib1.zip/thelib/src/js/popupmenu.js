// @require popup.js

function DlMenuBase(args) {
	if (this._isMenuBase)
		return;
	this._isMenuBase = true;
	this._items = [];

	var self = this;
	function onNamedItemSelect() {
		DlPopup.clearAllPopups();
		var me = this;
		setTimeout(function() {
			self.applyHooks("onSelect", [ me.name, me ]);
		}, 1);
	};

	// whatever container we are in, we patch the appendWidget function
	// (which will presumably used to append items) in order to keep an
	// array of menu items.
	this.__default_appendWidget = this.appendWidget;
	this.appendWidget = function(w) {
		if (w instanceof DlMenuItem) {
			this._items.push(w);
			if (w.name)
				w.addEventListener("onSelect", onNamedItemSelect);
		}
		this.__default_appendWidget.apply(this, Dynarch.makeArray(arguments));
	};

	this.parentMenu = null;

	var popup = null;
	this.getPopup = function(noCreate) {
		if (!popup && !noCreate) {
			popup = new DlPopupMenu({ parent: this });
			popup.parentMenu = this;
			if (this instanceof DlHMenu) {
				popup.DEFAULT_INSTALL_ALIGN = {
					prefer: "Br",
					fallX1: "__",
					fallX2: "_L",
					fallY1: "__",
					fallY2: "T_"
				};
				popup.addEventListener("onBeforePopup", DlMenuBase.BLOCK_ONMOUSEOVER);
// 				popup.correctPos = function(pos) {
// 					if (is_gecko) {
// 						--pos.x;
// 						--pos.y;
// 					}
// 				};
			} else {
				popup.correctPos = function(pos) {
					var menu = this.popupArgs().content();
					var el = menu.getElement();
					pos.y -= el.firstChild.offsetTop;
// 					if (is_gecko) {
// 						if (menu.parentMenu && menu.parentMenu.parentMenu) {
// 							--pos.y;
// 							--pos.x;
// 						} else
// 							++pos.x;
// 					}
				};
			}
		}
		return popup;
	};
};

DlMenuBase.BLOCK_ONMOUSEOVER = function(args, ev) {
	if ((ev.dl_type == "onMouseOver" || ev.dl_type == "onMouseEnter") && !this.visible)
		DlException.blockDefaultEvent();
};

(function() {

	var BASE = DlPopupMenu.inherits(DlPopup);
	function DlPopupMenu(args) {
		if (args) {
			BASE.constructor.call(this, args);
		}
	};

	var P = DlPopupMenu.prototype;

	P.DEFAULT_INSTALL_EVENTS = { on          : "onMouseEnter",
				     on_i        : "onMouseDown",
				     off         : "onMouseLeave"
	};

	P.DEFAULT_INSTALL_ALIGN = {
		prefer: "bR",
		fallX1: "__",
		fallX2: "_L",
		fallY1: "__",
		fallY2: "t_"
	};

	P.DEFAULT_TIMEOUTS = { on: 150, off: 400 };

	function onMouseEnter() {
		if (this.popupArgs() && this.popupArgs().widget.activate)
			this.popupArgs().widget.activate(true);
	};

	function onMouseLeave(ev) {
		if (this.popupArgs() && this.popupArgs().widget.activate)
			this.popupArgs().widget.activate(false);
	};

	P._setListeners = function() {
		BASE._setListeners.call(this);
		this.addEventListener("onMouseEnter", onMouseEnter);
		this.addEventListener("onMouseLeave", onMouseLeave);
		this.addEventListener("onHide", onMouseLeave);
	};

	window.DlPopupMenu = DlPopupMenu;

})();

(function() {

	var BASE = DlHMenu.inherits(DlHbox);
	function DlHMenu(args) {
		if (args) {
			BASE.constructor.call(this, args);
			DlMenuBase.call(this, args);
		}
	};

// 	DlHMenu._createCellElement = function() {
// 		var td = BASE._createCellElement.call(this);
// 		var prev = td.previousSibling;
// 		if (prev)
// 			prev.style.width = "1px";
// 		return td;
// 	};

	DlHMenu.prototype.initDOM = function() {
		this.registerEvents([ "onSelect" ]);
		BASE.initDOM.call(this);
	};

	window.DlHMenu = DlHMenu;

})();

(function() {

	var BASE = DlVMenu.inherits(DlVbox);
	function DlVMenu(args) {
		if (args) {
			BASE.constructor.call(this, args);
			DlMenuBase.call(this, args);
		}
	};

	DlVMenu.prototype.initDOM = function() {
		this.registerEvents([ "onSelect" ]);
		BASE.initDOM.call(this);
	};

	window.DlVMenu = DlVMenu;

})();

(function() {

	var DEFAULT_ARGS = {
		label      : [ "label",     "DlMenuItem" ],
		_iconClass : [ "iconClass", null ],
		parentMenu : [ "menu",      null ],
		name       : [ "name",      null ]
	};

	var BASE = DlMenuItem.inherits(DlContainer);
	function DlMenuItem(args) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
			if (!this.parentMenu)
				this.parentMenu = this.parent;
		}
	};

	var P = DlMenuItem.prototype;

	P.initDOM = function() {
		this.registerEvents([ "onSelect" ]);
		BASE.initDOM.call(this);
	};

	P._createElement = function() {
		BASE._createElement.call(this);
		var el = this.getElement();
		el.innerHTML = [ '<div class="div1"><div class="div2"><div class="div3">',
				 '</div></div></div>' ].join();
		this.setIconClass(this._iconClass);
		this._iconClass = null;
		this.setUnselectable();
		if (this.label)
			this.setContent(this.label);
	};

	P.getContentElement = function() {
		return this.getElement().firstChild.firstChild.firstChild;
	};

	P.setIconClass = DlButton.prototype.setIconClass;	// ALIAS

	P.getPopup = function(nocreate) {
		return this.parentMenu.getPopup(nocreate);
	};

	function onMouseEnter(ev) {
		this.addClass("DlMenuItem-hover");
		this.delClass("DlMenuItem-active");
		var p = this.getPopup(true);
		if (p && p.visible && !this._menu) {
			p._handle_off();
		}
	};

	function onMouseLeave() {
		this.delClass("DlMenuItem-hover");
		this.delClass("DlMenuItem-active");
	};

	function onMouseUp() {
		this.delClass("DlMenuItem-active");
		this.callHooks("onSelect");
	};

	function onMouseDown() {
		this.addClass("DlMenuItem-active");
	};

	P._setListeners = function() {
		BASE._setListeners.call(this);
		this.addEventListener("onMouseEnter", onMouseEnter);
		this.addEventListener("onMouseLeave", onMouseLeave);
		this.addEventListener("onMouseDown", onMouseDown);
		this.addEventListener("onMouseUp", onMouseUp);
	};

	P.getMenu = function() {
		var menu = this._menu;
		if (typeof menu == "function")
			menu = menu();
		menu.parentMenu = this.parentMenu;
		var p1 = menu._thisPopup = this.getPopup();
		var p2 = this.parentMenu.parentMenu;
		if (p2)
			p2 = p2.getPopup(true);
		if (p2)
			p1.attachToPopup(p2);
		return menu;
	};

	P.setMenu = function(menu) {
		this._menu = menu;
		this.condClass(menu, "DlMenuItem-withPopup");
		var popup = this.getPopup();
		var content = Dynarch.makeClosure(this.getMenu, this);
		popup.install({ widget: this, content: content });
	};

	P.activate = function(act) {
		this.condClass(act, "DlMenuItem-active");
		//this.condClass(act, "DlMenuItem-hover");
	};

	window.DlMenuItem = DlMenuItem;

})();
