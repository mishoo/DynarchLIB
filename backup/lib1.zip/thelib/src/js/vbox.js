// @require box.js

(function() {

	var CE = DynarchDomUtils.createElement;
	var BASE = DlVbox.inherits(DlBox);
	function DlVbox(args) {
		if (args) {
			BASE.constructor.call(this, args);
		}
	};

	var P = DlVbox.prototype;

	P._createCellElement = function() {
		return CE("td", null, { className : "cell" },
			  CE("tr", null, { className : "row" }, this._tbody));
	};

	P._removeWidgetElement = function(w) {
		if (this._widgets.contains(w)) {
			var el = w.getElement();
			el.parentNode.parentNode.parentNode.removeChild(el.parentNode.parentNode);
		}
	};

	window.DlVbox = DlVbox;

})();
