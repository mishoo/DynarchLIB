//(function() {

	var bm = buttonmenu;

//	var newMenu = new DlVMenu({});
var newMenu = bm.getMenu();
	new DlMenuItem({ parent: newMenu, label: "You are in" });
	new DlMenuItem({ parent: newMenu, label: "foomenu.js" });
	new DlMenuItem({ parent: newMenu, label: "Now I say" });
	newMenu.addSeparator();
	new DlMenuItem({ parent: newMenu, label: "Cool shiznitz" });

//	bm.setMenu(newMenu);

//})();
