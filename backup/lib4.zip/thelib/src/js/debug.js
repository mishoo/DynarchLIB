function DEBUG(msg) {
	window.dump(msg + "\n");
};
