// @require hbox.js
// @require button.js
// @require popupmenu.js

(function() {

	var DEFAULT_ARGS = {
		"label"    : [ "label", null ]
	};

	var BASE = DlButtonMenu.inherits(DlHbox);
	function DlButtonMenu(args) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			DlMenuBase.call(this, args);
			BASE.constructor.call(this, args);
			this.registerEvents([ "onSelect" ]);
		}
	};

	var P = DlButtonMenu.prototype;

	var ALIGN = {
		prefer: "Bl",
		fallX1: "_r",
		fallX2: "_L",
		fallY1: "__",
		fallY2: "T_"
	};

	var EVENTS = { on_i : "onMouseDown" };

	function activateItem(active) {
		this.condClass(active, this._classes.active);
	};

	P._createElement = function() {
		BASE._createElement.call(this);
		this._mainBtn = new DlButton({ parent: this, label: this.label, className: "LabelPart" });
		this._menuBtn = new DlButton({ parent: this, label: "&nbsp;", className: "MenuArrow", noCapture: true });
		this._menuBtn.activate = activateItem;
		this._mainBtn.connectEvents([ "onMouseEnter", "onMouseLeave" ], this._menuBtn);
	};

	P.getMenu = function() {
		var menu = this._menu;
		if (typeof menu == "function")
			menu = menu();
		menu.parentMenu = this;
		menu._thisPopup = this.getPopup();
		return menu;
	};

	P.getButton = function() { return this._mainBtn; };
	P.getArrow = function() { return this._menuBtn; };

	P.setMenu = function(menu) {
		this._menu = menu;
		var popup = this.getPopup();
		var props = {
			widget   : this._menuBtn,
			anchor   : this.getTableElement(),
			align    : ALIGN,
			content  : Dynarch.makeClosure(this.getMenu, this),
			events   : EVENTS,
			timeouts : { off: 500 }
		};
		popup.install(props);
	};

	window.DlButtonMenu = DlButtonMenu;

})();
