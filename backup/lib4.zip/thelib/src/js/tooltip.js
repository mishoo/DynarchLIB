// @require popup.js

(function() {

	var BASE = DlTooltip.inherits(DlPopup);
	function DlTooltip(args) {
		if (args) {
			args.zIndex = 2000;
			BASE.constructor.call(this, args);
		}
	};

	var P = DlTooltip.prototype;

	P.DEFAULT_INSTALL_EVENTS = { on          : "onMouseEnter",
				     off         : [ "onMouseLeave", "onMouseDown" ],
				     reset_tm_on : "onMouseMove"
	};

	P.DEFAULT_INSTALL_ALIGN = "mouse";

	P.DEFAULT_TIMEOUTS = { on: 400 };

	window.DlTooltip = DlTooltip;

})();
