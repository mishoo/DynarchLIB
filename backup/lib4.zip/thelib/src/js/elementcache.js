// @require jslib.js

var DlElementCache = {
	get : function(tag) {
		return this[tag].cloneNode(true);
	}
};

(function(){

	eval(DynarchDomUtils.importCommonVars());

	var TBODY_RC = document.createDocumentFragment();
	CE("td", null, null,
	   CE("tr", null, null,
	      CE("tbody", null, null, TBODY_RC)));
	DlElementCache.TBODY_RC = TBODY_RC;

	var SHADOWS = document.createDocumentFragment();
	CE("div", null, { className: "Shadow Shadow-TL" }, SHADOWS);
	CE("div", null, { className: "Shadow Shadow-T" }, SHADOWS);
	CE("div", null, { className: "Shadow Shadow-TR" }, SHADOWS);
	CE("div", null, { className: "Shadow Shadow-L" }, SHADOWS);
	CE("div", null, { className: "Shadow Shadow-R" }, SHADOWS);
	CE("div", null, { className: "Shadow Shadow-BL" }, SHADOWS);
	CE("div", null, { className: "Shadow Shadow-B" }, SHADOWS);
	CE("div", null, { className: "Shadow Shadow-BR" }, SHADOWS);
	DlElementCache.SHADOWS = SHADOWS;

})();
