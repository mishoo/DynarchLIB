// @require widget.js

(function(){

	var DEFAULT_EVENTS = [ "onChange" ];

	var DEFAULT_ARGS = {
		_domType    : [ "type"       , "text" ],
		_value      : [ "value"      , null ],
		_size       : [ "size"       , null ],
		_readonly   : [ "readonly"   , false ],
		_validators : [ "validators" , [] ]
	};

	eval(DynarchDomUtils.importCommonVars());

	var BASE = DlEntry.inherits(DlContainer);
	function DlEntry(args) {
		if (args) {
			args.tagName = "table";
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			this._isTextArea = args.type == "textarea";
			BASE.constructor.call(this, args);
		}
	};

	var D = DlEntry;
	var P = D.prototype;

	P.validate = function(val) {
		if (val == null)
			val = this.getValue();
		var a = this._validators, i, v, err = false;
		for (i = 0; i < a.length; ++i) {
			v = a[i];
			if (!v.ok(val)) {
				err = true;
				break;
			}
		}
		if (v && !err)
			this.setValue(v.getLastVal(), true);
		// alert(err + " \n " + this._validators.length);
		this.condClass(err, "DlEntry-ValidationError");
	};

	P.focus = function() {
		this.getInputElement().focus();
		if (!this.readonly() && this._domType != "textarea")
			this.select();
	};

	P.blur = function() {
		this.getInputElement().blur();
	};

	P.select = function() {
		this.getInputElement().select();
	};

	function element_focus() {
		this.addClass("DlEntry-Focus");
		this.callHooks("onFocus");
	};

	function element_blur() {
		this.delClass("DlEntry-Focus");
		this.validate();
		this.callHooks("onBlur");
	};

	function element_change() {
		this.callHooks("onChange");
	};

	P._createElement = function() {
		BASE._createElement.call(this);
		var el = this.getElement();
		el.appendChild(DlElementCache.get("TBODY_RC"));
		el.cellSpacing = el.cellPadding = el.border = 0;
		el = el.rows[0].cells[0];
		var input = this._isTextArea
			? document.createElement("textarea")
			: input = document.createElement("input");
		input.setAttribute("autocomplete", "off", 1);
		if (this._domType == "password")
			input.type = "password";
		el.appendChild(input);
	};

	P.getInputElement = function() {
		return this.getElement().rows[0].cells[0].firstChild;
	};

	P.getContentElement = P.getInputElement; // ALIAS

	P.setValue = function(value, nocall) {
		this.getInputElement().value = value;
		if (!nocall)
			this.callHooks("onChange");
	};

	P.getValue = function() {
		return this.getInputElement().value;
	};

	function onChange() {
		this.validate();
	};

	P.initDOM = function() {
		this.registerEvents(DEFAULT_EVENTS);
		BASE.initDOM.call(this);
		var input = this.getInputElement();
		DOM.addEvent(input, "focus", Dynarch.makeClosure(element_focus, this));
		DOM.addEvent(input, "blur", Dynarch.makeClosure(element_blur, this));
		DOM.addEvent(input, "change", Dynarch.makeClosure(element_change, this));
		this.addEventListener("onChange", onChange);
		if (this._value != null)
			this.setValue(this._value);
		if (this._size != null)
			input.size = this._size;
		this.readonly(this._readonly);
		delete this._readonly;
		delete this._value;
	};

	P.readonly = function(readonly) {
		var input = this.getInputElement();
		if (readonly != null) {
			input.readOnly = readonly;
			readonly
				? input.setAttribute("readonly", true, 1)
				: input.removeAttribute("readonly");
			this.condClass(readonly, "DlEntry-Readonly");
		}
		return input.getAttribute("readonly");
	};

	P.disabled = function(v, force) {
		var isDisabled = BASE.disabled.call(this, v, force);
		if (v != null)
			this.getInputElement().disabled = !!v;
		return isDisabled;
	};

	window.DlEntry = D;

})();
