// @require jslib.js
// @require exception.js

function DlEventListener() {
	this._hooks = {};
	this.registerEvents([ "onDestroy" ]);
};

(function() {

	// private stuff
	function getHooks(o, ev) {
		var a = o._hooks[ev.toLowerCase()];
		if (!a)
			throw new DlException("Event [" + ev + "] not registered.");
		return a;
	};

	function _connect_callback(w2, e2) {
		return w2.applyHooks(e2, Dynarch.makeArray(arguments, 2));
	};

	// public
	var P = {
		registerEvents : function(evs) {
			evs.foreach(function(e) {
				e = e.toLowerCase();
				if (!this._hooks[e])
					this._hooks[e] = [];
			}, this);
		},
		addEventListener : function(ev, handler, phase) {
			if (ev instanceof Array) {
				ev.foreach(function(ev) {
					this.addEventListener(ev, handler, phase);
				}, this);
			} else {
				var a = getHooks(this, ev);
				phase
					? a.unshift(handler)
					: a.push(handler);
			}
		},
		connectEvents : function(e1, w2, e2, reverse) {
			if (!e2)
				e2 = e1;
			if (e1 instanceof Array) {
				for (var i = 0; i < e1.length; ++i)
					this.connectEvents(e1[i], w2, e2[i], reverse);
			} else {
				this.addEventListener(
					e1,
					Dynarch.makeClosure(
						_connect_callback, null, w2, e2));
			}
		},
		removeEventListener : function(ev, handler) {
			if (ev instanceof Array) {
				ev.foreach(function(ev) {
					this.removeEventListener(ev, handler);
				}, this);
			} else {
				getHooks(this, ev).remove(handler);
			}
		},
		callHooks : function(ev) {
			var args = arguments.length > 1
				? Dynarch.makeArray(arguments, 1)
				: [];
			return this.applyHooks(ev, args);
		},
		applyHooks : function(ev, args) {
			var self = this;
			var ret = [];
			try {
				//var id = this.id || "-";
				//DEBUG("EVENT HOOKS: " + ev + " on " + id);
				getHooks(self, ev).foreach(function(f) {
					ret.push(f.apply(self, args));
				});
			} catch(ex) {
				if (!(ex instanceof DlExStopEventProcessing))
					throw ex;
			}
			return ret;
		},

		// this SHOULD NOT be overridden.  Register an onDestroy event
		// handler if you wish to be able to do stuff when this happens
		destroy : function() {
			if (!this.destroyed) {
				this.destroying = true;
				this.callHooks("onDestroy");
				this._hooks = null;
				this.destroying = false;
			}
		}
	};
	Dynarch.merge(DlEventListener.prototype, P);

})();
