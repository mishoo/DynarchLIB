// @require eventlistener.js
// @require singleton.js

(function(){

	var DEFAULT_EVENTS = [ "onDialogCreate",
			       "onDialogShow",
			       "onDialogHide",
			       "onDialogMinimize",
			       "onDialogRestore"
	];

	var BASE = DlSystem.inherits(DlEventListener);
	function DlSystem() {
		BASE.constructor.call(this);
		this.registerEvents(DEFAULT_EVENTS);
	};

	var P = DlSystem.prototype;

	DlSingleton.register("System", DlSystem);

})();
