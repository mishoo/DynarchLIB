var d = new DlDialog({ title: "Test dialog" });
//d.setOuterSize({ x: 400 });

var menu = new DlHMenu({ parent: d });

var vvbox = new DlVbox({ parent: d });
//vvbox.getTableElement().style.width = "100%";
vvbox.getElement().style.padding = "0 10px";

var vbox = new DlVbox({ parent: vvbox, borderSpacing: 1 });
vbox.getTableElement().style.margin = "10px auto 6px auto";

var hbox = new DlHbox({ parent: vbox });
new DlAbstractButton({ parent: hbox, label: "Please enter your birthday: " });
new DlButtonCalendar({ parent: hbox, calendar: { weekNumbers: true }});

var hbox = new DlHbox({ parent: vbox });
new DlAbstractButton({ parent: hbox, label: "Your favorite color: " });
var cb = new DlButtonColorPicker({ parent: hbox, color: "#0f8" });
cb.setColorPicker(new DlColorPickerHSV({}));
cb.addEventListener("onSelect", function(rgb, hsv, color, brightness) {
	this.setLabel("#" + DlColor.RGB2hex(rgb));
});

var hbox = new DlHbox({ parent: vbox });
new DlAbstractButton({ parent: hbox, label: "Please enter your birthday: " });
new DlButtonCalendar({ parent: hbox, calendar: { navigation: 0, navDisabled: true, omDisabled: true, weekNumbers: true } });

var hbox = new DlHbox({ parent: vbox });
new DlAbstractButton({ parent: hbox, label: "Please enter your birthday: " });
var tmp = new DlButtonCalendar({ parent: hbox, tooltip: "A nice cool tooltip" });

var hbox = new DlHbox({ parent: vbox });
var entry = new DlEntry({ parent: hbox, type: "textarea", value: "ckt cu mak", readonly: true });
new DlButton({ parent: hbox, label: "Check size" }).addEventListener("onClick", function() {
	entry.setValue("Size checked yo man");
 	var s = d.getOuterSize();
 	d.setOuterSize({ x: s.x + 1 });
});

var hbox = new DlHbox({ parent: vbox });
var val = new DlValidator(DlValidator.Number, -5, 10, false, 2);
var entry = new DlEntry({ parent: hbox, validators: [ val ] });
hbox.addSeparator();
var spinner = new DlSpinner({ parent: hbox /*, step: 0.1, minVal: -10, maxVal: 10, decimals: 1 */ });

vvbox.addSeparator();

var bbox = new DlHbox({ parent: vvbox, className: "SmallerButtons" });
new DlButton({ parent: bbox, label: "OK" }).getElement().style.width = "6em";
var cancel = new DlButton({ parent: bbox, label: "Cancel" });
cancel.getElement().style.width = "6em";
cancel.addEventListener("onClick", function() {
	d.destroy();
});
bbox.getTableElement().style.margin = "2px 5px 6px auto";

document.body.appendChild(d.getElement());

d.display(true);
d.centerOnParent();


menu.getTableElement().style.width = d.getInnerSize().x + "px";
var item_file = new DlMenuItem({ parent: menu, label: "File" });
new DlMenuItem({ parent: menu, label: "Edit" });
new DlMenuItem({ parent: menu, label: "View" });
var tools = new DlMenuItem({ parent: menu, label: "Tools" });
menu.createCellElement().style.width="100%";
var win = new DlMenuItem({ parent: menu, label: "Window" });
//menu.createCellElement().style.width="100%";
menu.addSeparator();
new DlMenuItem({ parent: menu, label: "Help" });

menu = new DlVMenu({});
var color = new DlMenuItem({ parent: menu, label: "Color", iconClass: "IconColors" });
tools.setMenu(menu);
color.setMenu(new DlColorPickerHSV({}));

//menu.getTableElement().style.width = "100%";


menu = new DlVMenu({});
new DlMenuItem({ parent: menu, label: "New..." });
nftp = new DlMenuItem({ parent: menu, label: "New from template" });
menu.addSeparator();
new DlMenuItem({ parent: menu, label: "Open..." });
new DlMenuItem({ parent: menu, label: "Open recent" });
menu.addSeparator();
new DlMenuItem({ parent: menu, label: "Save" });
new DlMenuItem({ parent: menu, label: "Save as..." });
menu.addSeparator();
new DlMenuItem({ parent: menu, label: "Quit" });

item_file.setMenu(menu);

menu = new DlVMenu({});
new DlMenuItem({ parent: menu, label: "Web page" });
new DlMenuItem({ parent: menu, label: "SVG graphics" });
menu.addSeparator();
new DlMenuItem({ parent: menu, label: "XML document" });
nftp.setMenu(menu);

menu = new DlVMenu({});
new DlMenuItem({ parent: menu, label: "Activate next", name: "ACTIVATE_NEXT" });
new DlMenuItem({ parent: menu, label: "Activate previous", name: "ACTIVATE_PREV" });
menu.addSeparator();
new DlMenuItem({ parent: menu, label: "Deactivate this", name: "DEACTIVATE" });
win.setMenu(menu);

menu.addEventListener("onSelect", function(item_id) {
	switch (item_id) {
	    case "ACTIVATE_NEXT":
		DlDialog.activateNext();
		break;
	    case "ACTIVATE_PREV":
		DlDialog.activatePrev();
		break;
	    case "DEACTIVATE":
		d.deactivate();
		break;
	}
});
