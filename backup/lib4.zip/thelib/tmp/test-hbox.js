var hbox = new DlHbox({ borderSpacing: 4 });

for (var i = 0; i < 6; ++i) {

	b = new DlButton({ parent : hbox,
				   label  : "Foo <b>Bar</b> Baz #" + i });
	b.addEventListener("onClick", function(ev) {
		ev.computePos(this);
		window.status = (ev.elPos.x + ", " + ev.elPos.y + " - " + ev.target.tagName + this.getElement().innerHTML);
	});

}

document.body.appendChild(hbox.getElement());
