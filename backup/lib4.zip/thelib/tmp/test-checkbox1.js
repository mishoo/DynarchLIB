var hbox = new DlHbox({ borderSpacing: 0 });

for (var i = 0; i < 6; ++i) {

	b = new DlCheckbox({ parent : hbox,
				     label  : "Foo <b>Bar</b> Baz #" + i });
	b.addEventListener("onClick", function(ev) {
		ev.computePos(this);
		window.status = (ev.elPos.x + ", " + ev.elPos.y + " - " + ev.target.tagName + this.getElement().innerHTML);
	});

	b.addEventListener("onMouseMove", function(ev) {
                if (this.hasCapture) {
        		ev.computePos(this);
	        	window.status = (ev.relPos.x + ", " + ev.relPos.y + " - " + ev.target.tagName);
                }
	});

}

document.body.appendChild(hbox.getElement());
