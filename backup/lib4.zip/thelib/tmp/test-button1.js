var table = document.createElement("table");
table.style.whiteSpace = "nowrap";
table.align = "center";
var tbody = document.createElement("tbody");
var tr = document.createElement("tr");
table.appendChild(tbody);
tbody.appendChild(tr);

for (var i = 0; i < 6; ++i) {

	b = new DlButton({ label: "Foo <b>Bar</b> Baz #" + i });
	var td = document.createElement("td");
	tr.appendChild(td);
	td.appendChild(b.getElement());

	b.addEventListener("onClick", function(ev) {
		ev.computePos(this);
		window.status = (ev.elPos.x + ", " + ev.elPos.y + " - " + ev.target.tagName + this.getElement().innerHTML);
	});

}

document.body.appendChild(table);
