var table = document.createElement("table");
table.style.whiteSpace = "nowrap";
table.align = "center";
var tbody = document.createElement("tbody");
var tr = document.createElement("tr");
table.appendChild(tbody);
tbody.appendChild(tr);

for (var i = 0; i < 6; ++i) {

	b = new DlButton({ label: "Foo <b>Bar</b> Baz #" + i });
	var td = document.createElement("td");
	tr.appendChild(td);
	td.appendChild(b.getElement());

	b.addEventListener("onClick", function(ev) {
		alert(ev.elPos.x + ", " + ev.elPos.y);
	});

}

document.body.appendChild(table);
