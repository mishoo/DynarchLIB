var p1 = DlPopup.get(0);
var p2 = DlTooltip.get(0);
var p3 = DlPopup.get(0);

alert(p3 === p1);
