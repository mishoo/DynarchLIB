// @require widget.js
// @require radiogroup.js

(function() {

	var TYPE = {
		STANDARD : 1,
		TWOSTATE : 2
	};

	var DEFAULT_ARGS = {
		_label     : [ "label"     , "" ],
		_classes   : [ "classes"   , {} ],
		_checked   : [ "checked"   , false ],
		_groupId   : [ "group"     , null ],
		_btnType   : [ "type"      , TYPE.STANDARD ]
	};

	var DEFAULT_LISTENERS = [ "onMouseEnter",
				  "onMouseLeave",
				  "onMouseDown",
				  "onMouseUp",
				  "onUpdateLabel",
				  "onClick",
				  "onCheck",
				  "onChange",
				  "onDisabled"
				  ];

	eval(DynarchDomUtils.importCommonVars());

	var BASE = DlAbstractButton.inherits(DlWidget);
	function DlAbstractButton(args, classes) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
			if (this._groupId != null) {
				if (typeof this._groupId == "object") {
					this._group = this._groupId;
					this._groupId = this._group.id;
				} else {
					this._group = DlRadioGroup.get(this._groupId);
					this._group.addWidget(this);
				}
			}
		}
	};

	DlAbstractButton.TYPE = TYPE;

	var P = DlAbstractButton.prototype;

	P._onMouseEnter = function(ev) {
		var el = this.getElement();
		AC(el, this._classes.hover);
		if (this.hasCapture)
			AC(el, this._classes.active);
	};

	P._onMouseLeave = function(ev) {
		var el = this.getElement();
		if (!this.hasCapture)
			DC(el, this._classes.hover);
		DC(el, this._classes.active);
	};

	P._onMouseDown = function(ev) {
		var el = this.getElement();
		AC(el, this._classes.hover);
		AC(el, this._classes.active);
		this._mouseDown = true;
		DlEvent.setButtonCapture(ev, "onmouseup", this);
	};

	P._onMouseUp = function(ev) {
		var el = this.getElement();
		DC(el, this._classes.active);
		var dc = true;
		if (this._mouseInside && this._mouseDown) {
			this.applyHooks("onClick", [ ev ]);
			dc = this.disabled();
		}
		if (dc)
			DC(el, this._classes.hover);
		this._mouseDown = false;
	};

	P._onUpdateLabel = function() {
		var el = this.getElement();
		if (!/\S/.test(this._label))
			AC(el, this._classes.empty);
		else
			DC(el, this._classes.empty);
	};

	P._onClick = function() {
		if (this._btnType == TYPE.TWOSTATE)
			this.toggle();
	};

	P._onChange = function() {
		if (this._group != null)
			this._group.applyHooks("onChange", [ this ]);
	};

	P._onCheck = Dynarch.noop;

	P._onDisabled = function(v) {
		CC(this.getElement(), v, this._classes.disabled);
	};

	P.initDOM = function() {
		this.registerEvents([ "onCheck", "onUncheck", "onChange", "onUpdateLabel" ]);
		BASE.initDOM.call(this);
		this.setUnselectable();
	};

	P._createElement = function() {
		// this.BASE._createElement.call(this);
		// this.BASE_call("_createElement");
		BASE._createElement.call(this);
		this._createLabelElement();
		this.label(this._label, true);
		this._updateState();
	};

	P._setListeners = function() {
		BASE._setListeners.call(this);
		var self = this;
		DEFAULT_LISTENERS.r_foreach(function(ev) {
			self.addEventListener(ev, self["_"+ev]);
		});
	};

	P._createLabelElement = Dynarch.noop;

	P.label = function(label, force) {
		if (label != null && (force || label !== this._label)) {
			this._label = label;
			this.setContent(this._label);
			this.applyHooks("onUpdateLabel", [ this._label ]);
		}
		return this._label;
	};

	/* two-state button stuff */

	P.group = function() {
		return this._group;
	};

	P._checkTwoState = function(nothrow) {
		var cond = this._btnType != TYPE.TWOSTATE;
		if (cond && !nothrow)
			throw DlExInvalidOperation("This operation is only available for a TWOSTATE button");
		return !cond;
	};

	P._updateState = function() {
		if (this._checkTwoState(true)) {
			var c = this._classes;
			CC(this.getElement(), this._checked, c.checked, c.unchecked);
		}
	};

	P.checked = function(checked, nohooks) {
		this._checkTwoState();
		if (checked != null) {
			var diff = !nohooks && (this._checked !== checked);
			this._checked = checked;
			this._updateState();
			if (diff) {
				this.callHooks("onChange");
				this.callHooks(this._checked ? "onCheck" : "onUncheck");
			}
		}
		return this._checked;
	};

	P.toggle = function(nohooks) {
		this._checkTwoState();
		this.checked(!this._checked, nohooks);
	};

	window.DlAbstractButton = DlAbstractButton;

})();
