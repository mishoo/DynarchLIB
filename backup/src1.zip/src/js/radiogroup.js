(function() {

	var BASE = DlRadioGroup.inherits(DlEventListener);
	function DlRadioGroup(id) {
		if (id != null) {
			BASE.constructor.call(this);

			this._buttons = [];
			this._buttonsById = {};
			this._history = [];
			this._maxChecked = 1;
			this.id = id;

			this.registerEvents([ "onChange" ]);
			this.addEventListener("onChange", this._onChange);
		}
	};

	var GROUPS = {};

	DlRadioGroup.get = function(id) {
		var g = GROUPS[id];
		if (!g)
			g = GROUPS[id] = new DlRadioGroup(id);
		return g;
	};

	DlRadioGroup.getById = DlRadioGroup.get;

	var P = DlRadioGroup.prototype;

	P._onChange = function(w) {
		if (w.checked()) {
			if (this._maxChecked != null
			    && this._history.length >= this._maxChecked) {
				var o = this._history[0];
				o.checked(false, true);
				o.callHooks("onMouseLeave");
				this._history.splice(0, 1);
			}
			this._history.push(w);
		} else
			this._history.remove(w);
	};

	P.addWidget = function(w) {
		if (!this._buttonsById[w.id]) {
			this._buttonsById[w.id] = w;
			this._buttons.push(w);
 			if (w.checked())
 				// this._onChange(w);
				this._history.push(w);
		}
	};

	P.maxChecked = function(maxChecked) {
		if (maxChecked != null)
			this._maxChecked = maxChecked;
		return this._maxChecked;
	};

	P.currentSelection = function() {
		return this._history;
	};

	// This really checks all.  Doesn't make too much sense when
	// _maxChecked restricts selection.
	P.checkAll = function(val) {
		if (val == null)
			val = true;
		this._buttons.foreach(function(w) {
			w.checked(val, true);
		});
	};

	window.DlRadioGroup = DlRadioGroup;

})();
