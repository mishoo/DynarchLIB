// @require container.js
// @require button.js

(function(){

	var TAB_POS = {
		TOP    : 0,
		RIGHT  : 1,
		BOTTOM : 2,
		LEFT   : 3
	};

	var TAB_CLASSES = [ "DlTabs-top", "DlTabs-right", "DlTabs-bottom", "DlTabs-left" ];

	var DEFAULT_EVENTS = [ "onChange" ];

	eval(DynarchDomUtils.importCommonVars());

	var DEFAULT_ARGS = {
		_tabPos       : [ "tabPos"        , TAB_POS.TOP ]
	};

	var BASE = DlTabs.inherits(DlContainer);
	function DlTabs(args) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
		}
	};

	DlTabs.TAB_POS = TAB_POS;

	var P = DlTabs.prototype;

	function onNotebookChange(newIndex, oldIndex) {
		var w = newIndex != null ? this._panes[newIndex] : null;
		w && w._tab.checked(true);
	};

	function onTabChange(btn) {
		if (btn.checked())
			this._tabContent.showPane(btn.userData);
	};

	function onTabClick(ev) {
		this.checked(true);
		throw new DlExStopEventProcessing();
	};

	P.addTab = function(w, title) {
		this._tabContent.appendWidget(w);
		var args = { label  : title,
			     parent : this._tabBar,
			     group  : this._tabGroup,
			     type   : DlButton.TYPE.TWOSTATE,
			     data   : this._tabContent.length() - 1
		};
		w._tab = new DlButton(args);
		w._tab.addEventListener("onClick", onTabClick, true);
	};

	P.getTabBar = function() { return this._tabBar; };
	P.getNotebook = function() { return this._tabContent; };
	P.getTabContent = P.getNotebook;

	P.initDOM = function() {
		BASE.initDOM.call(this);
		this._tabGroup = DlRadioGroup.get(this.id);
		this._tabBar = new DlHbox({ className: "TabBar" });
		this._tabContent = new DlNotebook({ className: "TabContent" });
		switch (this._tabPos) {
		    case TAB_POS.TOP:
		    case TAB_POS.LEFT:
			this.appendWidget(this._tabBar);
			this.appendWidget(this._tabContent);
			break;
		    case TAB_POS.BOTTOM:
		    case TAB_POS.RIGHT:
			this.appendWidget(this._tabContent);
			this.appendWidget(this._tabBar);
			break;
		}
		// CE("div", { clear: "both" }, null, this._tabBar.getElement());
		this.registerEvents(DEFAULT_EVENTS);
		this._tabContent.addEventListener("onChange", onNotebookChange);
		this._tabGroup.addEventListener("onChange", Dynarch.makeClosure(onTabChange, this));
		AC(this.getElement(), TAB_CLASSES[this._tabPos]);
	};

	P.setTabPos = function(tabPos) {
		var bar = this._tabBar.getElement();
		var content = this._tabContent.getElement();
		if (bar.parentNode)
			bar.parentNode.removeChild(bar);
		var pos = (tabPos == TAB_POS.TOP || tabPos == TAB_POS.LEFT)
			? pos = content
			: null;
		content.parentNode.insertBefore(bar, pos);
		AC(this.getElement(), TAB_CLASSES[tabPos], TAB_CLASSES[this._tabPos]);
		this._tabPos = tabPos;
	};

	P.setTabAlign = function(tabAlign) {
		return this._tabBar.setAlign(tabAlign);
	};

	P.setOuterSize = P.setSize = function(size) {
		BASE.setSize.call(this, size);
		size = this.getInnerSize();
		var bar = this._tabBar.getSize();
		// alert(size.x + "x" + size.y + " - " + bar.x + "x" + bar.y);
		switch (this._tabPos) {
		    case TAB_POS.TOP:
		    case TAB_POS.BOTTOM:
			size.y -= bar.y;
			break;
		    case TAB_POS.LEFT:
		    case TAB_POS.RIGHT:
			size.x -= bar.x;
			break;
		}
		this._tabContent.setSize(size);
	};

	P.showPane = function(index) { return this._tabContent.showPane(index); };
	P.nextPane = function() { return this._tabContent.nextPane(); };
	P.prevPane = function() { return this._tabContent.prevPane(); };
	P.isFirstPane = function() { return this._tabContent.isFirstPane(); };
	P.isLastPane = function() { return this._tabContent.isLastPane(); };

	window.DlTabs = DlTabs;

})();
