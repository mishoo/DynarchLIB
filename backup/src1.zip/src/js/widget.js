// @require eventlistener.js
// @require event.js

(function() {

	var DEFAULT_ARGS = {
		_parent         : [ "parent"    , null ],
		_tagName        : [ "tagName"   , "div" ],
		_addClassName   : [ "className" , "" ],
		_disabled       : [ "disabled"  , false ],
		userData        : [ "data"      , null ]
	};

	var DEFAULT_EVENTS = [ "onMouseEnter",
			       "onMouseLeave",
			       "onMouseMove",
			       "onMouseDown",
			       "onMouseUp",
			       "onClick",
			       "onDisabled",
			       "onDestroy"
		];

	var WIDGETS = {};

	eval(DynarchDomUtils.importCommonVars());

	var BASE = DlWidget.inherits(DlEventListener);
	function DlWidget(args) {
		if (args) {
			BASE.constructor.call(this);
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);

			if (!(this._parent == null || this._parent instanceof DlContainer))
				throw new DlException("Parent must be an instance of DlContainer");

			this.id = Dynarch.ID(this._objectType || 'DlWidget');
			WIDGETS[this.id] = this;

			this.initDOM();
		}
	};

	DlWidget.getById = function(id) { return WIDGETS[id]; };
	DlWidget.getDefaultArgs = function() { return DEFAULT_ARGS; };
	DlWidget.getFromElement = function(el) { return el._dynarch_object; };

	var P = DlWidget.prototype;

	P._className = [ "DlWidget" ];

	P.__patchSubclassPrototype = function() {
		this._className = Dynarch.makeArray(this._className);
		this._className.push(this._objectType);
	};

	P._setListeners = Dynarch.noop;	// ALIAS

	P._createElement = function() {
		var cn = this._className.join(" ");
		if (this._addClassName)
			cn += " " + this._addClassName;
		var el = DynarchDomUtils.createElement(
			this._tagName, null, { className : cn,
					       id        : this.id
			});
		el._dynarch_object = this;
		this._element = el;
		if (this._parent) {
			this._parent.appendWidget(this);
			this._parent = null; // this was a temporary property
		}
	};

	P.getElement = function() {
		return this._element;
	};

	P.getContentElement = P.getElement;

	P.setContent = function(content) {
		var el = this.getContentElement();
		if (typeof content == "string") {
			el.innerHTML = content;
		} else if (content instanceof DlWidget) {
			el.innerHTML = "";
			this.appendWidget(content);
		} else if (content instanceof Array) {
			el.innerHTML = content.join("");
		}
	};

	P.initDOM = function() {
		this.registerEvents(DEFAULT_EVENTS);
		this._setListeners();
		this._createElement();
		if (this._disabled)
			this.disabled(true, true);
		return this;
	};

	P.setUnselectable = function() {
		DOM.setUnselectable(this.getElement());
	};

	P.disabled = function(v, force) {
		if (v != null && (force || v != this._disabled)) {
			this._disabled = v;
			CC(this.getElement(), v, "DlWidget-disabled");
			this.applyHooks("onDisabled", [ v ]);
		}
		return this._disabled;
	};

	P.destroy = function() {
		this.callHooks("onDestroy");
		var el = this.getElement();
		el._dynarch_object = null;
		this._element = null;
		// <XXX: this is probably not good for composed widgets>
		var els = Dynarch.makeArray(el.getElementsByTagName("*"));
		els.r_foreach(function(el) { el._dynarch_object = null; });
		// </XXX>
		if (this.parent)
			parent.removeWidget(this);
		else if (el.parentNode)
			el.parentNode.removeChild(el);
		if (WIDGETS[this.id])
			delete WIDGETS[this.id];
	};

	P.setSize = P.setOuterSize = function(size) {
		DOM.setOuterSize(this.getElement(), size.x, size.y);
	};

	P.setInnerSize = function(size) {
		DOM.setInnerSize(this.getContentElement(), size.x, size.y);
	};

	P.getSize = P.getOuterSize = function() {
		return DOM.getOuterSize(this.getElement());
	};

	P.getInnerSize = function() {
		return DOM.getInnerSize(this.getContentElement());
	};

	P.display = function(v) {
		var s = this.getElement().style;
		if (v != null) {
			s.display = v ? "" : "none";
			return v;
		}
		return s.display != "none";
	};

	P.visibility = function(v) {
		var s = this.getElement().style;
		if (v != null) {
			s.visibility = v ? "" : "hidden";
			return v;
		}
		return s.visible != "hidden";
	};

	P.setPosition = function(pos) {
		var s = this.getElement().style;
		s.left = pos.x + "px";
		s.top = pos.y + "px";
	};

	window.DlWidget = DlWidget;

	DlEvent.atUnload(function(){
		for (var i in WIDGETS) {
			var w = WIDGETS[i];
			//w.destroy();
			if (w._element) {
				w._element._dynarch_object = null;
				w._element = null;
			}
			delete WIDGETS[i];
		}
		WIDGETS = null;
	});

})();
