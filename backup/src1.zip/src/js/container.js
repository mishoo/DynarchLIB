// @require widget.js

(function() {

	var BASE = DlContainer.inherits(DlWidget);
	function DlContainer(args) {
		if (args) {
			BASE.constructor.call(this, args);

			//this._widgets = [];
			//this._widgetsById = {};
		}
	};

	var P = DlContainer.prototype;

	P.appendWidget = function(w) {
		// alert("Appending " + w._objectType + " to " + this._objectType);
		if (w.parent)
			w.parent.removeWidget(w);
		//this._widgetsById[w.id] = w;
		//this._widgets.push(w);
		w.parent = this;
		this._appendWidgetElement(w);
	};

	P._appendWidgetElement = function(w) {
		this.getElement().appendChild(w.getElement());
	};

	P.removeWidget = function(w) {
		if (w.parent == this) {
			//delete this._widgetsById[w.id];
			//this._widgets.remove(w);
			this._removeWidgetElement(w);
			w.parent = null;
		}
	};

	P._removeWidgetElement = function(w) {
		var el = w.getElement();
		el.parentNode.removeChild(el);
	};

	window.DlContainer = DlContainer;

})();
