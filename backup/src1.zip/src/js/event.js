// @require eventlistener.js

(function() {

	eval(DynarchDomUtils.importCommonVars());

	function DlEvent(ev) {
		this.type = ev.type;
		if (!/^on/.test(this.type))
			this.type = "on" + this.type;
		this.ctrlKey = ev.ctrlKey;
		this.altKey = ev.altKey;
		this.shiftKey = ev.shiftKey;
		this.button = ev.button;
		this.pos = { x : ev.clientX,
			     y : ev.clientY };
		if (is_ie) {
			this.target = ev.srcElement;
			switch (this.type) {
			    case "onmouseover" : this.relatedTarget = ev.fromElement; break;
			    case "onmouseout"  : this.relatedTarget = ev.toElement; break;
			}
		} else try {
			this.target = ev.target;
			if (this.target.nodeType == 3 /* Node.TEXT */)
				this.target = this.target.parentNode;
			if (this.type == "onmouseout" || this.type == "onmouseover") {
				this.relatedTarget = ev.relatedTarget;
				if (this.relatedTarget && this.relatedTarget.nodeType == 3 /* Node.TEXT */)
					this.relatedTarget = this.relatedTarget.parentNode;
			}
		} catch(ex) {}
	};

	DlEvent.prototype.computePos = function(widget) {
		var el = widget
			? widget.getElement()
			: document.body;
		var pos = this.elPos = el
			? DOM.getPos(el)
			: { x: 0, y: 0 };
		this.relPos = { x : this.pos.x - pos.x,
				y : this.pos.y - pos.y };
	};

	DlEvent.prototype.getObject = function() {
		var el = this.target;
		try {
			while (el && !DlWidget.getFromElement(el))
				el = el.parentNode;
			return el ? DlWidget.getFromElement(el) : null;
		} catch(ex) {};
		return null;
	};

	DlEvent.stopEvent = function(ev) {
		if (is_ie) {
			ev.cancelBubble = true;
			ev.returnValue = false;
		} else {
			ev.preventDefault();
			ev.stopPropagation();
		}
		return false;
	};

	DlEvent._captures = {};
	DlEvent.addCapture = function(w, evs) {
		var id = Dynarch.ID("capture");
		DlEvent._captures[id] = {
			widget : w,
			events : evs
		};
		return id;
	};

	DlEvent.removeCapture = function(id) {
		delete DlEvent._captures[id];
	};

	DlEvent.setButtonCapture = function(ev, release, widget) {
		DlEvent.releaseCapture(ev);
		DlEvent._currentCapture = widget;
		DlEvent._captureEv = ev;
		DlEvent._captureRelease = release;
		widget.hasCapture = true;
	};

	DlEvent.releaseCapture = function(ev) {
		if (DlEvent._currentCapture) {
			var tmp = this._captureEv;
			DlEvent._currentCapture.hasCapture = false;
			DlEvent._currentCapture = null;
			DlEvent._captureEv = null;
			DlEvent._captureRelease = null;

			// usually, after a capture we want to trigger some elements on
			// the original and final destinations:

			if (tmp.target != ev.target) {
				tmp.type = "onmousemove";
				_genericEventHandler(tmp);
				tmp.type = "onmouseout";
				_genericEventHandler(tmp);
				ev.type = "onmouseover";
				_genericEventHandler(ev);
				ev.type = "onmousemove";
				_genericEventHandler(ev);
			}
		}
	};

	DlEvent.checkDisabled = function(w) {
		while (w) {
			if (w.disabled())
				return true;
			w = w.parent;
		}
		return false;
	};

	function _genericEventHandler(ev) {
		ev || (ev = window.event);
		var el, obj,
			dev = ev instanceof DlEvent ? ev : new DlEvent(ev),
			cc  = DlEvent._currentCapture;
		DlEvent.latestEvent = dev;
		if (cc && dev.type === DlEvent._captureRelease) {
			cc.applyHooks("onMouseUp", [ dev ]);
			DlEvent.releaseCapture(dev);
		} else {
			try {
				// window.status = dev.target.tagName;
				el = dev.target;
				while (el) {
					obj = DlWidget.getFromElement(el);
					if (obj) {
						if ((!cc || cc === obj) && !DlEvent.checkDisabled(obj)) {
							switch (dev.type) {
							    case "onmouseover" :
								if (!DOM.related(el, ev)) {
									obj._mouseInside = true;
									obj.applyHooks("onMouseEnter", [ dev ]);
								}
								break;
							    case "onmouseout" :
								if (!DOM.related(el, ev)) {
									obj._mouseInside = false;
									obj.applyHooks("onMouseLeave", [ dev ]);
								}
								break;
							    default :
								obj.applyHooks(dev.type, [ dev ]);
								break;
							}
						}
					}
					el = el.parentNode;
				}
				// return DlEvent.stopEvent(ev);
			} catch(ex) {
				if (!(ex instanceof DlExStopEventBubbling))
					throw ex;
			}
		}
	};

	var _unloadListeners = [];
	function _unloadHandler() {
		_unloadListeners.r_foreach(function(f) { f(); });
		DOM.removeEvents(document, [ "mouseover", "mouseout", "mousedown", "mouseup", "mousemove" ],
				 _genericEventHandler);
		// CLEAN UP.  BULLDOZE EVERYTHING!  Who said JS is garbage collected?
		// No it ain't, not as long as IE still exists. :-(
		DOM.removeEvent(window, "unload", _unloadHandler);
		for (var i in window) {
			if (i == "DlEvent")
				continue;
			if (/^(Dynarch|Dl)/.test(i)) {
				DestroyObject(window[i]);
				window[i] = null;
			}
		}
		if (is_ie)
			CollectGarbage();
		window.unload = null;
		window.DlEvent = null;
	};

	DlEvent.atUnload = function(f) { _unloadListeners.push(f); };

	DOM.addEvents
		(document, [ "mouseover", "mouseout", "mousedown", "mouseup", "mousemove" ],
		 _genericEventHandler);

	DOM.addEvent(window, "unload", _unloadHandler);

	window.DlEvent = DlEvent;

})();
