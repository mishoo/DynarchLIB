var el = document.createElement("div");
el.style.position = "absolute";
el.style.width = "20px";
el.style.height = "20px";
el.style.backgroundColor = "#ff8";
el.style.border = "1px solid #c00";
el.style.left = "10px";
el.style.top = "100px";
document.body.appendChild(el);

var a = new Animation(50, 50);
a.addEventListener("onUpdate", function(pos) {
    el.style.left = (10 + 300 * pos) + "px";
});
a.start();
