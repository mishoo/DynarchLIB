var d = new DlDialog({ title: "User profile" });

// d.getContentElement().style.padding = "10px 10px 5px 10px";

// var top_hbox = new DlHbox({ parent: d });
// var cell = top_hbox.createCellElement();
// cell.style.background = "url('profile.png') no-repeat 0 0";
// cell.style.width = "64px";

var vbox = new DlVbox({ parent: d });

// var hmenu = new DlHMenu({ parent: vbox });
// new DlMenuItem({ parent: hmenu, label: "Ckt" });
// hmenu.addSeparator();
// new DlMenuItem({ parent: hmenu, label: "Cu" });
// hmenu.addSeparator();
// new DlMenuItem({ parent: hmenu, label: "Mak" });
// hmenu.createCellElement().style.width = "100%";
// new DlMenuItem({ parent: hmenu, label: "Heeeeelp!" });

var top_c = new DlContainer({ parent: vbox });
top_c.getElement().style.padding = "15px";
var grid = new DlGrid({ parent: top_c });

var row = grid.addRow();
var c1 = grid.addCell(row);
var label = new DlLabel({ label: "<u>U</u>ser ID:", parent: c1 });
c1.getElement().style.textAlign = "right";
var c2 = grid.addCell(row);
label.setWidget(new DlEntry({ parent: c2, readonly: true, value: "grootesque" }));

var row = grid.addRow();
var c1 = grid.addCell(row);
var label = new DlLabel({ label: "Account type:", parent: c1 });
c1.getElement().style.textAlign = "right";
var c2 = grid.addCell(row);
var opts = [
	{ label: "Ordinary", value: "guest" },
	{ label: "Registered", value: "user" },
	{ label: "Administrators", value: "admin" },
	{ label: "Check out this really long option text", value: "check" }
];
var sel = new DlSelect({ parent: c2, options: opts, value: "admin" });
label.setWidget(sel);
sel.getButton().setIconClass("IconChardev");

grid.addSeparator();

var row = grid.addRow();
var c1 = grid.addCell(row);
var label = new DlLabel({ label: "User name:", parent: c1 });
c1.getElement().style.textAlign = "right";
var c2 = grid.addCell(row);
label.setWidget(new DlEntry({ parent: c2 }));

var row = grid.addRow();
var c1 = grid.addCell(row);
var label = new DlLabel({ label: "Password:", parent: c1 });
c1.getElement().style.textAlign = "right";
var c2 = grid.addCell(row);
var pass = new DlEntry({ parent: c2, type: "password" });
label.setWidget(pass);

var row = grid.addRow();
var c1 = grid.addCell(row);
var label = new DlLabel({ label: "Confirm password:", parent: c1 });
c1.getElement().style.textAlign = "right";
var c2 = grid.addCell(row);
var val = new DlValidator(function(data, pass) {
	if (data != pass.getValue())
		throw new DlValidatorException("Password mismatch");
	return data;
}, pass);
var cpass = new DlEntry({ parent: c2, type: "password", validators : [ val ] });
label.setWidget(cpass);

var row = grid.addRow();
var c1 = grid.addCell(row);
var label = new DlLabel({ label: "Your birthday:", parent: c1 });
c1.getElement().style.textAlign = "right";
var c2 = grid.addCell(row);
var tmp = new DlButtonCalendar({ parent: c2, dateFormat: "(%A) %d %B %Y", calendar: { weekNumbers: true } });
// tmp.getElement().style.width = "100%";

grid.addSeparator();

var row = grid.addRow();
var c1 = grid.addCell(row);
var label = new DlLabel({ label: "Debug level:", parent: c1 });
c1.getElement().style.textAlign = "right";
var c2 = grid.addCell(row);
label.setWidget(new DlSpinner({ parent: c2, value: 0, minVal: 0, maxVal: 5, step: 1, integer: true }));

// var html = new DlWidget({ parent: c2, tagName: 'span' });
// html.getElement().style.cssFloat = 'right';
// html.setContent("Maximum value is 5 and is very verbose—<em>will</em> degrade performance.");

grid.addSeparator();

var row = grid.addRow();
var c1 = grid.addCell(row);
new DlLabel({ label: "Color palette:", parent: c1 });
c1.getElement().style.textAlign = "right";
var c2 = grid.addCell(row);
var cp = new DlButtonColorPicker({ parent: c2, label: "FG" });
cp.setColorPicker(new DlColorPickerHSV({}));
cp.getElement().align = "left";
var cp = new DlButtonColorPicker({ parent: c2, label: "BG" });
cp.setColorPicker(new DlColorPickerHSV({}));
cp.getElement().align = "left";
cp.getElement().style.marginLeft = "5px";

vbox.addSeparator();
hbox = new DlHbox({ parent: vbox, borderSpacing: "5px" });
new DlButton({ label: "<div style='width:5em'>OK</div>", parent: hbox });
new DlButton({ label: "<div style='width:5em'>Cancel</div>", parent: hbox }).addEventListener("onClick", function() {
	d.destroy();
});
hbox.getElement().style.margin = "auto 0 auto auto";
hbox.getElement().style.padding = "3px 5px 5px 0";

document.body.appendChild(d.getElement());

d.display(true);
d.centerOnParent();
