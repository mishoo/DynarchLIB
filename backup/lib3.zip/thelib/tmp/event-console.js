var hbox = new DlHbox({ borderSpacing: 4 });

for (var i = 0; i < 6; ++i) {

	b = new DlRadioButton({ parent : hbox,
					label  : "Foo <b>Bar</b><br />Baz #" + i });
	b.addEventListener("onClick", function(ev) {
		ev.computePos(this);
		window.status = (ev.elPos.x + ", " + ev.elPos.y + " - " + ev.target.tagName + this.getElement().innerHTML);
	});

}

document.body.appendChild(hbox.getElement());

var console = DynarchDomUtils.createElement("div", { backgroundColor: "#fff" }, null, document.body);
var oldApply = DlEventListener.prototype.applyHooks;
DlEventListener.prototype.applyHooks = function(ev, args) {
	console.innerHTML += ev + " on " + this.id + "<br />";
	oldApply.call(this, ev, args);
};
