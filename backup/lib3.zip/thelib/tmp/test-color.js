//

var CP = new DlColorPickerHSV({});
CP.addEventListener("onSelect", function(rgb, hsv, color) {
	document.body.style.backgroundColor = color;
});
CP.addEventListener("onMouseLeave", function() {
	document.body.style.backgroundColor = "#fff";
});

document.body.appendChild(CP.getElement());
