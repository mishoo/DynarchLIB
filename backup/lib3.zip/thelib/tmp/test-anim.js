var a = new Animation(10, 5);
a.addEventListener("onUpdate", function(pos) {
	var p = document.createElement("p");
	p.innerHTML = pos;
	document.body.appendChild(p);
});
