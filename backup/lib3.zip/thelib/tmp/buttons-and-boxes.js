function listener(ev) {
	ev.computePos(this);
	window.status = (ev.elPos.x + ", " + ev.elPos.y + " - " + ev.target.tagName + this.getElement().innerHTML);
};

function letters(i) {
	var a = [ "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten" ];
	return a[i];
};

var hbox = new DlHbox({ borderSpacing: 4 });

var vbox = new DlVbox({ parent: hbox });
for (var i = 0; i < 6; ++i) {

	b = new DlRadioButton({ parent : vbox,
					label  : "Foo <b>Bar</b> Baz #" + letters(i) });
	b.addEventListener("onClick", listener);

}

var vbox = new DlVbox({ parent: hbox });
for (var i = 0; i < 6; ++i) {

	b = new DlCheckbox({ parent : vbox,
				     label  : "Foo <b>Bar</b> Baz #" + letters(i) });
	b.addEventListener("onClick", listener);

}

var vbox = new DlVbox({ parent: hbox });
for (var i = 0; i < 6; ++i) {

	b = new DlButton({ parent : vbox,
				   label  : "Foo <b>Bar</b> Baz #" + letters(i) });
	b.addEventListener("onClick", listener);

}

document.body.appendChild(hbox.getElement());

