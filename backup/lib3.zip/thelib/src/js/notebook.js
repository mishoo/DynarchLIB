// @require container.js
// @require button.js

(function(){

	var DEFAULT_EVENTS = [ "onChange" ];

	var BASE = DlNotebook.inherits(DlContainer);
	function DlNotebook(args) {
		if (args) {
			BASE.constructor.call(this, args);

			this._panes = [];
			this._currentPane = null;
		}
	};

	var P = DlNotebook.prototype;

	P._createElement = function() {
		BASE._createElement.call(this);
		this.getElement().innerHTML = "<div class='TabContent-inner'></div>";
	};

	P.appendWidget = function(w) {
		BASE.appendWidget.call(this, w);
		var el = w.getElement();
		w.display(false);
//		el.style.display = "none";
// 		el.style.position = "absolute";
// 		el.style.visibility = "hidden";
// 		el.style.left = el.style.top = "0";
		this.getElement().firstChild.appendChild(el);
		this._panes.push(w);
	};

	P.initDOM = function() {
		this.registerEvents(DEFAULT_EVENTS);
		BASE.initDOM.call(this);
	};

	P.getPane = function(index) { return this._panes[index]; };

	P.length = function() { return this._panes.length; };

	P.showPane = function(index) {
		var old = this._currentPane;
		if (old != null)
			this.getPane(old).display(false);
		this._currentPane = index;
		this.getPane(index).display(true);
		if (index !== old)
			this.applyHooks("onChange", [ index, old ]);
		return this;
	};

	P.nextPane = function() {
		var i = this._currentPane;
		i == null ? i = 0 : ++i;
		if (i >= this._panes.length)
			i = 0;
		return this.showPane(i);
	};

	P.prevPane = function() {
		var i = this._currentPane;
		i == null ? i = 0 : --i;
		if (i < 0)
			i = this._panes.length - 1;
		return this.showPane(i);
	};

	P.isFirstPane = function() { return this._currentPane == 0; };
	P.isLastPane = function() { return this._currentPane == this._panes.length - 1; };

	P.getContentElement = function() {
		return this.getElement().firstChild;
	};

	P.setSize = P.setOuterSize = function(size) {
		BASE.setOuterSize.call(this, size);
		var el = this.getElement();
		size = DynarchDomUtils.getInnerSize(el);
		DynarchDomUtils.setOuterSize(this.getContentElement(), size.x, size.y);
		el.style.width = el.style.height = "";
	};

	P.setIdealSize = function() {
		var size = { x: 0, y: 0 };
		this._panes.r_foreach(function(p) {
			p.display(true);
			var s = p.getOuterSize();
			p.display(false);
			if (s.x > size.x) size.x = s.x;
			if (s.y > size.y) size.y = s.y;
		});
		this.setInnerSize(size);
		this.getPane(this._currentPane).display(true);
	};

	window.DlNotebook = DlNotebook;

})();
