// @require abstractbutton.js

(function(){

	var DEFAULT_ARGS = {
		_activateWidget : [ "widget", null ],
		_noCapture      : [ "noCapture" , true ]
	};

	var BASE = DlLabel.inherits(DlAbstractButton);
	function DlLabel(args) {
		if (args) {
			args.tagName = "span";
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
		}
	};

	function activate() {
		var w = this._activateWidget;
		if (w) {
			w.focus();
			throw new DlExStopDOMEventBubbling;
		}
	};

	var P = DlLabel.prototype;

	P._setListeners = function() {
		BASE._setListeners.call(this);
		this.addEventListener("onMouseDown", activate);
	};

	P.setWidget = function(widget) {
		this._activateWidget = widget;
	};

	window.DlLabel = DlLabel;

})();
