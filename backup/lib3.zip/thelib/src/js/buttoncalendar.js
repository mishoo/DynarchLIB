// @require buttonmenu.js
// @require calendar.js

(function() {

	var DEFAULT_ARGS = {
		dateFormat     : [ "dateFormat"   , "%Y/%m/%d" ],
		_calendarArgs  : [ "calendar"     , {} ],
		date           : [ "date"         , "Select date..." ]
	};

	var BASE = DlButtonCalendar.inherits(DlButtonMenu);
	function DlButtonCalendar(args) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
		}
	};

	var P = DlButtonCalendar.prototype;

	function calendar_onSelect(cal, cleared, otherMonth) {
		if (!cleared) {
			this.getButton().setContent(cal.date.print(this.dateFormat));
			DlPopup.clearAllPopups();
			this.date = new Date(cal.date);
		}
	};

	function button_onClick() {
		if (this.date instanceof Date) {
			var cal = this.getCalendar();
			if (!cal.date.dateEqualsTo(this.date)) {
				cal.date = new Date(this.date);
				cal._selectedDate = this.date.getDate();
				cal.init();
			}
		}
		this.getArrow().callHooks("onMouseDown");
	};

	P.getCalendar = function() {
		var cal = this._calendar;
		if (!cal) {
			cal = this._calendar = new DlCalendar(this._calendarArgs);
			cal.addEventListener("onSelect",
					     Dynarch.makeClosure(
						     calendar_onSelect, this, cal));
			if (this.date instanceof Date)
				cal.date = new Date(this.date);
			cal.init();
		}
		return this._calendar;
	};

	function onPopup(b) {
		b.getButton().currentPopup = this;
	};

	function onHide(b) {
		b.getButton().currentPopup = null;
	};

	P.initDOM = function() {
		BASE.initDOM.call(this);
		var b = this.getButton();
		if (this.date instanceof Date) {
			b.setContent(this.date.print(this.dateFormat));
		} else
			b.setContent(this.date);
		this.setMenu(Dynarch.makeClosure(this.getCalendar, this));
		b.setIconClass("IconCalendar");
		b.addEventListener("onClick", Dynarch.makeClosure(button_onClick, this));
		b = this.getPopup();
		b.addEventListener("onPopup", Dynarch.makeClosure(onPopup, null, this));
		b.addEventListener("onHide", Dynarch.makeClosure(onHide, null, this));
	};

	window.DlButtonCalendar = DlButtonCalendar;

})();
