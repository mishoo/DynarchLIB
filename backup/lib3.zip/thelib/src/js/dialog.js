// @require container.js

(function(){

	eval(DynarchDomUtils.importCommonVars());

	var DEFAULT_ARGS = {
		_title     : [ "title", "DlDialog" ],
		_fixed     : [ "fixed", false ],
		_resizable : [ "resizable", false ]
	};

	var DEFAULT_EVENTS = [ "onShow", "onHide" ];

	var STATIC_ELEMENT = document.createDocumentFragment();

	(function() {
		var c = CE("div", null, { className: "DlDialog-Rel" }, STATIC_ELEMENT);
 		if (!is_ie)
			// IE is currently too old to support such advancements
			c.appendChild(DlElementCache.get("SHADOWS"));
		CE("div", null, { className: "DlDialog-Title" }, c);
		CE("div", null, { className: "DlDialog-Content" }, c);
	})();

	var BASE = DlDialog.inherits(DlContainer);
	function DlDialog(args) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
			this.active = false;
		}
	};

	var D = DlDialog;
	var P = D.prototype;

	P._setDragCaptures = function(capture) {
		(capture ? DlEvent.captureGlobals : DlEvent.releaseGlobals)
			(this._dragHandlers);
	};

	P._setResizeCaptures = function(capture) {
		(capture ? DlEvent.captureGlobals : DlEvent.releaseGlobals)
			(this._resizeHandlers);
	};

	function startDrag(ev) {
		if (!this.dragging) {
			this.dragging = true;
			ev || (ev = window.event);
			var dlev = (ev instanceof DlEvent)
				? ev
				: new DlEvent(ev);
			this.addClass("DlDialog-Dragging");
			this._dragPos = dlev.computePos(this);
			this._setDragCaptures(true);
			AC(document.body, "CURSOR-DRAGGING");
		}
	};

	function startCtrlDrag(ev) {
		if (ev.ctrlKey) {
			startDrag.call(this, ev);
			throw new DlExStopEventBubbling;
		}
	};

	function stopDrag(ev) {
		if (this.dragging) {
			this.dragging = false;
			this.delClass("DlDialog-Dragging");
			this._setDragCaptures(false);
			DC(document.body, "CURSOR-DRAGGING");
		}
	};

	function doDrag(ev) {
		var x = ev.pos.x - this._dragPos.x;
		var y = ev.pos.y - this._dragPos.y;
		var sz = this.getOuterSize();
		var ws = DOM.getWindowSize();
		if (x < 0)
			x = 0;
		else if (x + sz.x > ws.x)
			x = ws.x - sz.x;
		if (y < 0)
			y = 0;
		else if (y + sz.y > ws.y)
			y = ws.y - sz.y;
		this.setPos(x, y);
		throw new DlExStopEventBubbling;
	};

	function startResize(ev) {
		if (!this.resizing) {
			this.resizing = true;
			ev || (ev = window.event);
			var dlev = (ev instanceof DlEvent)
				? ev
				: new DlEvent(ev);
			this.addClass("DlDialog-Resizing");
			this._dragPos = dlev.computePos(this);
			var sz = this.getOuterSize();
			this._dragPos.x -= sz.x;
			this._dragPos.y -= sz.y;
			var pos = this.getPos();
			var div = this.getResizeRect();
			DOM.setPos(div, pos.x, pos.y);
			DOM.setInnerSize(div, sz.x - 2, sz.y - 2);
			div.style.display = "";
			this.display(false);
			this._setResizeCaptures(true);
			AC(document.body, "CURSOR-DRAGGING");
			doResize.call(this, dlev);
		}
	};

	function stopResize(ev) {
		if (this.resizing) {
			var div = this.getResizeRect();
			var sz = DOM.getOuterSize(div);
			DOM.setPos(div, 0, 0);
			div.style.display = "none";
			this.display(true);
			this.setInnerSize({ x: sz.x - 2, y: sz.y - this.getTitleElement().offsetHeight - 2 });
			if (is_gecko)
				this.setOuterSize({ x: "auto", y: "auto" });
			this.resizing = false;
			this.delClass("DlDialog-Resizing");
			this._setResizeCaptures(false);
			DC(document.body, "CURSOR-DRAGGING");
			this.callHooks("onResize");
		}
	};

	function doResize(ev) {
		if (this.resizing) {
			var div = this.getResizeRect();
			var pos = DOM.getPos(div);
			pos.x = ev.pos.x - this._dragPos.x - 2 - pos.x;
			if (pos.x < 100)
				pos.x = 100;
			pos.y = ev.pos.y - this._dragPos.y - 2 - pos.y;
			if (pos.y < 100)
				pos.y = 100;
			DOM.setInnerSize(div, pos.x, pos.y);
			div.innerHTML = "<table style='height: 100%' align='center'><tr><td>" +
				pos.x + " x " + pos.y + "</td></tr></table>";
			// throw new DlExStopEventBubbling;
		}
	};

	var visibleDialogs = [];

	D.activatePrev = function() {
		if (visibleDialogs.length > 1) {
			visibleDialogs.peek().deactivate();
			visibleDialogs.unshift(visibleDialogs.pop());
			top = visibleDialogs.pop();
			top.activate();
		}
	};

	D.activateNext = function() {
		if (visibleDialogs.length > 1) {
			visibleDialogs[0].activate();
		}
	};

	D.getActive = function() {
		return visibleDialogs.peek();
	};

	function setZIndex() {
		visibleDialogs.r_foreach(function(d, i) {
			d.zIndex((d._modal ? 900 : 500) + i);
		});
	};

	function onDisplay(disp, val) {
		if (val != this.getElement().style) {
			if (disp) {
				this.callHooks("onShow");
				this.activate();
				DlSingleton.get("System").callHooks("onDialogShow", this);
			} else {
				this.callHooks("onHide");
				this.deactivate();
				DlSingleton.get("System").callHooks("onDialogHide", this);
				if (visibleDialogs.length > 1)
					visibleDialogs.peek().activate();
			}
		}
	};

	function onDestroy() {
 		visibleDialogs.remove(this);
		var last = visibleDialogs.pop();
		if (last)
			last.activate();
	};

	var MODAL_STOPPER = null;
	function getModalStopper() {
		if (!MODAL_STOPPER)
			MODAL_STOPPER = CE("div", { display: "none" },
				{ className: "Dl-ModalStopper" }, document.body);
		return MODAL_STOPPER;
	};

	P.setModal = function(modal) {
		this._modal = modal;
		getModalStopper().style.display = modal ? "" : "none";
		setZIndex();
	};

	P.activate = function() {
		var act = visibleDialogs.peek();
		if (!this.active) {
			if (act && act.active)
				act.deactivate(true);
			this.addClass("DlDialog-Active");
			visibleDialogs.remove(this);
			visibleDialogs.push(this);
			setZIndex();
			this.active = true;
			this.callHooks("onFocus");
		}
	};

	P.deactivate = function(noact) {
		if (this.active) {
			this.delClass("DlDialog-Active");
			this.active = false;
			this.callHooks("onBlur");
		}
	};

	P.makeResizable = function() {
		if (!this._resizeHandlers) {
			var div = this.getElement().firstChild;
			var el = CE("div", null, { className: "ResizeHandle" }, null);
			div.insertBefore(el, div.firstChild);
			this._resizeHandlers = {
				onMouseMove : Dynarch.makeClosure(doResize, this),
				onMouseUp   : Dynarch.makeClosure(stopResize, this),
				onMouseOver  : DlException.stopEventBubbling,
				onMouseOut   : DlException.stopEventBubbling,
				onMouseEnter : DlException.stopEventBubbling,
				onMouseLeave : DlException.stopEventBubbling
			};
			el.onmousedown = Dynarch.makeClosure(startResize, this);
			this.resizing = false;
		}
	};

	P.makeDraggable = function() {
		if (!this._dragHandlers) {
			var el = this.getTitleElement();
			el.style.cursor = "default";
			this._dragHandlers = {
				onMouseMove  : Dynarch.makeClosure(doDrag, this),
				onMouseUp    : Dynarch.makeClosure(stopDrag, this),
				onMouseOver  : DlException.stopEventBubbling,
				onMouseOut   : DlException.stopEventBubbling,
				onMouseEnter : DlException.stopEventBubbling,
				onMouseLeave : DlException.stopEventBubbling
			};
			el.onmousedown = Dynarch.makeClosure(startDrag, this);
			this.addEventListener("onMouseDown", startCtrlDrag);
			this.dragging = false;
		}
	};

	P.title = function(title) {
		if (title != null) {
			this._title = title;
			this.getTitleElement().innerHTML = title;
		}
		return this._title;
	};

	P.initDOM = function() {
		this.registerEvents(DEFAULT_EVENTS);
		BASE.initDOM.call(this);
		if (!this._fixed)
			this.makeDraggable();
		this.addEventListener("onMouseDown", this.activate);
		this.addEventListener("onDisplay", onDisplay);
		this.addEventListener("onDestroy", onDestroy);
	};

	P.getTitleElement = function() {
		var el = this.getElement().firstChild;
		var n = el.childNodes.length;
		return el.childNodes[n - 2];
	};

	P.getContentElement = function() {
		var el = this.getElement().firstChild;
		var n = el.childNodes.length;
		return el.childNodes[n - 1];
	};

	P._createElement = function() {
		BASE._createElement.call(this);
		this.setPos(0, 0);
		this.display(false);
		var div = this.getElement();
		div.appendChild(STATIC_ELEMENT.cloneNode(true));
		this.title(this._title);
		this.setUnselectable(this.getTitleElement());
		if (this._resizable)
			this.makeResizable();
	};

	P.centerOnParent = function() {
		var sz = this.getOuterSize(), ps;
		var p = this.getElement().offsetParent;
		if (p)
			ps = DOM.getOuterSize(p);
		else
			ps = DOM.getWindowSize();
		this.setPos((ps.x - sz.x) / 2, (ps.y - sz.y) / 2);
	};

	window.DlDialog = D;

})();
