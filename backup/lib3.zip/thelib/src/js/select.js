// @require buttonmenu.js
// @require radiobutton.js

(function(){

	var DEFAULT_EVENTS = [ "onChange" ];

	var DEFAULT_ARGS = {
		_options : [ "options", [] ],
		_value   : [ "value", null ]
	};

	var BASE = DlSelect.inherits(DlButtonMenu);
	function DlSelect(args) {
		if (args) {
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			BASE.constructor.call(this, args);
			if (this._options.length)
				this.setOptions(this._options);
			if (this._value != null)
				this.value(this._value, true);
		}
	};

	var D = DlSelect;
	var P = D.prototype;

	P.value = function(value, force) {
		var oldval = this._value;
		if (force || typeof value != "undefined" && value !== oldval) {
			this._value = value;
			this._updateLabel();
			this.applyHooks("onChange", [ oldval, value ]);
		}
		return oldval;
	};

	function radioGroup_onChange(cb) {
		if (cb.checked()) {
			this.value(cb.userData);
			DlPopup.clearAllPopups();
		}
		cb._onMouseLeave();
	};

	P._updateLabel = function() {
		var label = null, a = this._options, i, o;
		for (i = a.length; --i >= 0;) {
			o = a[i];
			if (this._value == o.value) {
				this.getButton().label(o.label);
				o.widget.checked(true);
			}
		}
	};

	P._setListeners = function() {
		this.registerEvents(DEFAULT_EVENTS);
		BASE._setListeners.call(this);
		this._radioGroup = new DlRadioGroup(this.id);
		this._radioGroup.addEventListener(
			"onChange",
			Dynarch.makeClosure(radioGroup_onChange, this));
	};

	P.setOptions = function(options) {
		if (this._menu)
			this._menu.destroy();
		this._radioGroup.reset();
		var menu = this._menu = new DlVMenu({});
		var args = {
			parent : menu,
			group  : this._radioGroup
		};
		options.foreach(function(o) {
			args.label = o.label;
			args.data = o.value;
			o.widget = new DlRadioButton(args);
		}, this);
		var el = menu.getElement();
		el.style.position = "absolute";
		menu.zIndex(-100);
		document.body.appendChild(el);
		var width = menu.getOuterSize().x;
		document.body.removeChild(el);
		el.style.position = "";
		this.getButton().setInnerSize({ x: width });
		this.setMenu(menu);
		this._options = options;
	};

	window.DlSelect = D;

})();
