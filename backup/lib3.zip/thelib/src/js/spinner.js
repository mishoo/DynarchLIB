// @require entry.js
// @require button.js

(function(){

	var DEFAULT_ARGS = {
		_step        : [ "step"      , 1 ],
		_size        : [ "size"      , 4 ],
		_value       : [ "value"     , 0 ],
		_minVal      : [ "minVal"    , null ],
		_maxVal      : [ "maxVal"    , null ],
		_decimals    : [ "decimals"  , null ],
		_integer     : [ "integer"   , false ]
	};

	eval(DynarchDomUtils.importCommonVars());

	var BASE = DlSpinner.inherits(DlEntry);
	function DlSpinner(args) {
		if (args) {
			args.validators = [ new DlValidator(DlValidator.Number,
							    args.minVal,
							    args.maxVal,
							    args.integer,
							    args.decimals) ];
			Dynarch.setDefaults.call(this, DEFAULT_ARGS, args);
			args.type = "text";
			BASE.constructor.call(this, args);
			this._timer = null;
			this._timerStep = null;
			this._timerState = null;
			this._timerPos = null;
		}
	};

	var D = DlSpinner;
	var P = D.prototype;

	P.intervals = [
		{ pos:   1 , step: 1  , speed: 125 },
		{ pos:  10 , step: 1  , speed: 70 },
		{ pos:  20 , step: 1  , speed: 35 },
		{ pos:  50 , step: 1  , speed: 20 },
		{ pos: 100 , step: 1  , speed: 10 },
		{ pos: 200 , step: 2  , speed: 10 }
	];

	P._createElement = function() {
		BASE._createElement.call(this);
		var table = this.getElement();
		var r1 = table.rows[0].cells[0];
		r1.rowSpan = 2;
		r1 = r1.parentNode;
		var r2 = CE("tr", null, null, table.firstChild);
		var c1 = CE("td", null, { className: "DlSpinner-Button DlSpinner-Button-Up" }, r1);
		var c2 = CE("td", null, { className: "DlSpinner-Button DlSpinner-Button-Down" }, r2);
		this._buttonUp = new DlButton({ parent: this, appendArgs: c1 });
		this._buttonDown = new DlButton({ parent: this, appendArgs: c2 });
	};

	function onFocus() {
		this.select();
	};

	function onKeyDown(ev) {
		switch (ev.keyCode) {
		    case DlEvent.KEY.ARROW_DOWN:
			spinnerAct.call(this, { _direction: false });
			throw new DlExStopEventBubbling;
			break;
		    case DlEvent.KEY.ARROW_UP:
			spinnerAct.call(this, { _direction: true });
			throw new DlExStopEventBubbling;
			break;
		}
	};

	function onKeyUp(ev) {
		this._clearTimer();
	};

	function onChange() {
		var val = this.getValue();
		var min = val == this._maxVal;
		var max = val == this._minVal;
		this._buttonUp.disabled(min);
		this._buttonDown.disabled(max);
		if (min || max)
			this._clearTimer();
	};

	P._setListeners = function() {
		BASE._setListeners.call(this);
		this.addEventListener("onFocus", onFocus);
		this.addEventListener("onKeyDown", onKeyDown);
		this.addEventListener("onKeyUp", onKeyUp);
		this.addEventListener("onChange", onChange);
	};

	P.initDOM = function() {
		BASE.initDOM.call(this);
		this._setupSpinnerBtn(this._buttonUp, true);
		this._setupSpinnerBtn(this._buttonDown, false);
	};

	P._spinnerUpdateVal = function(dir) {
		var val = new Number(this.getValue());
		var step = this._timerStep || this._step;
		val = dir
			? (val + step)
			: (val - step);
		if (this._minVal != null && val < this._minVal)
			val = this._minVal;
		if (this._maxVal != null && val > this._maxVal)
			val = this._maxVal;
		this.setValue(val);
		this.focus();
		this.select();
		if (this._timer) {
			var p = ++this._timerPos;
			if (this._timerState.length && p == this._timerState[0].pos) {
				var o = this._timerState.shift();
				this._clearTimer(true);
				this._timerStep = o.step;
				this._startTimer(dir, o.speed);
			}
		}
	};

	function spinnerAct(b) {
		this._spinnerUpdateVal(b._direction);
		(this._timerState = Dynarch.makeArray(this.intervals))
			.r_foreach(function(e){
				e.step *= this.step;
			}, this);
		this._timerPos = 0;
		this._startTimer(b._direction, 250);
		throw new DlExStopEventBubbling;
	};

	function spinnerMouseUp(b) {
//		this.select();
//		this.focus();
		this._clearTimer();
	};

	P._clearTimer = function(restart) {
		if (this._timer)
			clearInterval(this._timer);
		if (!restart) {
			this._timerState = null;
			this._timerStep = null;
			this._timerPos = null;
		}
		this._timer = null;
	};

	P._startTimer = function(dir, timeout) {
		this._timer = setInterval(Dynarch.makeClosure(this._spinnerUpdateVal, this, dir), timeout);
	};

	P._setupSpinnerBtn = function(b, up) {
		b._direction = up;
		var mouseUp = Dynarch.makeClosure(spinnerMouseUp, this, b);
		b.addEventListener("onMouseDown", Dynarch.makeClosure(spinnerAct, this, b));
		b.addEventListener("onMouseUp", mouseUp);
		// this.addEventListener("onMouseUp", mouseUp);
	};

	window.DlSpinner = D;

})();
