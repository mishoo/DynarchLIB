// @require widget.js

/*

  NEED TO DO:

  1. Loading / unloading a given style into the IFRAME
  2. Keyboard shortcuts
  3. Iframe forwards events to the parent widget -- dead simple, DONE.

*/

(function(){

	eval(DynarchDomUtils.importCommonVars());

	var DEFAULT_EVENTS = [ "onUpdate" ];

	var FORWARD_EVENTS = [ "mouseover", "mouseout", "mousemove", "mousedown", "mouseup", "click",
			       "keydown", "keyup", "keypress", "focus", "blur" ];

	var INIT_HTML = '<html>' +
		'<head><title>DynarchLIB Rich Text Editor</title></head>' +
		'<body></body></html>';

	var BASE = DlRteFrame.inherits(DlWidget);
	function DlRteFrame(args) {
		if (args) {
			BASE.constructor.call(this, args);
		}
	};

	var D = DlRteFrame;
	var P = D.prototype;

	D.COMMANDS = {
		"backcolor"             : { id: is_ie ? "backcolor" : "hilitecolor" },
		"forecolor"             : { id: "forecolor" },
		"bold"                  : { id: "bold"                   , key: "CTRL 'B'" },
		"italic"                : { id: "italic"                 , key: "CTRL 'I'" },
		"underline"             : { id: "underline"              , key: "CTRL 'U'" },
		"strike"                : { id: "strikethrough"          , key: "CTRL '-'" },
		"subscript"             : { id: "subscript" },
		"superscript"           : { id: "superscript" },
		"removeformat"          : { id: "removeformat"           , key: "ALT-CTRL '0'" },
		"justifyleft"           : { id: "justifyleft"            , key: "ALT-CTRL 'l'" },
		"justifyright"          : { id: "justifyright"           , key: "ALT-CTRL 'r'" },
		"justifycenter"         : { id: "justifycenter"          , key: "ALT-CTRL 'e'" },
		"justifyfull"           : { id: "justifyfull"            , key: "ALT-CTRL 'j'" },
		"orderedlist"           : { id: "insertorderedlist"      , key: "ALT-CTRL 'o'" },
		"unorderedlist"         : { id: "insertunorderedlist"    , key: "ALT-CTRL 'l'" },
		"indent"                : { id: "indent"                 , key: "CTRL '.'" },
		"outdent"               : { id: "outdent"                , key: "CTRL ','" },
		"undo"                  : { id: "undo" },
		"redo"                  : { id: "redo" },
		"<hr>"                  : { id: "inserthorizontalrule"   , key: "CTRL ' '" },
		"<h1>"                  : { id: "formatblock"            , key: "CTRL '1'", arg: "h1" },
		"<h2>"                  : { id: "formatblock"            , key: "CTRL '2'", arg: "h2" },
		"<h3>"                  : { id: "formatblock"            , key: "CTRL '3'", arg: "h3" },
		"<h4>"                  : { id: "formatblock"            , key: "CTRL '4'", arg: "h4" },
		"<h5>"                  : { id: "formatblock"            , key: "CTRL '5'", arg: "h5" },
		"<h6>"                  : { id: "formatblock"            , key: "CTRL '6'", arg: "h6" },
		"<p>"                   : { id: "formatblock"            , key: "CTRL 'n'", arg: "p" },
//		"<tt>"                  : { id: "formatinline"            , key: "CTRL 't'", arg: "code" },
		"<pre>"                 : { id: "formatblock"            , key: "CTRL-ALT 'n'", arg: "pre" }
	};

	P.execCommand = function(cmd, param) {
		var ret;
		if (D.COMMANDS[cmd]) {
			cmd = D.COMMANDS[cmd];
			if (typeof param == "undefined")
				param = cmd.arg || "";
			cmd = cmd.id;
		}
		if (is_ie && cmd == "formatblock")
			param = "<" + param + ">";
		ret = this.getIframeDoc().execCommand(cmd, false, param);
		this.focus();
		return ret;
	};

	P._setListeners = function() {
		this.registerEvents(DEFAULT_EVENTS);
		BASE._setListeners.call(this);
		this.addEventListener(is_ie ? "onKeyDown" : "onKeyPress", onKeypress);
	};

	P._createElement = function() {
		BASE._createElement.call(this);
		var iframe = CE("iframe", null,
			{ frameBorder: 0, marginHeight: 0, marginWidth: 0,
			  src : is_ie ? "javascript:'';" : "about:blank" },
				this.getElement());
		this._hasFrameEvents = false;
		var keymap = this._keymap = [];
		for (var i in D.COMMANDS) {
			var cmd = D.COMMANDS[i];
			if (cmd.key)
				keymap.push([ parseKey(cmd.key), i ]);
		}
	};

	P.setOuterSize = function(s) {
		var pb1 = DOM.getPaddingAndBorder(this.getElement());
		var pb2 = DOM.getPaddingAndBorder(this.getContentElement());
		this.setInnerSize({ x: s.x - pb1.x - pb2.x, y: s.y - pb1.y - pb2.y });
	};

	P.getIframeElement = function() {
		return this.getElement().firstChild;
	};

	P.getContentElement = P.getIframeElement; // ALIAS

	P.getIframeWin = function() {
		return this.getIframeElement().contentWindow;
	};

	P.getIframeDoc = function() {
		return this.getIframeWin().document;
	};

	P.getIframeBody = function() {
		return this.getIframeDoc().body;
	};

	P.initDesignMode = function(callback) {
		var doc = this.getIframeDoc();
		doc.open();
		doc.write(INIT_HTML);
		doc.close();
		doc.designMode = "on";
		if (!this._hasFrameEvents)
			setTimeout(Dynarch.makeClosure(registerEvents, this, callback), 5);
	};

	P.setHTML = function(html) {
		if (html instanceof Array)
			html = html.join();
		this.getIframeBody().innerHTML = html.trim();
	};

	P.focus = function() {
		this.getIframeWin().focus();
	};

	P.loadStyle = function(css) {
		var doc = this.getIframeDoc();
		var id = css.replace(/\x2f/g, "_");
		if (!doc.getElementById(id)) {
			var head = doc.getElementsByTagName("head")[0];
			var link = doc.createElement("link");
			link.type = "text/css";
			link.rel = "stylesheet";
			link.href = css;
			link.id = id;
			head.appendChild(link);
			// The Magic Gecko Hack
			link.disabled = true;
			link.disabled = false;
		}
	};

	function parseKey(key) {
		var o = {};
		if (/^([a-z]+)\s+\x27(.)\x27$/i.test(key)) {
			o[RegExp.$1.toUpperCase()] = true;
			o.key = RegExp.$2;
		} else if (/^([a-z]+)-([a-z]+)\s+\x27(.)\x27$/i.test(key)) {
			o[RegExp.$1.toUpperCase()] = true;
			o[RegExp.$2.toUpperCase()] = true;
			o.key = RegExp.$3;
		} else if (/^([a-z]+)-([a-z]+)-([a-z]+)\s+\x27(.)\x27$/i.test(key)) {
			o[RegExp.$1.toUpperCase()] = true;
			o[RegExp.$2.toUpperCase()] = true;
			o[RegExp.$3.toUpperCase()] = true;
			o.key = RegExp.$4;
		}
		return o;
	};

	function onKeypress(ev) {
		this._keymap.r_foreach(function(kc) {
			var k = kc[0], cmd = kc[1],
				on = ( ((!k.CTRL  && !ev.ctrlKey)   ||  (k.CTRL    && ev.ctrlKey)) &&
				       ((!k.ALT   && !ev.altKey)    ||  (k.ALT     && ev.altKey)) &&
				       ((!k.SHIFT && !ev.shiftKey)  ||  (k.SHIFT   && ev.shiftKey)) &&
				       ev.keyStr.toUpperCase() == k.key.toUpperCase() );
			if (on) {
				this.execCommand(cmd);
				throw new DlExStopFrameEvent;
			}
		}, this);
	};

	function callUpdateHooks(dev, ev) {
		this.callHooks("onUpdate");
		this._timerUpdate = null;
	};

	function eventProxy(ev) {
		ev || (ev = this.getIframeWin().event);
		var dev = new DlEvent(ev);
		dev.origTarget = dev.target;
		var p1 = dev.origPos = dev.pos;
		var p2 = DOM.getPos(this.getIframeElement());
		dev.pos = { x: p1.x + p2.x, y: p1.y + p2.y };
		// dev.origRelatedTarget = dev.relatedTarget;
		dev.target = this.getElement();
		try {
			DlEvent._genericEventHandler(dev);
		} catch(ex) {
			if (ex instanceof DlExStopFrameEvent)
				DOM.stopEvent(ev);
		}
		if (/onMouseDown|onMouseUp|onKey/.test(dev.dl_type)) {
			if (this._timerUpdate)
				clearTimeout(this._timerUpdate);
			this._timerUpdate = setTimeout(Dynarch.makeClosure(callUpdateHooks, this, dev, ev), 25);
		}
	};

	function registerEvents(callback) {
		var doc = this.getIframeDoc();
		this._hasFrameEvents = true;
		DOM.addEvents(doc, FORWARD_EVENTS,
			      Dynarch.makeClosure(eventProxy, this));
		if (callback)
			callback();
	};

	window.DlRteFrame = D;

})();
