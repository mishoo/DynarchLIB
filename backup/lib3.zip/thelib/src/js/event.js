// @require eventlistener.js

(function() {

	eval(DynarchDomUtils.importCommonVars());

	var EVENT_MAP = {
		"onmouseover"   : "onMouseEnter",
		"onmouseout"    : "onMouseLeave",
		"onmousedown"   : "onMouseDown",
		"onmouseup"     : "onMouseUp",
		"onmousemove"   : "onMouseMove",
		"onclick"       : "onClick",
		"onkeydown"     : "onKeyDown",
		"onkeyup"       : "onKeyUp",
		"onkeypress"    : "onKeyPress",
		"oncontextmenu" : "onContextMenu"
	};

	function DlEvent(ev) {
		this.type = ev.type;
		if (!/^on/.test(this.type))
			this.type = "on" + this.type;
		this.dl_type = EVENT_MAP[this.type] || this.type;
		this.ctrlKey = ev.ctrlKey;
		this.altKey = ev.altKey;
		this.shiftKey = ev.shiftKey;
		this.button = ev.button;
		if (/^onkey/.test(this.type)) {
			this.keyCode = ev.keyCode;
			this.charCode = (is_ie || is_opera) ? ev.keyCode : ev.charCode;
			this.keyStr = String.fromCharCode(this.charCode);
		}
		this.pos = { x : ev.clientX,
			     y : ev.clientY };
		if (is_ie) {
			this.target = ev.srcElement;
			switch (this.type) {
			    case "onmouseover" : this.relatedTarget = ev.fromElement; break;
			    case "onmouseout"  : this.relatedTarget = ev.toElement; break;
			}
		} else try {
			this.target = ev.target;
			if (this.target.nodeType == 3 /* Node.TEXT */)
				this.target = this.target.parentNode;
			if (this.type == "onmouseout" || this.type == "onmouseover") {
				this.relatedTarget = ev.relatedTarget;
				if (this.relatedTarget && this.relatedTarget.nodeType == 3 /* Node.TEXT */)
					this.relatedTarget = this.relatedTarget.parentNode;
			}
		} catch(ex) {}
	};

	DlEvent.KEY = {
		BACKSPACE    :  8,
		TAB          :  9,
		ENTER        : 13,
		ESCAPE       : 27,
		DELETE       : 46,
		PAGE_UP      : 33,
		PAGE_DOWN    : 34,
		END          : 35,
		HOME         : 36,
		ARROW_LEFT   : 37,
		ARROW_UP     : 38,
		ARROW_RIGHT  : 39,
		ARROW_DOWN   : 40
	};

	DlEvent.prototype.computePos = function(widget) {
		var el = widget
			? ( widget instanceof DlWidget ?
			    widget.getElement() :
			    widget )
			: document.body;
		var pos = this.elPos = el
			? DOM.getPos(el)
			: { x: 0, y: 0 };
		return this.relPos = { x : this.pos.x - pos.x,
				       y : this.pos.y - pos.y };
	};

	DlEvent.prototype.getObject = function() {
		var el = this.target;
		var obj = this.object;
		if (!obj) {
			try {
				while (el && !DlWidget.getFromElement(el))
					el = el.parentNode;
				obj = el ? DlWidget.getFromElement(el) : null;
			} catch(ex) {
				obj = null;
			}
			this.object = obj;
		}
		return obj;
	};

	DlEvent.stopEvent = DOM.stopEvent;

	var _captures = {};
	var _captures_by_event = {};

	DlEvent.DRAG_EVENTS = [ "onMouseEnter", "onMouseLeave", "onMouseMove", "onMouseUp", "onMouseOver", "onMouseOut" ];

	DlEvent.captureEvents = function(w, evs) {
		var id = Dynarch.ID("capture");
		var capture = {
			widget : w,
			events : evs
		};
		evs.r_foreach(function(ev, i) {
			// FIXME: is this needed if we stay organized?
			// evs[i] = ev = ev.toLowerCase();
			var f = _captures_by_event[ev];
			if (f == null)
				f = _captures_by_event[ev] = {};
			f[id] = capture;
		});
		_captures[id] = capture;
		return id;
	};

	DlEvent.releaseCapture = function(id) {
		var c = _captures[id];
		c.events.r_foreach(function(ev) {
			var f = _captures_by_event[ev];
			if (f != null)
				delete f[id];
		});
		delete _captures[id];
		return null;
	};

	function _processCaptures(dev, el, ev) {
		var f = _captures_by_event[dev.dl_type];
		var processed = {};
		for (var i in f) {
			var w = f[i].widget;
			if (!DlEvent.checkDisabled(w)) {
				processed[w.id] = dev.dl_type;
				_processEvent(w, dev, el, ev);
			}
		}
		return processed;
	};

	function _processEvent(obj, dev, el, ev) {
		var o2 = dev.getObject();
		switch (dev.type) {
		    case "onclick" :
			break;
		    case "onmousedown" :
			obj._ev_mouseDown = true;
			obj.applyHooks(dev.dl_type, [ dev ]);
			break;
		    case "onmouseup" :
			var tmp = obj._ev_mouseDown;
			obj._ev_mouseDown = false;
			obj.applyHooks(dev.dl_type, [ dev ]);
			if (tmp && obj._ev_mouseInside)
				obj.applyHooks("onClick", [ dev ]);
			break;
		    case "onmouseover" :
		    case "onmouseout" :
			if (!el || !DOM.related(el, ev)) {
				if (obj === o2)
					obj._ev_mouseInside = dev.type == "onmouseover";
				obj.applyHooks(dev.dl_type, [ dev ]);
			} else {
				// FIXME: this seems to be a hack ;)
				dev.dl_type = dev.type == "onmouseover"
					? "onMouseOver" : "onMouseOut";
				obj.applyHooks(dev.dl_type, [ dev ]);
			}
			break;
		    case "onmousemove" :
		    default :
			obj.applyHooks(dev.dl_type, [ dev ]);
			break;
		}
	};

	DlEvent.checkDisabled = function(w) {
		while (w) {
			if (w.disabled())
				return true;
			w = w.parent;
		}
		return false;
	};

	var GLOBAL_CAPTURES = {};

	// var CKT=0;
	DlEvent._genericEventHandler = function(ev) {
		ev || (ev = window.event);
		// window.status = "still here " + (++CKT);
		var el, obj,
			dev = ev instanceof DlEvent ? ev : new DlEvent(ev);
		DlEvent.latestEvent = dev;
		try {
			if (GLOBAL_CAPTURES[dev.dl_type])
				GLOBAL_CAPTURES[dev.dl_type].r_foreach(function(f) {
					f(dev);
				});
			el = dev.target;
			var processed = _processCaptures(dev, el, ev);
			//window.status = dev.dl_type;
			var objects = [];
			while (el) {
				obj = DlWidget.getFromElement(el);
				if (obj && !DlEvent.checkDisabled(obj)
				    && processed[obj.id] != dev.dl_type) {
					objects.push([ obj, el ]);
				}
				el = el.parentNode;
			}
			objects.foreach(function(e) {
				try {
					_processEvent(e[0], dev, e[1], ev);
				} catch(ex) {
					if (ex instanceof DlExStopDOMEventBubbling)
						DlEvent.stopEvent(ev);
					else
						throw ex;
				}
			});
		} catch(ex) {
			if (ex instanceof DlExStopEventBubbling)
				DlEvent.stopEvent(ev);
			else
				throw ex;
		}
	};

	var _unloadListeners = [];
	function _unloadHandler() {
		_unloadListeners.r_foreach(function(f) { f(); });
	};

	// map type => function ref.
	DlEvent.captureGlobals = function(obj) {
		for (var i in obj)
			DlEvent.captureGlobal(i, obj[i]);
	};

	DlEvent.captureGlobal = function(type, f) {
		var a = GLOBAL_CAPTURES[type];
		if (!a)
			a = GLOBAL_CAPTURES[type] = [];
		a.push(f);
	};

	DlEvent.releaseGlobal = function(type, f) {
		var a = GLOBAL_CAPTURES[type];
		if (a)
			a.remove(f);
	};

	// map type => function ref.
	DlEvent.releaseGlobals = function(obj) {
		for (var i in obj)
			DlEvent.releaseGlobal(i, obj[i]);
	};

	DlEvent.atUnload = function(f) { _unloadListeners.push(f); };

	DOM.addEvents
		(document, [ "contextmenu", "click", "mouseover",
			     "mouseout", "mousedown", "mouseup",
			     "mousemove", "keydown", "keyup", "keypress" ],
		 DlEvent._genericEventHandler);

	window.DlEvent = DlEvent;

})();
